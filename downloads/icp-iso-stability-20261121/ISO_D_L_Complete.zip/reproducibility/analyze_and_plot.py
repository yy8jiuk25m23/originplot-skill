"""Two independent ion intensity stability plots from the uploaded D/L ISO data."""
from pathlib import Path
import os,json,hashlib,shutil,zipfile,platform
B=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(B/'mplconfig')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
from matplotlib.ticker import MultipleLocator
from PIL import Image

O=B/'output';O.mkdir(exist_ok=True)
font=Path('/workspace/icp_chiral_20261121/font_setup/Arial.ttf')
if not font.exists():font=B/'font_setup/Arial.ttf'
font_manager.fontManager.addfont(str(font))
assert font_manager.FontProperties(fname=font).get_name()=='Arial'
plt.rcParams.update({'font.family':'Arial','font.size':11,'axes.labelsize':12,
 'xtick.labelsize':10,'ytick.labelsize':10,'axes.linewidth':.8,
 'axes.edgecolor':'#333333','text.color':'#222222','axes.labelcolor':'#222222',
 'axes.unicode_minus':False,'savefig.facecolor':'white','figure.facecolor':'white',
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','path.simplify':False})
COLORS={'D':'#2166AC','L':'#D73027'}
WINDOWS={'D':{'Arginine':(12000,13000),'Verapamil':(40000,41000)},
         'L':{'Arginine':(170,180),'Verapamil':(450,460)}}
metadata=json.loads((B/'raw_metadata.json').read_text())
rows=[];summary=[];traces={};qa=[]
for group in ['D','L']:
    source=next(r for r in metadata if r['sample']==group)
    path=B/'raw'/source['file']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==source['sha256']
    with zipfile.ZipFile(path) as z:assert z.testzip() is None
    a=np.load(B/f'{group}_raw_arrays.npz');data=a['data'];headers=a['headers'].tolist()
    x=data[:,0];ys=data[:,1:]
    assert data.shape==(95000,36) and np.isfinite(data).all() and np.all(np.diff(x)>0)
    for ion,(lo,hi) in WINDOWS[group].items():
        selected=np.flatnonzero((x>=lo)&(x<=hi));assert len(selected)>100
        values=ys[selected,:];positions=values.argmax(axis=0)
        indices=selected[positions];heights=values.max(axis=0)
        assert np.all(heights>0) and np.all((positions>0)&(positions<len(selected)-1))
        mean=float(heights.mean());sd=float(heights.std(ddof=1));rsd=100*sd/mean
        relative=100*heights/mean
        assert np.isclose(relative.mean(),100)
        assert np.isclose(100*relative.std(ddof=1)/relative.mean(),rsd)
        # Confirm the broad-window maximum is the same peak in a common narrower
        # row window. This is a robustness check, never a change of selection.
        anchor=int(selected[np.argmax(values.mean(axis=1))])
        narrow=np.arange(max(0,anchor-45),min(len(x),anchor+46))
        assert np.array_equal(heights,ys[narrow,:].max(axis=0))
        # Export local, unaltered signal for inspection and Origin import.
        frame=pd.DataFrame({'X_source':x[selected]})
        for j,name in enumerate(headers[1:]):frame[name]=ys[selected,j]
        frame.to_csv(O/f'{group}_{ion}_original_peak_window.csv.gz',index=False,compression='gzip',float_format='%.15g')
        traces[group,ion]=dict(height=heights,relative=relative,peak_X=x[indices])
        for j,name in enumerate(headers[1:]):
            rows.append(dict(group=group,ion=ion,scan=str(name),scan_number=j+1,
                source_file=source['file'],source_peak_height=float(heights[j]),
                relative_to_group_mean_percent=float(relative[j]),peak_X_source=float(x[indices[j]]),
                X_axis_kind='raw sampling index' if group=='D' else 'exported m/z grid',
                peak_mz_from_source=float(x[indices[j]]) if group=='L' else np.nan,
                peak_row_0based=int(indices[j]),window_lower_X=lo,window_upper_X=hi,
                included=True,source_UI_Raw='True' if group=='D' else 'False',source_UI_Relative='False'))
        summary.append(dict(group=group,ion=ion,n=35,source_peak_height_mean=mean,
            source_peak_height_SD_sample=sd,RSD_percent=rsd,relative_intensity_mean_percent=float(relative.mean()),
            relative_intensity_SD_percentage_points=float(relative.std(ddof=1)),
            source_peak_height_min=float(heights.min()),source_peak_height_max=float(heights.max()),
            relative_min_percent=float(relative.min()),relative_max_percent=float(relative.max()),
            peak_X_mean=float(x[indices].mean()),peak_X_SD_sample=float(x[indices].std(ddof=1)),
            peak_X_unit='sampling index' if group=='D' else 'm/z',window_lower_X=lo,window_upper_X=hi,
            pooled_local_peak_anchor_row_0based=anchor,
            narrow_window_same_peak_heights=True,all35_retained=True))
        qa.append(dict(group=group,ion=ion,n=35,positive_heights=True,no_boundary_maxima=True,
            broad_and_narrow_windows_exactly_same_heights=True,normalization_preserves_RSD=True))
peaks=pd.DataFrame(rows);stats=pd.DataFrame(summary)
peaks.to_csv(O/'All_140_Ion_Peak_Records.csv',index=False,float_format='%.15g')
stats.to_csv(O/'Ion_Stability_Summary.csv',index=False,float_format='%.15g')
ratio=[]
for group in ['D','L']:
    r=100*traces[group,'Verapamil']['height']/traces[group,'Arginine']['height']
    for j,v in enumerate(r):ratio.append(dict(group=group,scan_number=j+1,Verapamil_over_Arginine_percent=float(v)))
pd.DataFrame(ratio).to_csv(O/'Supplement_Ver_to_Arg_Ratio.csv',index=False,float_format='%.15g')

methods=[
 ('Source','D-ISO.xlsx and corrected L-ISO.xlsx; each 95000 data rows, 35 scans. Invalid initial empty L upload is not used.'),
 ('Ion identity','User assigned the lower mass strong peak to arginine and the higher peak near m/z455 to verapamil.'),
 ('D X axis','Raw sampling indices 0..94999; no verified m/z transformation provided. Extract original-index windows; do not report D absolute m/z.'),
 ('L X axis','File contains its own m/z grid, 50..999.989996. Use that grid directly.'),
 ('Extraction','Every scan maximum within a fixed ion/group window; D Arg[12000,13000], Ver[40000,41000]; L Arg[170,180], Ver[450,460].'),
 ('Robustness','For all scans, the same maxima are found within +/-45 data rows of each group/ion mean-spectrum peak. No competing dominant neighbor peak.'),
 ('Relative intensity','100 * per-scan ion peak height / mean peak height of that ion in that D or L group. Group mean is 100%; individual scans are not each forced to 100%.'),
 ('Stability','RSD=100*sample SD/mean, ddof=1; smaller RSD means lower observed exported-signal variability.'),
 ('No extra processing','No scans deleted, no alignment, no smoothing, no fitting, no reconstructed signal, no baseline subtraction.'),
 ('Ratio supplement','Ver/Arg*100 is provided separately and is not the plotted independent Ver stability: its variability includes denominator fluctuations.'),
 ('Limits','UI Raw=True for D and False for L; Relative=False for both. Instrument processing behind that UI flag is unverified. Compare observed exported-signal variability, not proven intrinsic enantiomer or hardware stability.'),
 ('Chronology','X-axis Scan number follows source Y1..Y35. No acquisition timestamps or temporal-independence assumptions supplied.'),
 ('Renderer','Matplotlib, Arial; not rendered in native Origin. Origin-importable CSV supplied.')]
with pd.ExcelWriter(O/'ISO_D_L_Stability_Data.xlsx',engine='openpyxl') as writer:
    tables={'Summary':stats,'All140_peak_records':peaks,'Arginine70':peaks[peaks.ion=='Arginine'],
        'Verapamil70':peaks[peaks.ion=='Verapamil'],'Ver_to_Arg_supplement':pd.DataFrame(ratio),
        'Methods':pd.DataFrame(methods,columns=['item','definition']),
        '原始文件校验':pd.DataFrame([dict(group=r['sample'],file=r['file'],sha256=r['sha256']) for r in metadata])}
    from openpyxl.styles import Font,PatternFill
    for name,df in tables.items():
        df.to_excel(writer,sheet_name=name,index=False);ws=writer.sheets[name];ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
        for c in ws[1]:c.font=Font(name='Arial',bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='264A60')
        for col in ws.columns:
            ws.column_dimensions[col[0].column_letter].width=min(65,max(15,max(len(str(c.value or '')) for c in list(col)[:145])+2))
            for c in list(col)[1:]:
                if isinstance(c.value,float):c.number_format='0.000000'

render_records=[]
def swarm_x(ax,center,y,min_separation_pt=5.4):
    """Pack only display X offsets; the measured Y values are never changed."""
    fig=ax.figure;fig.canvas.draw()
    px_per_x=ax.transData.transform((1,100))[0]-ax.transData.transform((0,100))[0]
    py=ax.transData.transform(np.column_stack([np.full(len(y),center),y]))[:,1]
    sep=min_separation_pt*fig.dpi/72
    candidates=np.r_[0,np.column_stack([np.arange(1,16),-np.arange(1,16)]).ravel()]*sep
    result=np.zeros(len(y));placed=[]
    for i in np.argsort(y,kind='stable'):
        for shift in candidates:
            if all((shift-other_x)**2+(py[i]-other_y)**2>=sep**2-.0001 for other_x,other_y in placed):
                result[i]=shift/px_per_x;placed.append((shift,py[i]));break
        else:raise RuntimeError('Cannot pack every actual point without overlap')
    assert np.max(np.abs(result))<.27
    return center+result

# Identical axes make the amount of fluctuation comparable across the two ions.
for ion,label,stem in [('Arginine','Arginine target ion','01_Arginine_Target_Stability'),
                       ('Verapamil','Verapamil (m/z ~455)','02_Verapamil_Relative_Intensity')]:
    fig,ax=plt.subplots(figsize=(7.6,5.8))
    fig.subplots_adjust(left=.15,right=.97,bottom=.15,top=.88)
    ax.set(ylabel='Relative intensity (% of group mean)',
           xlim=(.45,2.55),ylim=(80,145),xticks=[1,2],xticklabels=['D-Arginine','L-Arginine'])
    ax.set_title(label,fontsize=13,pad=15,loc='left')
    ax.yaxis.set_major_locator(MultipleLocator(10))
    ax.axhline(100,color='#AAAAAA',lw=.9,ls=(0,(4,4)),zorder=0)
    point_artists=[]
    from matplotlib.colors import to_rgba
    for group,center in [('D',1),('L',2)]:
        s=stats[(stats.group==group)&(stats.ion==ion)].iloc[0]
        yy=traces[group,ion]['relative']
        ax.boxplot([yy],positions=[center],widths=.43,patch_artist=True,showfliers=False,manage_ticks=False,
            boxprops=dict(facecolor=to_rgba(COLORS[group],.06),edgecolor=COLORS[group],lw=1.7),
            whiskerprops=dict(color=COLORS[group],lw=1.4),capprops=dict(color=COLORS[group],lw=1.4),
            medianprops=dict(color='#222222',lw=1.7),zorder=1)
        artist=ax.scatter(swarm_x(ax,center,yy),yy,s=25,color=COLORS[group],edgecolors='white',
            linewidths=.45,alpha=.85,zorder=3)
        point_artists.append(artist)
        ax.text(center,140.3,f'RSD = {s.RSD_percent:.2f}%',ha='center',va='center',
                fontsize=11,color=COLORS[group])
    ax.tick_params(direction='out',length=4,width=.8)
    ax.tick_params(axis='x',length=0,pad=10)
    assert sum(len(a.get_offsets()) for a in point_artists)==70
    assert all(np.array_equal(point_artists[j].get_offsets()[:,1],traces[g,ion]['relative']) for j,g in enumerate(['D','L']))
    fig.savefig(O/f'{stem}_600dpi.png',dpi=600)
    fig.savefig(O/f'{stem}_600dpi.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
    fig.savefig(O/f'{stem}_preview.png',dpi=240)
    fig.savefig(O/f'{stem}_vector.pdf',metadata={'Creator':'Matplotlib',
        'Subject':'Exported signal stability; per-ion, within-group mean normalization; D/L Raw UI flags differ'})
    fig.savefig(O/f'{stem}_editable.svg')
    plt.close(fig)
    for suffix in ['png','tiff']:
        with Image.open(O/f'{stem}_600dpi.{suffix}') as im:
            assert im.size==(4560,3480) and all(abs(float(d)-600)<.1 for d in im.info['dpi'])
    render_records.append(dict(figure=stem,ion=ion,style='boxplot and packed actual scatter points',
        displayed_groups=2,actual_points=70,dpi=600,
        raster_pixels=[4560,3480],y_limits=[80,145],normalization='per-group per-ion mean=100%',
        source_scans_deleted=0,no_smoothing=True))

record=dict(experiment='D/L arginine with verapamil hydrochloride',identity_basis='user confirmed lower mass arginine, higher mass verapamil near455',
    source_files=[dict(group=r['sample'],file=r['file'],sha256=r['sha256']) for r in metadata],
    normalization='100*individual scan ion peak height/group mean peak height of same ion',
    RSD_formula='100*sample SD/mean; ddof=1',scans_per_group=35,ions_per_scan=2,
    original_scan_count=70,ion_peak_record_count=140,excluded_scans=0,windows=WINDOWS,
    no_D_absolute_mass_calibration_assumed=True,
    source_UI_settings={'D':{'Raw':'True','Relative':'False'},'L':{'Raw':'False','Relative':'False'}},
    comparison_limit='Observed exported-signal variability; Raw UI setting differs and instrument preprocessing is unverified.',
    methods=dict(methods),qa=qa,figures=render_records,actual_renderer='Matplotlib',font_family='Arial',
    software={'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'matplotlib':matplotlib.__version__})
(O/'processing_record.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
(O/'source_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
print(stats.to_string(index=False))
print('COMPLETE: 2 D/L comparison figures, 140 real ion peaks from all70 scans; no deletions; 600dpi images; RSD preserved.')
