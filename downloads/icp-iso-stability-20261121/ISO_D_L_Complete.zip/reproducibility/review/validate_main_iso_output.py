"""Independent QA of deliverables against separately extracted raw-window peaks."""
from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from openpyxl import load_workbook
from PIL import Image
B=Path(__file__).resolve().parents[1];O=B/'output';R=Path(__file__).resolve().parent
ind=pd.read_csv(R/'independent_all70_ISO_peak_heights.csv')
peaks=pd.read_csv(O/'All_140_Ion_Peak_Records.csv');summary=pd.read_csv(O/'Ion_Stability_Summary.csv');ratio=pd.read_csv(O/'Supplement_Ver_to_Arg_Ratio.csv')
checks=[];err=[]
def ck(n,p):checks.append({'check':n,'passed':bool(p)})
def num(n,a,e):
 a=np.asarray(a,float);e=np.asarray(e,float);delta=np.abs(a-e);finite=np.isfinite(delta)
 if finite.any():err.append(float(delta[finite].max()))
 ck(n,np.allclose(a,e,atol=1e-10,rtol=1e-12,equal_nan=True))
ck('140 unique real ion records from 70 unique original scans',len(peaks)==140 and not peaks[['group','scan','ion']].duplicated().any() and len(peaks[['group','scan']].drop_duplicates())==70)
ck('All140 records retained',peaks.included.all())
for g in ['D','L']:
 independent=ind[ind.group==g].sort_values('scan_number');ck(g+' 35 unique independent scans',len(independent)==35)
 raw=np.load(B/f'{g}_raw_arrays.npz');data=raw['data'];x=data[:,0];ys=data[:,1:];names=raw['headers'].tolist()[1:]
 for ion,short in [('Arginine','Arg'),('Verapamil','Ver')]:
  p=peaks[(peaks.group==g)&(peaks.ion==ion)].sort_values('scan_number');ck(g+' '+ion+' all35 identities and inclusion',len(p)==35 and p.scan.tolist()==names and p.scan_number.tolist()==list(range(1,36)) and p.included.all())
  expected=independent[short+'_peak_height_raw'].to_numpy();rel=100*expected/expected.mean()
  num(g+' '+ion+' every raw peak height',p.source_peak_height,expected)
  num(g+' '+ion+' every original peak X',p.peak_X_source,independent[short+'_peak_X'])
  num(g+' '+ion+' every original peak row',p.peak_row_0based,independent[short+'_peak_row_index_0based'])
  num(g+' '+ion+' every plotted relative intensity',p.relative_to_group_mean_percent,rel)
  s=summary[(summary.group==g)&(summary.ion==ion)];ck(g+' '+ion+' unique summary row',len(s)==1);s=s.iloc[0]
  sampleSD=expected.std(ddof=1);rsd=100*sampleSD/expected.mean()
  expectedstats={'n':35,'source_peak_height_mean':expected.mean(),'source_peak_height_SD_sample':sampleSD,'RSD_percent':rsd,'relative_intensity_mean_percent':rel.mean(),'relative_intensity_SD_percentage_points':rel.std(ddof=1),'source_peak_height_min':expected.min(),'source_peak_height_max':expected.max(),'relative_min_percent':rel.min(),'relative_max_percent':rel.max(),'peak_X_mean':independent[short+'_peak_X'].mean(),'peak_X_SD_sample':independent[short+'_peak_X'].std(ddof=1)}
  num(g+' '+ion+' all summary metrics',[s[k] for k in expectedstats],list(expectedstats.values()))
  num(g+' '+ion+' group-mean normalization preserves original RSD',[100*p.relative_to_group_mean_percent.std(ddof=1)/p.relative_to_group_mean_percent.mean(),p.relative_to_group_mean_percent.mean()],[rsd,100.])
  ck(g+' '+ion+' all35 summary retained and narrow-window robustness',s.all35_retained and s.narrow_window_same_peak_heights)
  if g=='D':
   ck(g+' '+ion+' raw coordinate never fabricated as mass',p.X_axis_kind.eq('raw sampling index').all() and p.peak_mz_from_source.isna().all() and s.peak_X_unit=='sampling index')
  else:
   ck(g+' '+ion+' file-provided mass grid used',p.X_axis_kind.eq('exported m/z grid').all() and np.allclose(p.peak_mz_from_source,p.peak_X_source) and s.peak_X_unit=='m/z')
  ck(g+' '+ion+' correct exported UI Raw and Relative metadata',p.source_UI_Raw.eq(g=='D').all() and p.source_UI_Relative.eq(False).all())
  window=pd.read_csv(O/f'{g}_{ion}_original_peak_window.csv.gz');keep=(x>=p.window_lower_X.iloc[0])&(x<=p.window_upper_X.iloc[0])
  num(g+' '+ion+' full raw peak-window X export',window.X_source,x[keep]);ck(g+' '+ion+' full raw-window intensity export exact',np.array_equal(window.iloc[:,1:].to_numpy(),ys[keep]))
  anchor=int(s.pooled_local_peak_anchor_row_0based);num(g+' '+ion+' fixed +/-45-row robustness maxima',ys[max(0,anchor-45):min(len(x),anchor+46),:].max(axis=0),expected)
 r=ratio[ratio.group==g].sort_values('scan_number')
 ck(g+' 35 supplemental ratio scans',len(r)==35 and r.scan_number.tolist()==list(range(1,36)))
 num(g+' every supplemental Ver/Arg ratio',r.Verapamil_over_Arginine_percent,independent.Ver_over_Arg_percent)
ck('Summary exactly four group/ion rows',len(summary)==4 and not summary[['group','ion']].duplicated().any())
ck('Supplemental ratio exactly70 records',len(ratio)==70 and not ratio[['group','scan_number']].duplicated().any())
w=load_workbook(O/'ISO_D_L_Stability_Data.xlsx',read_only=True,data_only=True)
for sheet,n in {'Summary':4,'All140_peak_records':140,'Arginine70':70,'Verapamil70':70,'Ver_to_Arg_supplement':70,'Methods':13,'原始文件校验':2}.items():
 ck('Excel '+sheet+' row count',sheet in w.sheetnames and w[sheet].max_row-1==n)
for sn in w.sheetnames:ck('Excel '+sn+' no error cells',not any(c.data_type=='e' for row in w[sn].iter_rows() for c in row))
w.close()
meta=json.loads((O/'source_metadata.json').read_text())
for m in meta:ck(m['sample']+' original XLSX SHA256 preserved',hashlib.sha256((B/'raw'/m['file']).read_bytes()).hexdigest()==m['sha256'])
record=json.loads((O/'processing_record.json').read_text())
ck('Record states70 scans/140 peaks retained',record['original_scan_count']==70 and record['ion_peak_record_count']==140 and record['excluded_scans']==0)
ck('Record explicitly avoids D absolute m/z assumption',record['no_D_absolute_mass_calibration_assumed'])
ck('Record exposes differing source Raw UI settings',record['source_UI_settings']=={'D':{'Raw':'True','Relative':'False'},'L':{'Raw':'False','Relative':'False'}})
ck('Scientific limitation: exported signal variability only',record['comparison_limit']=='Observed exported-signal variability; Raw UI setting differs and instrument preprocessing is unverified.')
ck('Only two main figures, each contains all70 real scan points',len(record['figures'])==2 and all(f['actual_points']==70 and f['source_scans_deleted']==0 and f['no_smoothing'] for f in record['figures']))
for f in record['figures']:
 for suffix in ['png','tiff']:
  with Image.open(O/f"{f['figure']}_600dpi.{suffix}") as im:ck(f['figure']+' '+suffix+' 600dpi and size',im.size==(5520,3360) and all(abs(float(d)-600)<.1 for d in im.info['dpi']))
result={'reviewer':'Independent raw-window extraction, separate implementation','all_passed':all(c['passed'] for c in checks),'n_checks':len(checks),'n_failed':sum(not c['passed'] for c in checks),'maximum_numeric_absolute_error':max(err),'absolute_tolerance':1e-10,'relative_tolerance':1e-12,'scope':'140 original ion records, four summary groups, per-ion within-group-mean normalization, supplemental Ver/Arg ratio, raw-window exports, workbook row counts, source hashes, raw-coordinate/mass distinction and exported-signal limitation','checks':checks}
(R/'independent_deliverable_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))
for c in checks:
 if not c['passed']:print('FAILED',c)
assert result['all_passed']
