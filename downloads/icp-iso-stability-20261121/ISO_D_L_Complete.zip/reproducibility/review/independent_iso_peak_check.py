"""Independent read-only extraction of original-window peak heights for ISO stability."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.signal import find_peaks
B=Path(__file__).resolve().parents[1];R=Path(__file__).resolve().parent
rows=[];sums=[];competing=[]
for group,windows,unit in [('D',{'Arg':(12000,13000),'Ver':(40000,41000)},'original sampling coordinate'),('L',{'Arg':(170,180),'Ver':(450,460)},'m/z as provided in L file')]:
    a=np.load(B/f'{group}_raw_arrays.npz');d=a['data'];x=d[:,0];ys=d[:,1:];names=a['headers'].tolist()[1:]
    assert d.shape==(95000,36) and np.isfinite(d).all()
    ext={};pcoords={}
    for ion,(lo,hi) in windows.items():
        mask=(x>=lo)&(x<=hi);xx=x[mask];yy=ys[mask];indices=np.flatnonzero(mask);p=np.argmax(yy,axis=0);height=yy[p,np.arange(35)];ext[ion]=height;pcoords[ion]=(xx[p],indices[p])
        assert np.all((p>0)&(p<len(xx)-1)) and np.all(height>0)
        mean=height.mean();sd=height.std(ddof=1)
        sums.append({'group':group,'ion':ion,'n':35,'window_low_original_X':lo,'window_high_original_X':hi,'X_unit':unit,'peak_X_min':float(xx[p].min()),'peak_X_max':float(xx[p].max()),'raw_peak_mean':float(mean),'raw_peak_sample_SD':float(sd),'raw_peak_RSD_percent':float(100*sd/mean),'raw_peak_min':float(height.min()),'raw_peak_max':float(height.max()),'own_group_mean_normalized_mean_percent':float((100*height/mean).mean()),'own_group_mean_normalized_sample_SD_percentage_points':float((100*height/mean).std(ddof=1))})
        for j in range(35):
            # Report competing local peaks separated >=50 actual row positions
            # from selected main peak. This is QA only, not used to select data.
            peaks,_=find_peaks(yy[:,j],distance=10)
            candidates=peaks[abs(peaks-p[j])>50]
            other=int(candidates[np.argmax(yy[candidates,j])]) if len(candidates) else None
            competing.append({'group':group,'ion':ion,'scan':names[j],'selected_peak_X':float(xx[p[j]]),'selected_peak_height':float(height[j]),'largest_competing_local_peak_X':None if other is None else float(xx[other]),'largest_competing_local_peak_height':None if other is None else float(yy[other,j]),'competing_relative_to_main_percent':None if other is None else float(100*yy[other,j]/height[j])})
    for j,name in enumerate(names):
        row={'group':group,'scan':name,'scan_number':j+1,'Arg_peak_height_raw':float(ext['Arg'][j]),'Ver_peak_height_raw':float(ext['Ver'][j]),'Arg_peak_X':float(pcoords['Arg'][0][j]),'Ver_peak_X':float(pcoords['Ver'][0][j]),'Arg_peak_row_index_0based':int(pcoords['Arg'][1][j]),'Ver_peak_row_index_0based':int(pcoords['Ver'][1][j]),'Arg_own_group_mean_percent':float(100*ext['Arg'][j]/ext['Arg'].mean()),'Ver_own_group_mean_percent':float(100*ext['Ver'][j]/ext['Ver'].mean()),'Ver_over_Arg_percent':float(100*ext['Ver'][j]/ext['Arg'][j])}
        rows.append(row)
    ratio=100*ext['Ver']/ext['Arg'];sums.append({'group':group,'ion':'Ver/Arg ratio','n':35,'ratio_mean_percent':float(ratio.mean()),'ratio_sample_SD_percentage_points':float(ratio.std(ddof=1)),'ratio_RSD_percent':float(100*ratio.std(ddof=1)/ratio.mean())})
f=pd.DataFrame(rows);c=pd.DataFrame(competing)
f.to_csv(R/'independent_all70_ISO_peak_heights.csv',index=False,float_format='%.17g');c.to_csv(R/'independent_competing_peaks_QA.csv',index=False,float_format='%.17g')
r={'n_scans':len(f),'all_scans_retained':True,'selection':'Fixed original-X windows per file, each actual observed maximum, no smoothing/fitting/alignment/reconstruction','D_coordinate_warning':'D X is uncalibrated raw sampling coordinate. Do not transplant L m/z calibration or infer exact D m/z. User assigned lower peak to arginine and higher peak to verapamil (~455).','main_plot_normalization':'100*per-scan ion raw peak height / full35 group mean of the same ion. Relative own-group mean; not per-scan maximum normalization. It preserves raw CV exactly.','ratio_warning':'Ver/Arg ratio is secondary table metric; its variability includes Arg reference variability and is not independent Ver stability.','statistics':sums,'maximum_competing_fraction_percent_by_group_and_ion':[{'group':g,'ion':i,'max_competing_relative_to_main_percent':float(v)} for (g,i),v in c.groupby(['group','ion']).competing_relative_to_main_percent.max().items()]}
(R/'independent_ISO_peak_review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
print(pd.DataFrame(sums).to_string(index=False))
print('Max competing local peak % of main:')
print(c.groupby(['group','ion']).competing_relative_to_main_percent.max())
