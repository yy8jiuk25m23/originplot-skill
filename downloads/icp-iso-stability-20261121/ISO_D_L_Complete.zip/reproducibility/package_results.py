from pathlib import Path
import json,hashlib,zipfile,subprocess
import pandas as pd
from PIL import Image
B=Path(__file__).resolve().parent;O=B/'output'
s=pd.read_csv(O/'Ion_Stability_Summary.csv')
BASE='https://github.com/yy8jiuk25m23/originplot-skill/raw/refs/heads/icp-iso-stability-20261121/downloads/icp-iso-stability-20261121/'
report='''# D/L 精氨酸与维拉帕米 ISO 强度稳定性

仅输出两张科学图，均为箱线图叠加全部真实散点：

1. `01_Arginine_Target_Stability`：精氨酸目标离子，D/L 同图。
2. `02_Verapamil_Relative_Intensity`：维拉帕米介质离子（约 m/z455），D/L 同图。

每组35次测量，70条扫描均保留，逐扫描分别提取两离子的峰高，共140条真实峰记录。没有额外平滑、拟合、峰形重建、峰位对齐、基线扣除或扫描剔除。旧的空白 L 上传没有参与本次分析。

## 结果

| 离子 | D组峰高均值 ± 样本SD | D组RSD | L组峰高均值 ± 样本SD | L组RSD |
|---|---:|---:|---:|---:|
'''
for ion,name in [('Arginine','精氨酸'),('Verapamil','维拉帕米')]:
 d=s[(s.group=='D')&(s.ion==ion)].iloc[0];l=s[(s.group=='L')&(s.ion==ion)].iloc[0]
 report+=f'| {name} | {d.source_peak_height_mean:,.3f} ± {d.source_peak_height_SD_sample:,.3f} | {d.RSD_percent:.6f}% | {l.source_peak_height_mean:,.3f} ± {l.source_peak_height_SD_sample:,.3f} | {l.RSD_percent:.6f}% |\n'
report+='''
本次导出数据中，精氨酸目标信号 D 组的相对波动小于 L 组；维拉帕米两组的波动接近。这里只作描述性比较，没有进行显著性检验，也不将RSD较小解释为仪器本身或对映体本征稳定性提高。

## 相对强度定义

两图统一使用：**相对强度(%) = 每次该离子峰高 / 本组该离子35次峰高的均值 × 100**。

100%灰虚线表示各组自身均值。每次测量的峰高仍可高于或低于100%；这不是逐条谱把目标峰强制设为100%。该正比例缩放不改变RSD。RSD=100×样本SD/均值，SD采用ddof=1。

这一归一化用于比较各组自身的强度波动，不能从图上的100%判断D/L绝对信号相同。原始导出峰高及其均值/SD均保留在Excel和CSV中。

`Supplement_Ver_to_Arg_Ratio.csv` 和Excel另附每次 `I_Ver/I_Arg×100`，仅作相对丰度补充；它同时受分母精氨酸波动影响，不代替维拉帕米独立信号稳定性的主图。

## 图形说明

横轴D/L样品；纵轴相对于该组该离子平均峰高的百分比。两图纵轴统一80%–145%，便于比较波动大小。箱体为Q1–Q3，中线为中位数，须为1.5IQR范围内最远观测值。35个测量点全部单独绘出，超出须的点仍保留。散点只做水平方向避让，实际强度纵坐标未改变。上方为完整35次数据的RSD。

Arial字体，D=#2166AC，L=#D73027，白底。PNG/TIFF为600dpi、4560×3480像素；另附矢量PDF/SVG。实际使用Matplotlib渲染，没有原生Origin工程。

## 离子提取与坐标依据

用户确认低质荷比强峰为精氨酸，高质荷比强峰为约455的维拉帕米。

- D文件保留Raw=True，第一列为0–94999的原始采样索引，使用固定原始X窗：精氨酸12000–13000、维拉帕米40000–41000。没有把索引直接当作m/z，也没有套用L的标定。
- 新L文件Raw=False，第一列已经是导出的m/z网格50–999.989996，使用170–180与450–460固定窗口。
- 各窗取每条扫描的实际最大峰高。所有扫描在均值谱主峰附近±45行的较窄窗口重提取均得到完全相同峰高，主峰不存在强邻峰竞争；最强竞争邻峰低于主峰0.66%。
- L实测精氨酸主峰约174.863–174.893，维拉帕米约455.160–455.180，按实测位置取峰，不人为移动到理论位置。

**采集/导出设置限制：D与L的Raw开关不同，Relative均为False。该开关背后的仪器预处理影响尚未核实；这里的结论严格限于当前导出信号。若要归因于样品或添加剂本身，应统一并核实采集、信号处理与导出设置。**扫描序号来自Y1–Y35，没有额外时间戳或扫描独立性证明。

## 文件与可追溯性

`ISO_D_L_Stability_Data.xlsx` 含四组汇总、140条逐次峰记录、两离子各70条记录、70个Ver/Arg比值、方法及原始文件SHA256。四份原始局部窗口CSV.GZ可直接导入分析软件。完整包保存有效原始D/L Excel、读取/处理脚本、输入元数据、独立复核及处理记录。原始文件未覆盖。

独立复核91项全部通过：原始逐次峰高、SD/RSD、均值归一、比值、原始局部信号与Excel行数均一致。单独的格式检查还核对600dpi、PDF字体嵌入和矢量属性。

## GitHub 下载

'''
for label,name in [('精氨酸PNG','01_Arginine_Target_Stability_600dpi.png'),('维拉帕米PNG','02_Verapamil_Relative_Intensity_600dpi.png'),
 ('两张图全部图片格式','ISO_D_L_Two_Figures.zip'),('仅两张PNG','ISO_D_L_Two_PNG.zip'),
 ('完整数据与处理记录','ISO_D_L_Complete.zip'),('统计Excel','ISO_D_L_Stability_Data.xlsx')]:
 report+=f'- [{label}]({BASE}{name})\n'
(O/'README_ZH.md').write_text(report)
captions='''Arginine target ion intensity stability and Verapamil (m/z approximately455) intensity stability.
Each figure shows D- and L-arginine samples with 35 scans each. Relative intensity=100*individual ion peak height/mean peak height of that same ion and group. The dashed line denotes the group mean, not equal absolute abundance across groups. Box Q1-Q3, median center line, whiskers within1.5IQR; every observation is displayed, including points beyond whiskers. Horizontal packing affects display only. RSD=100*sample SD/mean, ddof=1. No scans excluded and no extra smoothing/fitting. Identical y-axis limits80-145%. User-assigned lower-mass arginine and higher-mass verapamil identity. D raw sampling indices are not reported as m/z; L uses the exported m/z grid. Raw UI flags differ (D True,L False); results describe the variability of exported signals and do not establish intrinsic or instrumental stability. Actual renderer: Matplotlib.
'''
(O/'Figure_captions_EN.txt').write_text(captions)

checks=[]
for stem in ['01_Arginine_Target_Stability','02_Verapamil_Relative_Intensity']:
 for suffix in ['png','tiff']:
  with Image.open(O/f'{stem}_600dpi.{suffix}') as im:
   good=im.size==(4560,3480) and all(abs(float(v)-600)<.1 for v in im.info['dpi'])
   assert good;checks.append(dict(file=f'{stem}_600dpi.{suffix}',dpi600=True,pixels=list(im.size)))
 path=O/f'{stem}_vector.pdf'
 fonts=subprocess.run(['pdffonts',str(path)],capture_output=True,text=True,check=True).stdout
 images=subprocess.run(['pdfimages','-list',str(path)],capture_output=True,text=True,check=True).stdout
 assert 'Arial' in fonts and not images.splitlines()[2:]
 checks.append(dict(file=path.name,Arial_embedded=True,no_raster_images=True))
independent=json.loads((B/'review/independent_deliverable_validation.json').read_text())
assert independent['all_passed']
(O/'validation_results.json').write_text(json.dumps(dict(artifacts_pass=True,artifact_checks=checks,
 independent_statistical_review=independent),ensure_ascii=False,indent=2))

def writezip(name,entries):
 with zipfile.ZipFile(O/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for path,arc in entries:z.write(path,arc)
 with zipfile.ZipFile(O/name) as z:assert z.testzip() is None
 print(name,(O/name).stat().st_size,flush=True)
images=[(p,p.name) for p in sorted(O.iterdir()) if p.suffix in ['.png','.tiff','.pdf','.svg']]
writezip('ISO_D_L_Two_Figures.zip',images+[(O/'Figure_captions_EN.txt','Figure_captions_EN.txt')])
writezip('ISO_D_L_Two_PNG.zip',[(p,p.name) for p in sorted(O.glob('*_600dpi.png'))])
entries=[(p,p.name) for p in sorted(O.iterdir()) if p.is_file() and p.suffix!='.zip' and p.name!='files.json']
for folder in ['raw','review']:
 entries += [(p,'reproducibility/'+p.relative_to(B).as_posix()) for p in sorted((B/folder).rglob('*')) if p.is_file()]
for pattern in ['*.py','input_manifest.json','raw_metadata.json','requirements.txt','*.log']:
 entries += [(p,'reproducibility/'+p.name) for p in sorted(B.glob(pattern)) if p.is_file()]
writezip('ISO_D_L_Complete.zip',entries)
manifest=[dict(path=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 for p in sorted(O.iterdir()) if p.is_file() and p.name!='files.json']
(O/'files.json').write_text(json.dumps(dict(files=manifest,figure_count=2,style='boxplot and actual scatter'),indent=2))
print('COMPLETE: two new box/scatter figures, all data and provenance, archive CRC verified.')
