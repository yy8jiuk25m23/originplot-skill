from pathlib import Path
import zipfile,shutil,json,hashlib
B=Path(__file__).resolve().parent;O=B/'output'
for folder in ['origin']:
    shutil.copytree(B/folder,O/folder,dirs_exist_ok=True)

def build(name,entries):
    with zipfile.ZipFile(O/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for src,dest in entries:z.write(src,dest)
    with zipfile.ZipFile(O/name) as z:assert z.testzip() is None
    print(name,(O/name).stat().st_size,flush=True)

figentries=[(p,p.relative_to(O).as_posix()) for p in sorted((O/'figures').glob('*'))]
figentries += [(O/n,n) for n in ['Figure_captions_EN.txt','Figure_captions_ZH.txt','All_Figures_A_to_F_vector.pdf','All_Figures_A_to_F_preview.png','README.md']]
build('ICP_Sensitivity_Figures.zip',figentries)
pngentries=[(p,p.relative_to(O).as_posix()) for p in sorted((O/'figures').glob('*.png'))]+[(O/'All_Figures_A_to_F_preview.png','All_Figures_A_to_F_preview.png')]
build('ICP_Sensitivity_PNG.zip',pngentries)
build('ICP_Sensitivity_Excel_Tables.zip',[(p,p.name) for p in sorted(O.glob('*.xlsx'))]+[(O/'Analysis_report_ZH.md','Analysis_report_ZH.md')])
entries=[(p,p.relative_to(O).as_posix()) for p in sorted(O.rglob('*')) if p.is_file() and p.suffix!='.zip' and p.name!='files.json']
for folder in ['raw','review','logs']:
    entries += [(p,'reproducibility/'+p.relative_to(B).as_posix()) for p in sorted((B/folder).rglob('*')) if p.is_file()]
for pattern in ['*.py','*.json','requirements.txt']:
    entries += [(p,'reproducibility/'+p.name) for p in sorted(B.glob(pattern)) if p.is_file()]
prov=Path('/workspace/icp_chiral_20261121/font_setup/arial-package-provenance.json')
if prov.exists():entries.append((prov,'reproducibility/font_setup/arial-package-provenance.json'))
build('ICP_Sensitivity_Complete.zip',entries)
manifest=[]
for p in sorted(O.rglob('*')):
    if p.is_file() and p.name!='files.json':
        manifest.append(dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(O/'files.json').write_text(json.dumps(dict(files=manifest,native_OPJU_generated=False,all_downloads_verified_locally=True),ensure_ascii=False,indent=2))
print('COMPLETE: archives CRC checked and SHA256 manifest written.')
