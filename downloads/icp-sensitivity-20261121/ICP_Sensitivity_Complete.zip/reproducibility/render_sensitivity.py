from pathlib import Path
import os,json,hashlib
B=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(B/'mplconfig')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle,Patch
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.ticker import MultipleLocator
from PIL import Image,ImageOps,ImageDraw

O=B/'output';T=O/'data';F=O/'figures';F.mkdir(exist_ok=True)
font_path=Path('/workspace/icp_chiral_20261121/font_setup/Arial.ttf')
if not font_path.exists():font_path=B/'font_setup'/'Arial.ttf'
font_manager.fontManager.addfont(str(font_path))
assert font_manager.FontProperties(fname=font_path).get_name()=='Arial'
plt.rcParams.update({'font.family':'Arial','font.size':11,'axes.labelsize':12,'xtick.labelsize':10,
    'ytick.labelsize':10,'axes.linewidth':.8,'axes.edgecolor':'#333333','text.color':'#222222',
    'axes.labelcolor':'#222222','legend.frameon':False,'legend.fontsize':10,
    'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','path.simplify':False,
    'axes.unicode_minus':False,'savefig.facecolor':'white','figure.facecolor':'white',
    'mathtext.fontset':'custom','mathtext.rm':'Arial','mathtext.it':'Arial','mathtext.bf':'Arial',
    'mathtext.cal':'Arial','mathtext.sf':'Arial','mathtext.tt':'Arial'})
C={'D':'#2166AC','L':'#D73027'}
scans=pd.read_csv(T/'all70_original_peak_parameters.csv')
sen=pd.concat([pd.read_csv(T/f'{g}_sensitivity_k0_to10.csv') for g in ['D','L']])
full=pd.read_csv(T/'full35_group_statistics.csv').set_index('group')
combos=pd.read_csv(T/'all121_combinations.csv')
captions={}
records=[]
pdf=PdfPages(O/'All_Figures_A_to_F_vector.pdf',metadata={'Title':'ICP outlier screening and nested removal sensitivity',
    'Creator':'Matplotlib; Origin Skill data workflow; native Origin unavailable',
    'Subject':'All peak voltages use unverified provisional V=X*0.002 mV conversion'})

def base(letter,figsize=(8.8,5.4)):
    fig,ax=plt.subplots(figsize=figsize)
    fig.subplots_adjust(left=.12,right=.97,bottom=.17,top=.93)
    ax.text(-.10,1.045,letter,transform=ax.transAxes,fontweight='bold',fontsize=15,va='top')
    ax.tick_params(direction='out',length=4,width=.8)
    for spine in ax.spines.values():spine.set_visible(True)
    return fig,ax

def save(fig,stem,caption):
    fig.canvas.draw()
    fig.savefig(F/f'{stem}_600dpi.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
    fig.savefig(F/f'{stem}_preview.png',dpi=240)
    fig.savefig(F/f'{stem}_vector.pdf',metadata={'Creator':'Matplotlib','Subject':caption})
    fig.savefig(F/f'{stem}_editable.svg')
    pdf.savefig(fig)
    with Image.open(F/f'{stem}_600dpi.tiff') as im:
        assert all(abs(d-600)<.1 for d in im.info['dpi'])
        pixels=list(im.size)
    records.append(dict(figure=stem,size_inches=fig.get_size_inches().tolist(),TIFF_pixels=pixels,
                        TIFF_dpi=600,PNG_dpi=240,font='Arial',data_curves_smoothed=False,
                        vector_PDF=True,editable_SVG=True))
    captions[stem]=caption
    plt.close(fig)
    print('EXPORTED',stem,flush=True)

fig,ax=base('A')
for group in ['D','L']:
    s=scans[scans.group==group];normal=~s.candidate_either_threshold
    ax.scatter(s.loc[normal,'scan_number'],s.loc[normal,'peak_voltage_mV'],s=29,color=C[group],zorder=3)
    out=s[~normal]
    ax.scatter(out.scan_number,out.peak_voltage_mV,s=63,facecolors='white',edgecolors=C[group],linewidths=1.6,zorder=4)
    ax.axhline(full.loc[group,'mean_peak_mV'],color=C[group],lw=1.6,ls='--')
    ax.axhline(full.loc[group,'median_peak_mV'],color=C[group],lw=1.5,ls=':')
    for _,r in out.iterrows():
        txt=r.scan.upper()+(' (IQR + Z)' if r.modified_Z_candidate else ' (IQR)')
        ax.annotate(txt,(r.scan_number,r.peak_voltage_mV),xytext=(0,10),textcoords='offset points',
                    ha='center',fontsize=9,color=C[group])
ax.set(xlabel='Scan Number',ylabel='Peak Voltage (mV)',xlim=(0,36),ylim=(127.5,152.7))
ax.set_xticks([1,5,10,15,20,25,30,35])
ax.legend(handles=[Line2D([],[],color=C['D'],marker='o',ls='',label='D-Arginine'),
    Line2D([],[],color=C['L'],marker='o',ls='',label='L-Arginine'),
    Line2D([],[],color='#444444',ls='--',lw=1.6,label='Mean'),
    Line2D([],[],color='#444444',ls=':',lw=1.5,label='Median'),
    Line2D([],[],color='#444444',marker='o',markerfacecolor='white',ls='',label='Threshold candidate')],
    loc='upper center',ncol=5,fontsize=9,handletextpad=.5,columnspacing=1.1)
save(fig,'Figure_A_Original_Peak_Distribution',
    'All 35 raw, unaligned peak voltages per group. Dashed/dotted lines: mean/median. Hollow points: IQR or modified-Z candidates, not confirmed errors. D Y17/Y27: both; Y33: IQR only. L: none. Scan numbers are identifiers; acquisition chronology is unverified.')

fig,ax=base('B')
for group in ['D','L']:
    s=sen[sen.group==group]
    ax.errorbar(s.n_removed,s.mean_peak_mV,yerr=s.SD_mV,color=C[group],lw=1.8,marker='o',
                ms=4,capsize=3,elinewidth=1.3,capthick=1.2,label=f'{group}-Arginine')
ax.set(xlabel='Number of Removed Scans',ylabel='Mean Peak Voltage (mV)',xlim=(-.3,10.3))
ax.xaxis.set_major_locator(MultipleLocator(1));ax.legend(loc='center right')
save(fig,'Figure_B_Mean_Voltage_Sensitivity',
    'Retained mean peak voltages with sample SD error bars (not SEM or confidence intervals), k=0..10. Deletions follow the fixed full35-median absolute-deviation ranking. No smoothing, reranking or Delta-V optimization.')

fig,ax=base('C')
for group in ['D','L']:
    s=sen[sen.group==group]
    ax.plot(s.n_removed,s.SD_mV,color=C[group],lw=1.8,marker='o',ms=4,label=f'{group}-Arginine')
d3=sen[(sen.group=='D')&(sen.n_removed==3)].iloc[0]
ax.scatter([3],[d3.SD_mV],s=125,facecolors='none',edgecolors='#333333',lw=1.2,zorder=4)
ax.annotate('D: candidate boundary at k = 3\nPossible slope change; no confirmed plateau',
    xy=(3,d3.SD_mV),xytext=(3.8,2.30),fontsize=10,
    arrowprops=dict(arrowstyle='-',color='#555555',lw=.9))
ax.set(xlabel='Number of Removed Scans',ylabel='Standard Deviation (mV)',xlim=(-.3,10.3),ylim=(.8,2.8))
ax.xaxis.set_major_locator(MultipleLocator(1));ax.legend(loc='upper right')
save(fig,'Figure_C_SD_Sensitivity',
    'Sample SD after fixed-order trimming. D k=3 ends the three IQR candidates and shows a possible slope change, not a demonstrated stable plateau. SD keeps decreasing beyond k=3. No clear L elbow. Lower retained-data SD does not establish improved instrument repeatability.')

fig,ax=base('D')
for group in ['D','L']:
    s=sen[sen.group==group]
    ax.plot(s.n_removed,s.drift_range_mV,color=C[group],lw=1.8,marker='o',ms=4,label=f'{group}-Arginine')
ax.set(xlabel='Number of Removed Scans',ylabel='Peak Voltage Drift Range (mV)',xlim=(-.3,10.3),ylim=(2.5,12))
ax.xaxis.set_major_locator(MultipleLocator(1));ax.legend(loc='upper right')
save(fig,'Figure_D_Drift_Range_Sensitivity',
    'Observed peak-to-peak range=max(retained peak voltage)-min(retained peak voltage), for each nested removal count. Range reduction is a property of selection and is not evidence of improved hardware stability or a time-dependent drift model.')

fig,ax=base('E',figsize=(9.1,7.7))
fig.subplots_adjust(left=.13,right=.87,bottom=.17,top=.95)
z=combos.pivot(index='L_n_removed',columns='D_n_removed',values='delta_V_mV').to_numpy()
mesh=ax.pcolormesh(np.arange(12)-.5,np.arange(12)-.5,z,cmap='YlGnBu',shading='flat',
                   edgecolors='white',linewidth=.45,rasterized=False)
for row in range(11):
    for col in range(11):
        rgba=mesh.cmap(mesh.norm(z[row,col]));luma=.2126*rgba[0]+.7152*rgba[1]+.0722*rgba[2]
        ax.text(col,row,f'{z[row,col]:.3f}',ha='center',va='center',fontsize=8.4,
                color='white' if luma<.48 else '#222222')
# Full and recommended combinations coincide; display both outlines, never mark the maximum as optimal.
ax.add_patch(Rectangle((-.47,-.47),.94,.94,fill=False,edgecolor='black',lw=2.2,clip_on=False))
ax.add_patch(Rectangle((-.38,-.38),.76,.76,fill=False,edgecolor='#CC8A00',lw=1.8))
ax.set(xlabel='Number of Removed D-Arg Scans',ylabel='Number of Removed L-Arg Scans',
       xticks=np.arange(11),yticks=np.arange(11),xlim=(-.5,10.5),ylim=(-.5,10.5),aspect='equal')
cb=fig.colorbar(mesh,ax=ax,fraction=.045,pad=.025)
cb.solids.set_rasterized(False)
cb.set_label(r'Peak Voltage Difference, $\Delta V$ (mV)',fontsize=11)
ax.legend(handles=[Patch(facecolor='none',edgecolor='black',lw=2,label='Full data (0, 0)'),
    Patch(facecolor='none',edgecolor='#CC8A00',lw=1.8,label='Recommended (0, 0)')],
    loc='upper center',bbox_to_anchor=(.5,-.11),ncol=2,fontsize=10)
save(fig,'Figure_E_DeltaV_121_Combinations',
    'All 121 fixed nested D/L removal combinations. Each cell is the absolute difference of retained group means, rounded only for display to three decimals. Full data and primary recommendation coincide at (0,0), shown by two outlines. Larger Delta V is not an optimality criterion. No search over arbitrary subsets.')

fig,ax=base('F',figsize=(9.8,6.1))
fig.subplots_adjust(left=.11,right=.97,bottom=.23,top=.94)
pos={'D':[1,2],'L':[3.5,4.5]}
for group in ['D','L']:
    s=scans[scans.group==group].sort_values('scan_number');v=s.peak_voltage_mV.to_numpy()
    q1,q3=np.quantile(v,[.25,.75]);med=np.median(v)
    jitter=.15*np.sin(s.scan_number.to_numpy()*2.3999632297)
    for x in pos[group]:
        ax.boxplot([v],positions=[x],widths=.48,patch_artist=True,showfliers=False,manage_ticks=False,
            boxprops=dict(facecolor='white',edgecolor=C[group],lw=1.7),
            whiskerprops=dict(color=C[group],lw=1.5),capprops=dict(color=C[group],lw=1.5),
            medianprops=dict(color='#222222',lw=1.7),zorder=1)
        normal=~s.candidate_either_threshold.to_numpy()
        ax.scatter(x+jitter[normal],v[normal],s=23,color=C[group],alpha=.83,zorder=3)
        ax.scatter(x+jitter[~normal],v[~normal],s=41,facecolors='white',edgecolors=C[group],lw=1.3,zorder=4)
        ax.text(x,151.7,f'n = 35\nMedian = {med:.3f}\nIQR = {q3-q1:.3f}',ha='center',va='top',fontsize=9.5,color=C[group])
ax.set(xticks=[1,2,3.5,4.5],xticklabels=['D-Arg\nBefore filtering','D-Arg\nAfter filtering',
    'L-Arg\nBefore filtering','L-Arg\nAfter filtering'],ylabel='Peak Voltage (mV)',xlim=(.45,5.05),ylim=(127.5,153.5))
ax.tick_params(axis='x',length=0,pad=9)
ax.text(.5,-.24,'Primary recommendation: remove 0 scans in each group.\nBefore and after contain the same observations.',
    transform=ax.transAxes,ha='center',fontsize=10)
save(fig,'Figure_F_Before_After_Recommended',
    'Boxplots plus every actual peak-voltage observation. Primary D0/L0 recommendation retains all scans; before/after are the same observations shown twice for comparison, not new measurements. Boxes Q1-Q3; center line median; whiskers extend to observed values within 1.5 IQR; all points displayed separately. Hollow points are statistical candidates retained in primary analysis. Deterministic horizontal display offsets do not alter voltage values. Labels report n, median, IQR in mV.')
pdf.close()
provisional='All panels use provisional, unverified V_AC (mV)=X*0.002; no instrument calibration was found. All statistics use original, unaligned peak positions. No smoothing or fitting. Actual renderer: Matplotlib; native Origin OPJU not generated.'
(O/'Figure_captions_EN.txt').write_text('\n\n'.join(f'{k}\n{v}' for k,v in captions.items())+'\n\n'+provisional)
(O/'rendering_record.json').write_text(json.dumps(dict(actual_renderer='Matplotlib',native_Origin=False,
    font_family='Arial',font_SHA256=hashlib.sha256(font_path.read_bytes()).hexdigest(),colors=C,
    figures=records,full_and_recommended_heatmap_cell=[0,0],heatmap_cell_annotations=121,
    Figure_F_actual_observations_per_box=35,Figure_F_before_after_identical_by_recommendation=True,
    no_smoothing=True,voltage_conversion_verified=False),indent=2))
# A convenient, non-publication contact sheet; individual figures retain full resolution.
thumbs=[]
for r in records:
    with Image.open(F/f"{r['figure']}_preview.png") as im:
        im=im.convert('RGB'); im.thumbnail((1120,880))
        tile=Image.new('RGB',(1160,920),'white');tile.paste(im,((1160-im.width)//2,(920-im.height)//2));thumbs.append(tile)
sheet=Image.new('RGB',(2320,2760),'white')
for i,tile in enumerate(thumbs):sheet.paste(tile,((i%2)*1160,(i//2)*920))
sheet.save(O/'All_Figures_A_to_F_preview.png',dpi=(200,200))
print('COMPLETE: six TIFF 600dpi + PNG + vectorPDF + editable SVG; Arial embedded in PDF; 121 heatmap labels.')
