"""Raw, unaligned peak extraction and fixed-ranking nested sensitivity analysis."""
from pathlib import Path
import json, hashlib, platform
import numpy as np
import pandas as pd

B=Path(__file__).resolve().parent
O=B/'output'; T=O/'data'; T.mkdir(parents=True,exist_ok=True)
SCALE=.002

def peak_metrics(x,y):
    finite=np.isfinite(x)&np.isfinite(y)
    if not finite.any() or np.max(y[finite])<=0:
        raise ValueError('Unusable curve: no finite positive maximum')
    imax=float(np.max(y[finite])); p=int(np.flatnonzero(finite)[np.argmax(y[finite])])
    ties=np.flatnonzero(finite&(y==imax))
    left=right=p; half=imax/2
    while left>0 and finite[left-1] and y[left-1]>=half: left-=1
    while right<len(y)-1 and finite[right+1] and y[right+1]>=half: right+=1
    lc=rc=np.nan
    if left>0 and finite[left-1] and y[left-1]<half:
        lc=float(x[left-1]+(half-y[left-1])*(x[left]-x[left-1])/(y[left]-y[left-1]))
    if right<len(y)-1 and finite[right+1] and y[right+1]<half:
        rc=float(x[right]+(half-y[right])*(x[right+1]-x[right])/(y[right+1]-y[right]))
    flags=[]
    if not finite.all(): flags.append('missing_values')
    if len(ties)>1: flags.append('tied_global_maximum')
    if p in [0,len(y)-1]: flags.append('maximum_at_boundary')
    if not np.isfinite(lc+rc): flags.append('incomplete_FWHM')
    above=finite&(y>=half)
    return dict(peak_index_0based=p,peak_X=float(x[p]),peak_voltage_mV=float(x[p]*SCALE),
                I_max_raw=imax,peak_max_tie_count=len(ties),valid_numeric_points=int(finite.sum()),
                left_half_X=lc,right_half_X=rc,left_half_mV=lc*SCALE,right_half_mV=rc*SCALE,
                FWHM_X=rc-lc,FWHM_mV=(rc-lc)*SCALE,
                half_height_component_count=int(np.count_nonzero(above&~np.r_[False,above[:-1]])),
                acquisition_flags=';'.join(flags),FWHM_complete=bool(np.isfinite(lc+rc)))

def stats(df):
    v=df.peak_voltage_mV.to_numpy(); q1,q3=np.quantile(v,[.25,.75],method='linear')
    mean=float(v.mean());sd=float(v.std(ddof=1));median=float(np.median(v))
    return dict(n_retained=len(v),retention_percent=100*len(v)/35,
                mean_peak_mV=mean,median_peak_mV=median,SD_mV=sd,
                MAD_mV=float(np.median(abs(v-median))),Q1_mV=float(q1),Q3_mV=float(q3),
                IQR_mV=float(q3-q1),RSD_percent=100*sd/abs(mean),
                min_peak_mV=float(v.min()),max_peak_mV=float(v.max()),drift_range_mV=float(np.ptp(v)),
                mean_FWHM_mV=float(df.FWHM_mV.mean()),SD_FWHM_mV=float(df.FWHM_mV.std(ddof=1)))

metadata=json.loads((B/'raw_metadata.json').read_text())
rows=[]; sha_checks=[]
for group in ['D','L']:
    source=next(m for m in metadata if m['sample']==group)
    rawfile=B/'raw'/source['file']
    actual=hashlib.sha256(rawfile.read_bytes()).hexdigest()
    assert actual==source['sha256']
    attached=Path(source['path'])
    if attached.exists(): assert hashlib.sha256(attached.read_bytes()).hexdigest()==actual
    sha_checks.append(dict(sample=group,file=source['file'],sha256=actual))
    a=np.load(B/f'{group}_raw_arrays.npz'); data=a['data']; headers=a['headers'].tolist()
    x=data[:,0]; raw=data[:,1:]; assert data.shape==(150000,36)
    assert np.array_equal(x,np.arange(150000)) and np.isfinite(data).all()
    normalized=raw/raw.max(axis=0)
    assert np.array_equal(normalized.max(axis=0),np.ones(35))
    for j,name in enumerate(headers[1:]):
        metrics=peak_metrics(x,raw[:,j]); check=peak_metrics(x,normalized[:,j])
        assert check['peak_X']==metrics['peak_X']
        assert np.isclose(check['FWHM_X'],metrics['FWHM_X'],rtol=1e-10)
        rows.append(dict(group=group,sample=f'{group}-Arginine',scan=name,scan_number=j+1,
                         source_file=source['file'],included_full_data=True,**metrics))
    # Lossless arrays preserve all samples. No coordinates are aligned or interpolated.
    np.savez_compressed(T/f'{group}_raw_and_normalized_all35.npz',X=x,V_mV_assumed=x*SCALE,
                        I_raw=raw,I_normalized=normalized,scan_names=np.array(headers[1:]))

rawtable=pd.DataFrame(rows); ranked=[]; full=[]; sensitivity=[]; members=[]; thresholds=[]
kept_frames={}; method_rows=[]
for group in ['D','L']:
    df=rawtable[rawtable.group==group].copy().reset_index(drop=True)
    s0=stats(df); med=s0['median_peak_mV'];mad=s0['MAD_mV'];iqr=s0['IQR_mV']
    lower=s0['Q1_mV']-1.5*iqr; upper=s0['Q3_mV']+1.5*iqr
    df['absolute_deviation_from_full_median_mV']=abs(df.peak_voltage_mV-med)
    df['full35_median_peak_mV']=med;df['full35_MAD_mV']=mad
    df['IQR_lower_mV']=lower;df['IQR_upper_mV']=upper
    df['IQR_candidate']=(df.peak_voltage_mV<lower)|(df.peak_voltage_mV>upper)
    df['modified_Z']=.6745*(df.peak_voltage_mV-med)/mad if mad else np.nan
    df['modified_Z_candidate']=abs(df.modified_Z)>3.5 if mad else False
    df['modified_Z_applicable']=mad!=0
    df=df.sort_values(['absolute_deviation_from_full_median_mV','scan_number'],ascending=[False,True])
    df['fixed_removal_rank']=np.arange(1,36)
    df['candidate_either_threshold']=df.IQR_candidate|df.modified_Z_candidate
    df['candidate_both_thresholds']=df.IQR_candidate&df.modified_Z_candidate
    ranked.append(df)
    full.append(dict(group=group,**s0,IQR_lower_mV=lower,IQR_upper_mV=upper,
                     n_IQR_candidates=int(df.IQR_candidate.sum()),n_modified_Z_candidates=int(df.modified_Z_candidate.sum())))
    thresholds.append(dict(group=group,reference_n=35,median_mV=med,MAD_mV=mad,Q1_mV=s0['Q1_mV'],
                           Q3_mV=s0['Q3_mV'],IQR_mV=iqr,lower_mV=lower,upper_mV=upper,
                           modified_Z_constant=.6745,modified_Z_threshold_strictly_greater=3.5))
    for method,flag in [('B_IQR','IQR_candidate'),('C_Modified_Z','modified_Z_candidate')]:
        scans=df.loc[df[flag],'scan'].tolist()
        method_rows.append(dict(group=group,method=method,n_candidates=len(scans),candidate_scans=';'.join(scans),
                                interpretation='Statistical candidates only; not proof of acquisition error'))
    method_rows.append(dict(group=group,method='A_Absolute_deviation_ranking',n_candidates=np.nan,
                            candidate_scans=';'.join(df.scan),
                            interpretation='Ranking only; no anomaly cutoff. First k are hypothetical deletions, not automatically outliers.'))
    previous=None
    for k in range(11):
        kept=df.iloc[k:].sort_values('scan_number'); removed=df.iloc[:k]; s=stats(kept)
        kept_frames[group,k]=kept
        sensitivity.append(dict(group=group,n_removed=k,**s,
            mean_shift_from_full_mV=s['mean_peak_mV']-s0['mean_peak_mV'],
            abs_mean_shift_from_full_mV=abs(s['mean_peak_mV']-s0['mean_peak_mV']),
            mean_change_from_previous_mV=s['mean_peak_mV']-previous['mean_peak_mV'] if previous else np.nan,
            abs_mean_change_from_previous_mV=abs(s['mean_peak_mV']-previous['mean_peak_mV']) if previous else np.nan,
            SD_reduction_from_full_percent=100*(s0['SD_mV']-s['SD_mV'])/s0['SD_mV'],
            SD_decrease_from_previous_mV=previous['SD_mV']-s['SD_mV'] if previous else np.nan,
            SD_decrease_from_previous_percent=100*(previous['SD_mV']-s['SD_mV'])/previous['SD_mV'] if previous else np.nan,
            removed_scans_in_fixed_order=';'.join(removed.scan),retained_scans=';'.join(kept.scan),
            newly_removed_scan=removed.scan.iloc[-1] if k else '',meets_90percent_preference=s['retention_percent']>=90,
            recommended=(k==0)))
        for _,r in df.iterrows():
            members.append(dict(group=group,n_removed=k,scan=r.scan,scan_number=int(r.scan_number),
                                fixed_removal_rank=int(r.fixed_removal_rank),
                                retained=bool(r.fixed_removal_rank>k),
                                peak_voltage_mV=r.peak_voltage_mV,FWHM_mV=r.FWHM_mV,
                                IQR_candidate=bool(r.IQR_candidate),modified_Z_candidate=bool(r.modified_Z_candidate)))
        previous=s

scans=pd.concat(ranked).sort_values(['group','scan_number']).reset_index(drop=True)
sen=pd.DataFrame(sensitivity);full=pd.DataFrame(full);membership=pd.DataFrame(members)
baseline_delta=abs(full.set_index('group').loc['L','mean_peak_mV']-full.set_index('group').loc['D','mean_peak_mV'])
combos=[]
for kd in range(11):
    d=sen[(sen.group=='D')&(sen.n_removed==kd)].iloc[0]
    for kl in range(11):
        l=sen[(sen.group=='L')&(sen.n_removed==kl)].iloc[0]
        overlap_low=max(d.min_peak_mV,l.min_peak_mV);overlap_high=min(d.max_peak_mV,l.max_peak_mV)
        delta=abs(l.mean_peak_mV-d.mean_peak_mV)
        combos.append(dict(D_n_removed=kd,L_n_removed=kl,D_n_retained=int(d.n_retained),L_n_retained=int(l.n_retained),
            D_retention_percent=d.retention_percent,L_retention_percent=l.retention_percent,
            D_mean_peak_mV=d.mean_peak_mV,D_SD_mV=d.SD_mV,L_mean_peak_mV=l.mean_peak_mV,L_SD_mV=l.SD_mV,
            delta_V_mV=delta,delta_change_from_full_mV=delta-baseline_delta,
            D_min_peak_mV=d.min_peak_mV,D_max_peak_mV=d.max_peak_mV,L_min_peak_mV=l.min_peak_mV,L_max_peak_mV=l.max_peak_mV,
            observed_ranges_overlap=bool(overlap_low<=overlap_high),observed_overlap_width_mV=max(0,overlap_high-overlap_low),
            signed_L_min_minus_D_max_mV=l.min_peak_mV-d.max_peak_mV,
            D_mean_FWHM_mV=d.mean_FWHM_mV,L_mean_FWHM_mV=l.mean_FWHM_mV,
            D_removed_scans=d.removed_scans_in_fixed_order,L_removed_scans=l.removed_scans_in_fixed_order,
            D_retained_scans=d.retained_scans,L_retained_scans=l.retained_scans,
            recommended=(kd==0 and kl==0),full_data=(kd==0 and kl==0)))
combos=pd.DataFrame(combos)

compare=[]
for label,kd,kl,primary in [('Full_data',0,0,False),('Recommended_keep_all',0,0,True),
                           ('Sensitivity_D_IQR_candidates',3,0,False),('Sensitivity_D_ModifiedZ_candidates',2,0,False)]:
    r=combos[(combos.D_n_removed==kd)&(combos.L_n_removed==kl)].iloc[0].to_dict()
    r.update(scenario=label,primary_recommendation=primary)
    for group,k in [('D',kd),('L',kl)]:
        s=sen[(sen.group==group)&(sen.n_removed==k)].iloc[0]
        for key in ['mean_shift_from_full_mV','SD_reduction_from_full_percent','median_peak_mV','drift_range_mV']:
            r[f'{group}_{key}']=s[key]
    compare.append(r)
compare=pd.DataFrame(compare)

files={'all70_original_peak_parameters.csv':scans,'full35_group_statistics.csv':full,
       'outlier_method_comparison.csv':pd.DataFrame(method_rows),'outlier_thresholds_fixed_full35.csv':pd.DataFrame(thresholds),
       'D_sensitivity_k0_to10.csv':sen[sen.group=='D'],'L_sensitivity_k0_to10.csv':sen[sen.group=='L'],
       'all_scheme_membership_770rows.csv':membership,'all121_combinations.csv':combos,
       'recommended_vs_full_and_candidate_scenarios.csv':compare}
for name,df in files.items():df.to_csv(T/name,index=False,float_format='%.15g')
matrix=combos.pivot(index='L_n_removed',columns='D_n_removed',values='delta_V_mV')
matrix.to_csv(T/'Figure_E_heatmap_matrix.csv',float_format='%.15g')
scans[['group','scan','scan_number','peak_voltage_mV','IQR_candidate','modified_Z_candidate','candidate_either_threshold']].to_csv(T/'Figure_A_points.csv',index=False,float_format='%.15g')
frows=[]
for group in ['D','L']:
    for stage in ['Before filtering','After filtering']:
        for _,r in kept_frames[group,0].iterrows():
            frows.append(dict(group=group,stage=stage,scan=r.scan,scan_number=r.scan_number,peak_voltage_mV=r.peak_voltage_mV,
                              candidate_either_threshold=bool(r.candidate_either_threshold),n_removed=0))
pd.DataFrame(frows).to_csv(T/'Figure_F_points_recommended_k0.csv',index=False,float_format='%.15g')

methods=[
 ('Source','D-.86.xlsx and L-.86.xlsx; 150000 rows, X=0..149999; 35 scans each; originals unchanged.'),
 ('Voltage','PROVISIONAL, UNVERIFIED: V_AC (mV)=X*0.002. No instrument calibration metadata found.'),
 ('Extraction','Global maximum of each unaligned raw curve. No smoothing, fitting, peak alignment or baseline subtraction.'),
 ('Normalization','I/Imax per scan. Exact normalization preserves maximum coordinates and FWHM.'),
 ('FWHM','Closest half-maximum crossings enclosing global maximum; linear interpolation of crossing positions only, not signal reconstruction.'),
 ('SD','Sample SD, ddof=1. RSD=100*sample SD/abs(mean).'),
 ('MAD','Unscaled median absolute deviation from full35 median. Modified Z=0.6745*(V-median)/MAD; abs(Z)>3.5.'),
 ('IQR','NumPy linear quantile interpolation. Strict outside Q1-1.5*IQR, Q3+1.5*IQR. Fixed full35 thresholds.'),
 ('Method A','Fixed descending absolute deviations from ORIGINAL full35 median; ties resolved by original scan number. No cutoff specified: ranking is not an outlier classification.'),
 ('Nesting','Same fixed order for k=0..10. Do not rerank or recompute anomaly thresholds after removal.'),
 ('Overlap','Intersection of observed retained min-max peak-voltage intervals, including endpoints. This is not a probability-distribution or confidence-interval overlap test.'),
 ('Recommendation','D0/L0: retain all70 as primary. D3/L0 and D2/L0 are sensitivity scenarios, not proven acquisition failures.'),
 ('Rationale','D has threshold candidates but no confirmed acquisition errors; no established stability plateau or instrument tolerance. L has no IQR/modified-Z candidates.'),
 ('Selection bias','Trimming centralizes retained data by design. Lower post-filter SD does not demonstrate improved instrument repeatability; Delta V is not an optimization objective.'),
 ('Scan index','Y1..Y35 are curve numbers. Their acquisition chronology and independence are unverified; no inferential p-values or temporal-drift claims are made.'),
 ('Renderer','Actual figures rendered using Matplotlib; Origin Windows runtime unavailable; no native OPJU generated.')]
methoddf=pd.DataFrame(methods,columns=['item','definition'])

def write_book(path,sheets):
    with pd.ExcelWriter(path,engine='openpyxl') as writer:
        for name,df in {'Methods':methoddf,**sheets}.items():
            df.to_excel(writer,sheet_name=name,index=False)
            ws=writer.sheets[name];ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
            from openpyxl.styles import Font,PatternFill,Alignment
            for c in ws[1]:c.font=Font(name='Arial',bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='264A60')
            for col in ws.columns:
                width=max(len(str(c.value or '')) for c in list(col)[:150])+2
                ws.column_dimensions[col[0].column_letter].width=min(max(width,13),60)
                for c in list(col)[1:]:
                    c.font=Font(name='Arial',size=10)
                    if isinstance(c.value,float):c.number_format='0.000000'
    return path

write_book(O/'01_Original35_PeakParameters.xlsx',{'All70':scans,'D_original35':scans[scans.group=='D'],
    'L_original35':scans[scans.group=='L'],'Group_statistics':full,'Thresholds':pd.DataFrame(thresholds),
    'Method_comparison':pd.DataFrame(method_rows),'D_fixed_ranking':scans[scans.group=='D'].sort_values('fixed_removal_rank'),
    'L_fixed_ranking':scans[scans.group=='L'].sort_values('fixed_removal_rank'),'Raw_SHA256':pd.DataFrame(sha_checks)})
write_book(O/'02_D_L_Removal_Sensitivity.xlsx',{'D_k0_to10':sen[sen.group=='D'],'L_k0_to10':sen[sen.group=='L'],
    'All_scheme_membership':membership,'Fixed_order':scans.sort_values(['group','fixed_removal_rank'])})
write_book(O/'03_All121_Removal_Combinations.xlsx',{'Combinations121':combos,'DeltaV_matrix':matrix.reset_index(),
    'D_scheme_membership':membership[membership.group=='D'],'L_scheme_membership':membership[membership.group=='L']})
write_book(O/'04_Recommendation_vs_Full.xlsx',{'Scenario_comparison':compare,'Recommended_all70':scans,
    'Candidates_not_deleted':scans[scans.candidate_either_threshold]})
write_book(O/'ICP_Sensitivity_All_Results.xlsx',{'Original70':scans,'Full_statistics':full,
    'D_sensitivity':sen[sen.group=='D'],'L_sensitivity':sen[sen.group=='L'],'Combinations121':combos,
    'Scheme_membership':membership,'Recommendation':compare,'Thresholds':pd.DataFrame(thresholds),
    'Method_comparison':pd.DataFrame(method_rows)})

record=dict(voltage_mapping=dict(mV_per_X=SCALE,offset_mV=0,verified_instrument_calibration=False),
            original_checksums=sha_checks,normalization='Per-scan I/Imax; no smoothing/fitting/alignment',
            valid_scans=70,removed_from_primary=0,primary_recommendation={'D':0,'L':0},
            D_IQR_candidates=scans.loc[(scans.group=='D')&scans.IQR_candidate,'scan'].tolist(),
            D_modified_Z_candidates=scans.loc[(scans.group=='D')&scans.modified_Z_candidate,'scan'].tolist(),
            L_IQR_candidates=[],L_modified_Z_candidates=[],
            secondary_scenario={'D':3,'L':0,'interpretation':'Sensitivity only; no confirmed acquisition failure'},
            baseline_delta_V_mV=float(baseline_delta),overlap_definition=methods[10][1],methods=dict(methods),
            method_A_has_no_cutoff=True,thresholds_computed_once_from_full35=True,
            ties='Smaller original scan number first',SD_ddof=1,quantile_method='linear',
            recommendation_basis='No confirmed acquisition faults; D k3 slope change is not a stable plateau; L has no threshold candidates. Preserve full data as primary.',
            native_Origin_available=False,OPJU_generated=False,actual_renderer='Matplotlib',
            software={'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__})
(O/'processing_record.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
(O/'raw_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
assert len(scans)==70 and len(sen)==22 and len(combos)==121 and len(membership)==770
assert not scans.acquisition_flags.str.len().any()
assert (combos.recommended.sum(),combos.full_data.sum())==(1,1)
print(full.to_string(index=False))
print(compare[['scenario','D_n_removed','L_n_removed','D_mean_peak_mV','D_SD_mV','L_mean_peak_mV','L_SD_mV','delta_V_mV','delta_change_from_full_mV']].to_string(index=False))
print('COMPLETE: raw unaligned peaks; 70 scans; 22 nested schemes; 121 combinations; 770 membership decisions. Primary D0/L0.')
