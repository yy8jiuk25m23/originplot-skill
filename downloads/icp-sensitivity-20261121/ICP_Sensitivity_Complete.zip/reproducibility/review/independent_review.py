"""Independent calculation from complete raw arrays; never alters raw data."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
BASE=Path('/workspace/icp_chiral_20261121')
OUT=Path(__file__).resolve().parent
src=pd.read_csv(BASE/'output/all_70_scan_peak_statistics.csv')
res={'voltage_assumption_mV_per_X':0.002,'verified_instrument_calibration':False,'sd_convention':'sample SD, ddof=1','quantile_convention':'NumPy quantile, method=linear','fixed_ranking_tie_breaker':'ascending scan number','method_A_threshold':None,'method_A_note':'Ranks all scans by absolute deviation from original 35-scan median. Ranking alone does not label any scan an outlier.','groups':{},'recommendation':{'D_removed_count':0,'L_removed_count':0,'reason':'Statistical flags do not establish acquisition error; no clearly sustained plateau is established over k=0..10; all original scans remain usable. Preserve all data for primary analysis and report nested trimming only as sensitivity analysis.','secondary_scenario':{'D_removed_count':3,'D_removed_scans':['y27','y17','y33'],'L_removed_count':0,'label':'IQR-supported candidate-exclusion sensitivity scenario, not recommended primary removal'}}}
arrays={};profiles={}
for g in ['D','L']:
    a=np.load(BASE/f'{g}_raw_arrays.npz');x=a['data'][:,0];Y=a['data'][:,1:];names=a['headers'].tolist()[1:]
    peaks=x[np.argmax(Y,axis=0)]*.002
    rawsd=np.std(peaks,ddof=1);rawmean=np.mean(peaks)
    med=np.median(peaks);dev=np.abs(peaks-med);mad=np.median(dev);q1,q3=np.quantile(peaks,[.25,.75]);iqr=q3-q1
    order=np.lexsort((np.arange(len(peaks)), -dev));z=.6745*(peaks-med)/mad if mad else np.full(len(peaks),np.nan)
    iqrflag=(peaks<q1-1.5*iqr)|(peaks>q3+1.5*iqr);zflag=np.abs(z)>3.5
    compare=src.loc[src['sample']==g].sort_values('scan_number')
    assert np.allclose(peaks,compare['peak_mV_assumed'].to_numpy(),rtol=0,atol=1e-12)
    widths=[]
    # Independent global-peak enclosing contiguous half-height component widths.
    for j in range(Y.shape[1]):
        y=Y[:,j];p=int(np.argmax(y));h=y[p]/2
        below=np.flatnonzero(y<h)
        l=int(below[below<p][-1]);r=int(below[below>p][0])
        lx=x[l]+(h-y[l])/(y[l+1]-y[l])*(x[l+1]-x[l])
        rx=x[r-1]+(h-y[r-1])/(y[r]-y[r-1])*(x[r]-x[r-1])
        widths.append((rx-lx)*.002)
    widths=np.array(widths)
    assert np.allclose(widths,compare['FWHM_mV_assumed'].to_numpy(),rtol=0,atol=1e-12)
    assert np.all(np.isfinite(Y)) and np.all(np.max(Y,axis=0)>0)
    norms=Y/np.max(Y,axis=0)
    assert np.all(np.max(norms,axis=0)==1)
    ss=[];last=rawmean
    for k in range(11):
        keep=np.ones(len(peaks),dtype=bool);keep[order[:k]]=False
        v=peaks[keep];mean=np.mean(v);sd=np.std(v,ddof=1)
        row={'removed_count':k,'n_retained':int(keep.sum()),'retention_percent':float(keep.mean()*100),'mean_mV':float(mean),'median_mV':float(np.median(v)),'SD_mV':float(sd),'RSD_percent':float(sd/mean*100),'drift_mV':float(np.ptp(v)),'mean_FWHM_mV':float(np.mean(widths[keep])),'mean_shift_from_full_mV':float(mean-rawmean),'mean_step_mV':None if k==0 else float(mean-last),'SD_reduction_percent':float((rawsd-sd)/rawsd*100),'removed_scans':[names[j] for j in order[:k]],'retained_scans':[names[j] for j in range(len(peaks)) if keep[j]],'min_peak_mV':float(v.min()),'max_peak_mV':float(v.max())}
        ss.append(row);last=mean
    res['groups'][g]={'n':len(peaks),'median_mV':float(med),'MAD_mV':float(mad),'Q1_mV':float(q1),'Q3_mV':float(q3),'IQR_mV':float(iqr),'IQR_lower_mV':float(q1-1.5*iqr),'IQR_upper_mV':float(q3+1.5*iqr),'IQR_candidates':[names[j] for j in np.flatnonzero(iqrflag)],'modified_z_candidates':[names[j] for j in np.flatnonzero(zflag)],'fixed_order':[names[j] for j in order],'scan_metrics':[{'scan':names[j],'peak_mV':float(peaks[j]),'FWHM_mV':float(widths[j]),'deviation_mV':float(dev[j]),'modified_z':float(z[j]),'IQR_candidate':bool(iqrflag[j]),'modified_z_candidate':bool(zflag[j])} for j in range(len(peaks))],'sensitivity':ss}
    profiles[g]=ss
rows=[];base=abs(profiles['L'][0]['mean_mV']-profiles['D'][0]['mean_mV'])
for d in profiles['D']:
    for l in profiles['L']:
        delta=abs(l['mean_mV']-d['mean_mV'])
        lo=max(d['min_peak_mV'],l['min_peak_mV']);hi=min(d['max_peak_mV'],l['max_peak_mV'])
        rows.append({'D_removed_count':d['removed_count'],'L_removed_count':l['removed_count'],'delta_V_mV':delta,'delta_change_from_full_mV':delta-base,'observed_minmax_ranges_overlap':bool(lo<=hi),'observed_range_gap_mV':float(max(0,lo-hi))})
res['combinations']=rows
res['checks']={'all_70_peaks_match_previous_raw_extraction':True,'all_70_FWHM_match_independent_raw_intersections':True,'normalization_maxima_exactly_one':True,'all_raw_observations_finite':True,'all_121_observed_minmax_ranges_nonoverlapping':all(not r['observed_minmax_ranges_overlap'] for r in rows),'observed_range_overlap_note':'Finite-sample observed min-max interval overlap only; does not prove underlying population distributions do not overlap.'}
res['key_secondary_D3_L0']={**next(r for r in rows if r['D_removed_count']==3 and r['L_removed_count']==0),'D':profiles['D'][3],'L':profiles['L'][0]}
(OUT/'independent_review_results.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
pd.DataFrame(rows).to_csv(OUT/'independent_121_combinations.csv',index=False)
for g in ['D','L']:pd.DataFrame(profiles[g]).to_csv(OUT/f'independent_{g}_sensitivity.csv',index=False)
print(json.dumps({g:{'mean':profiles[g][0]['mean_mV'],'SD':profiles[g][0]['SD_mV'],'drift':profiles[g][0]['drift_mV'],'D3_if_D_or_L0':profiles[g][3 if g=='D' else 0]} for g in profiles},ensure_ascii=False,indent=2))
print('delta full',base,'D3L0',res['key_secondary_D3_L0']['delta_V_mV'])
print('all combinations delta range',min(r['delta_V_mV'] for r in rows),max(r['delta_V_mV'] for r in rows))
