"""Independent QA: raw arrays -> all reported parameter, scenario and membership rows."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from openpyxl import load_workbook
B=Path('/workspace/icp_sensitivity_20261121');P=B/'output';T=P/'data';R=Path(__file__).resolve().parent
checks=[];numeric_errors=[]
def ck(name,passed,details=None):
    checks.append(dict(check=name,passed=bool(passed),**({'details':details} if details is not None else {})))
def num(name,actual,expected):
    a=np.asarray(actual,dtype=float);e=np.asarray(expected,dtype=float)
    delta=np.abs(a-e);finite=np.isfinite(delta)
    err=float(delta[finite].max()) if finite.any() else 0.
    numeric_errors.append(err);ck(name,np.allclose(a,e,atol=1e-10,rtol=1e-12,equal_nan=True),{'max_absolute_error':err})
def textv(v): return '' if pd.isna(v) else str(v)
scans=pd.read_csv(T/'all70_original_peak_parameters.csv');sens={};arrays={};original={}
ck('70 original scan rows, unique group and scan identities',len(scans)==70 and not scans[['group','scan']].duplicated().any())
for g in ['D','L']:
    a=np.load(B/f'{g}_raw_arrays.npz');d=a['data'];x=d[:,0];Y=d[:,1:]
    names=a['headers'].tolist()[1:];v=x[np.argmax(Y,axis=0)]*.002
    halfwidth=[];left=[];right=[]
    for j in range(35):
        y=Y[:,j];peak=int(np.argmax(y));h=y[peak]/2;below=np.flatnonzero(y<h)
        lo=int(below[below<peak][-1]);hi=int(below[below>peak][0])
        lc=x[lo]+(h-y[lo])/(y[lo+1]-y[lo])*(x[lo+1]-x[lo]);rc=x[hi-1]+(h-y[hi-1])/(y[hi]-y[hi-1])*(x[hi]-x[hi-1]);left.append(lc);right.append(rc);halfwidth.append((rc-lc)*.002)
    widths=np.asarray(halfwidth);med=np.median(v);dev=abs(v-med);mad=np.median(dev);q1,q3=np.quantile(v,[.25,.75]);iqr=q3-q1
    order=np.lexsort((np.arange(35),-dev));rank=np.empty(35,int);rank[order]=np.arange(1,36)
    z=.6745*(v-med)/mad;flagI=(v<q1-1.5*iqr)|(v>q3+1.5*iqr);flagZ=abs(z)>3.5
    s=scans[scans.group==g].sort_values('scan_number')
    ck(g+' scan naming and numbering',s.scan.tolist()==names and s.scan_number.tolist()==list(range(1,36)))
    ck(g+' all raw cells finite, X exactly 0..149999',np.isfinite(d).all() and np.array_equal(x,np.arange(150000)))
    num(g+' raw global peak indexes',s.peak_index_0based,np.argmax(Y,axis=0));num(g+' raw global peak X',s.peak_X,x[np.argmax(Y,axis=0)])
    num(g+' unaligned peak voltages',s.peak_voltage_mV,v);num(g+' raw Imax',s.I_max_raw,Y.max(axis=0));num(g+' FWHM mV',s.FWHM_mV,widths)
    num(g+' raw left half crossing',s.left_half_X,left);num(g+' raw right half crossing',s.right_half_X,right)
    num(g+' FWHM X',s.FWHM_X,np.asarray(right)-np.asarray(left));num(g+' left half voltage',s.left_half_mV,np.asarray(left)*.002);num(g+' right half voltage',s.right_half_mV,np.asarray(right)*.002)
    num(g+' absolute deviations from ORIGINAL median',s.absolute_deviation_from_full_median_mV,dev)
    num(g+' original median fixed on every row',s.full35_median_peak_mV,np.repeat(med,35));num(g+' original MAD fixed on every row',s.full35_MAD_mV,np.repeat(mad,35))
    num(g+' fixed IQR lower bounds',s.IQR_lower_mV,np.repeat(q1-1.5*iqr,35));num(g+' fixed IQR upper bounds',s.IQR_upper_mV,np.repeat(q3+1.5*iqr,35))
    num(g+' modified Z-scores',s.modified_Z,z)
    ck(g+' strict IQR candidate flags',np.array_equal(s.IQR_candidate,flagI));ck(g+' strict abs(modified Z)>3.5 flags',np.array_equal(s.modified_Z_candidate,flagZ))
    ck(g+' candidate union/intersection',np.array_equal(s.candidate_either_threshold,flagI|flagZ) and np.array_equal(s.candidate_both_thresholds,flagI&flagZ))
    ck(g+' fixed full35 median removal ranks',np.array_equal(s.fixed_removal_rank,rank))
    ck(g+' all included, complete widths, unique maxima, no acquisition flags',s.included_full_data.all() and s.FWHM_complete.all() and (s.peak_max_tie_count==1).all() and (s.valid_numeric_points==150000).all() and s.acquisition_flags.fillna('').eq('').all())
    n=np.load(T/f'{g}_raw_and_normalized_all35.npz')
    ck(g+' archived raw arrays unchanged',np.array_equal(n['I_raw'],Y) and np.array_equal(n['X'],x))
    num(g+' archived voltage mapping',n['V_mV_assumed'],x*.002)
    ck(g+' all normalized raw samples exactly I/Imax and max1',np.array_equal(n['I_normalized'],Y/Y.max(axis=0)) and np.array_equal(n['I_normalized'].max(axis=0),np.ones(35)))
    sen=pd.read_csv(T/f'{g}_sensitivity_k0_to10.csv').sort_values('n_removed');sens[g]=sen
    ck(g+' 11 nested sensitivity scenarios',len(sen)==11 and sen.n_removed.tolist()==list(range(11)))
    prev=None;expected=[]
    for k in range(11):
        keep=rank>k;vv=v[keep];ww=widths[keep];mean=vv.mean();sd=vv.std(ddof=1);q1k,q3k=np.quantile(vv,[.25,.75]);mk=np.median(vv)
        row=dict(n_retained=keep.sum(),retention_percent=keep.mean()*100,mean_peak_mV=mean,median_peak_mV=mk,SD_mV=sd,MAD_mV=np.median(abs(vv-mk)),Q1_mV=q1k,Q3_mV=q3k,IQR_mV=q3k-q1k,RSD_percent=100*sd/abs(mean),min_peak_mV=vv.min(),max_peak_mV=vv.max(),drift_range_mV=np.ptp(vv),mean_FWHM_mV=ww.mean(),SD_FWHM_mV=ww.std(ddof=1),mean_shift_from_full_mV=mean-v.mean(),abs_mean_shift_from_full_mV=abs(mean-v.mean()),mean_change_from_previous_mV=np.nan if prev is None else mean-prev['mean_peak_mV'],abs_mean_change_from_previous_mV=np.nan if prev is None else abs(mean-prev['mean_peak_mV']),SD_reduction_from_full_percent=100*(v.std(ddof=1)-sd)/v.std(ddof=1),SD_decrease_from_previous_mV=np.nan if prev is None else prev['SD_mV']-sd,SD_decrease_from_previous_percent=np.nan if prev is None else 100*(prev['SD_mV']-sd)/prev['SD_mV'])
        actual=sen.iloc[k];num(f'{g} k{k} all 22 numerical statistics',[actual[t] for t in row],list(row.values()))
        removed=';'.join(names[j] for j in order[:k]);retained=';'.join(names[j] for j in range(35) if keep[j]);new=names[order[k-1]] if k else ''
        ck(f'{g} k{k} deletion/retention identities and 90% preference',textv(actual.removed_scans_in_fixed_order)==removed and actual.retained_scans==retained and textv(actual.newly_removed_scan)==new and bool(actual.meets_90percent_preference)==(keep.mean()>=.9) and bool(actual.recommended)==(k==0))
        expected.append(row);prev=row
    arrays[g]=dict(v=v,widths=widths,order=order,rank=rank,names=names,flagI=flagI,flagZ=flagZ);original[g]=expected
members=pd.read_csv(T/'all_scheme_membership_770rows.csv')
ck('770 unique membership decisions',len(members)==770 and not members[['group','n_removed','scan']].duplicated().any())
for g in ['D','L']:
    a=arrays[g]
    for k in range(11):
        m=members[(members.group==g)&(members.n_removed==k)].sort_values('scan_number')
        ck(f'{g} k{k} all35 membership decisions',len(m)==35 and m.scan.tolist()==a['names'] and np.array_equal(m.retained,a['rank']>k) and np.array_equal(m.fixed_removal_rank,a['rank']) and np.array_equal(m.IQR_candidate,a['flagI']) and np.array_equal(m.modified_Z_candidate,a['flagZ']))
        num(f'{g} k{k} membership peak/FWHM values',np.r_[m.peak_voltage_mV,m.FWHM_mV],np.r_[a['v'],a['widths']])
comb=pd.read_csv(T/'all121_combinations.csv');base=abs(original['L'][0]['mean_peak_mV']-original['D'][0]['mean_peak_mV'])
ck('121 unique combinations',len(comb)==121 and not comb[['D_n_removed','L_n_removed']].duplicated().any())
for _,r in comb.iterrows():
    kd=int(r.D_n_removed);kl=int(r.L_n_removed);d=original['D'][kd];l=original['L'][kl];delta=abs(l['mean_peak_mV']-d['mean_peak_mV']);low=max(d['min_peak_mV'],l['min_peak_mV']);high=min(d['max_peak_mV'],l['max_peak_mV'])
    nums={f'{g}_{dest}':original[g][k][source] for g,k in [('D',kd),('L',kl)] for dest,source in [('n_retained','n_retained'),('retention_percent','retention_percent'),('mean_peak_mV','mean_peak_mV'),('SD_mV','SD_mV'),('min_peak_mV','min_peak_mV'),('max_peak_mV','max_peak_mV'),('mean_FWHM_mV','mean_FWHM_mV')]}
    nums.update(delta_V_mV=delta,delta_change_from_full_mV=delta-base,observed_overlap_width_mV=max(0,high-low),signed_L_min_minus_D_max_mV=l['min_peak_mV']-d['max_peak_mV'])
    num(f'combination D{kd}/L{kl} all numeric outputs',[r[t] for t in nums],list(nums.values()))
    ok=bool(r.observed_ranges_overlap)==(low<=high) and bool(r.recommended)==(kd==0 and kl==0) and bool(r.full_data)==(kd==0 and kl==0)
    for g,k in [('D',kd),('L',kl)]:
        a=arrays[g];keep=a['rank']>k;rem=';'.join(a['names'][j] for j in a['order'][:k]);ret=';'.join(a['names'][j] for j in range(35) if keep[j])
        ok &= textv(r[f'{g}_removed_scans'])==rem and r[f'{g}_retained_scans']==ret
    ck(f'combination D{kd}/L{kl} flags and identities',ok)
mat=pd.read_csv(T/'Figure_E_heatmap_matrix.csv',index_col=0)
num('heatmap exact mapping Y=L removed and X=D removed',mat.to_numpy(),comb.pivot(index='L_n_removed',columns='D_n_removed',values='delta_V_mV').to_numpy())
rec=pd.read_csv(T/'recommended_vs_full_and_candidate_scenarios.csv')
ck('D0/L0 recommendation, D3 and D2 secondary scenarios',rec.scenario.tolist()==['Full_data','Recommended_keep_all','Sensitivity_D_IQR_candidates','Sensitivity_D_ModifiedZ_candidates'] and rec.D_n_removed.tolist()==[0,0,3,2] and rec.L_n_removed.tolist()==[0,0,0,0] and rec.primary_recommendation.tolist()==[False,True,False,False])
for _,r in rec.iterrows():
    s=comb[(comb.D_n_removed==r.D_n_removed)&(comb.L_n_removed==r.L_n_removed)].iloc[0]
    num('recommendation scenario '+r.scenario,[r.D_mean_peak_mV,r.D_SD_mV,r.L_mean_peak_mV,r.L_SD_mV,r.delta_V_mV],[s.D_mean_peak_mV,s.D_SD_mV,s.L_mean_peak_mV,s.L_SD_mV,s.delta_V_mV])
f=pd.read_csv(T/'Figure_F_points_recommended_k0.csv');ck('Figure F shows true unchanged 35 before/after for both groups',len(f)==140 and (f.n_removed==0).all())
for g in ['D','L']:
    for stage in ['Before filtering','After filtering']:
        ff=f[(f.group==g)&(f.stage==stage)].sort_values('scan_number');num(g+' '+stage+' Figure F real points',ff.peak_voltage_mV,arrays[g]['v'])
expectedbooks={
'01_Original35_PeakParameters.xlsx':{'All70':70,'D_original35':35,'L_original35':35,'Group_statistics':2,'Thresholds':2,'Method_comparison':6,'D_fixed_ranking':35,'L_fixed_ranking':35,'Raw_SHA256':2},
'02_D_L_Removal_Sensitivity.xlsx':{'D_k0_to10':11,'L_k0_to10':11,'All_scheme_membership':770,'Fixed_order':70},
'03_All121_Removal_Combinations.xlsx':{'Combinations121':121,'DeltaV_matrix':11,'D_scheme_membership':385,'L_scheme_membership':385},
'04_Recommendation_vs_Full.xlsx':{'Scenario_comparison':4,'Recommended_all70':70,'Candidates_not_deleted':3},
'ICP_Sensitivity_All_Results.xlsx':{'Original70':70,'Full_statistics':2,'D_sensitivity':11,'L_sensitivity':11,'Combinations121':121,'Scheme_membership':770,'Recommendation':4,'Thresholds':2,'Method_comparison':6}}
for name,sheets in expectedbooks.items():
    w=load_workbook(P/name,read_only=True,data_only=True)
    for sheet,n in sheets.items():ck(name+' / '+sheet+' row count',sheet in w.sheetnames and w[sheet].max_row-1==n)
    for sheet in w.sheetnames:
        ck(name+' / '+sheet+' no spreadsheet errors',not any(c.data_type=='e' for row in w[sheet].iter_rows() for c in row))
    w.close()
metadata=json.loads((B/'raw_metadata.json').read_text())
for m in metadata:ck(m['sample']+' original Excel SHA256 preserved',hashlib.sha256((B/'raw'/m['file']).read_bytes()).hexdigest()==m['sha256'])
record=json.loads((P/'processing_record.json').read_text());ck('processing record accurately distinguishes recommendation and scenario',record['primary_recommendation']=={'D':0,'L':0} and record['secondary_scenario']['D']==3 and record['method_A_has_no_cutoff'] and record['thresholds_computed_once_from_full35'] and record['SD_ddof']==1 and record['voltage_mapping']['verified_instrument_calibration']==False)
result=dict(reviewer='Independent raw-array statistical recomputation',n_checks=len(checks),all_passed=all(c['passed'] for c in checks),n_failed=sum(not c['passed'] for c in checks),maximum_numeric_absolute_error=max(numeric_errors),absolute_tolerance=1e-10,relative_tolerance=1e-12,checks=checks)
(R/'independent_main_output_QA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
for c in checks:
    if not c['passed']:print('FAILED',c)
assert result['all_passed']
