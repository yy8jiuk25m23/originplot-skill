from pathlib import Path
import json,hashlib,subprocess,xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from PIL import Image
from openpyxl import load_workbook
B=Path(__file__).resolve().parent;O=B/'output';F=O/'figures'
checks=[]
def check(name,condition,details=None):
    checks.append(dict(check=name,passed=bool(condition),details=details))
    assert condition,(name,details)

independent=json.loads((B/'review/independent_main_output_QA.json').read_text())
check('independent_statistical_QA_passed',independent['all_passed'] and independent['n_failed']==0,
      dict(checks=independent['n_checks'],max_error=independent['maximum_numeric_absolute_error']))
render=json.loads((O/'rendering_record.json').read_text())
check('six_figures',len(render['figures'])==6)
for r in render['figures']:
    stem=r['figure']
    with Image.open(F/f'{stem}_600dpi.tiff') as im:
        check(stem+'_TIFF600dpi',all(abs(d-600)<.1 for d in im.info['dpi']),dict(pixels=im.size,dpi=[float(d) for d in im.info['dpi']]))
    with Image.open(F/f'{stem}_preview.png') as im:
        check(stem+'_PNG_preview',im.width>=2000 and im.height>=1200,dict(pixels=im.size,dpi=im.info.get('dpi')))
    svg=ET.parse(F/f'{stem}_editable.svg')
    ns={'s':'http://www.w3.org/2000/svg'}
    check(stem+'_editable_SVG_text',len(svg.findall('.//s:text',ns))>0)
    check(stem+'_SVG_no_embedded_images',len(svg.findall('.//s:image',ns))==0)
    if stem.startswith('Figure_E'):
        labels=[e.text for e in svg.findall('.//s:text',ns) if e.text]
        vals=pd.read_csv(O/'data/all121_combinations.csv').delta_V_mV
        from collections import Counter
        expected=Counter(f'{v:.3f}' for v in vals)
        actual=Counter(s for s in labels if s in expected)
        check('heatmap121_exact_rounded_annotations',actual==expected,dict(count=sum(actual.values())))
pdfs=sorted(F.glob('*_vector.pdf'))+[O/'All_Figures_A_to_F_vector.pdf']
for path in pdfs:
    fonts=subprocess.run(['pdffonts',str(path)],capture_output=True,text=True,check=True).stdout
    imgs=subprocess.run(['pdfimages','-list',str(path)],capture_output=True,text=True,check=True).stdout
    fontrows=[line for line in fonts.splitlines()[2:] if line.strip()]
    image_rows=[line for line in imgs.splitlines()[2:] if line.strip()]
    check(path.name+'_Arial_embedded',bool(fontrows) and all('Arial' in s and 'yes' in s for s in fontrows),fontrows)
    check(path.name+'_vector_no_raster',not image_rows,image_rows)
for path in O.glob('*.xlsx'):
    book=load_workbook(path,read_only=True,data_only=True)
    check(path.name+'_Chinese_dictionary','字段说明' in book.sheetnames)
    errors=[]
    for ws in book:
        for row in ws.iter_rows():
            errors.extend(c.coordinate for c in row if c.data_type=='e')
    check(path.name+'_no_error_cells',not errors)
    book.close()
for m in json.loads((O/'raw_metadata.json').read_text()):
    check(m['sample']+'_original_checksum_unchanged',hashlib.sha256((B/'raw'/m['file']).read_bytes()).hexdigest()==m['sha256'])
    new=np.load(B/f"{m['sample']}_raw_arrays.npz")['data']
    published=np.load(O/'data'/f"{m['sample']}_raw_and_normalized_all35.npz")
    check(m['sample']+'_fresh_XLSX_read_matches_archived_raw_array',
          np.array_equal(new[:,0],published['X']) and np.array_equal(new[:,1:],published['I_raw']))
check('no_native_OPJU_misrepresented',not list(O.rglob('*.opju')) and not render['native_Origin'])
record=dict(all_passed=all(r['passed'] for r in checks),artifact_checks=len(checks),checks=checks,
            independent_statistical_QA_file='reproducibility/review/independent_main_output_QA.json',
            actual_renderer='Matplotlib',native_OPJU_generated=False)
(O/'validation_results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
print(f'PASS: {len(checks)} artifact checks; independent scientific QA attached; all PDF/SVG fully vector; Arial embedded.')
