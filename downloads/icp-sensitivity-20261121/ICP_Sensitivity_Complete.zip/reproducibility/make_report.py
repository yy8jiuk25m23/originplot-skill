from pathlib import Path
import json,shutil,hashlib,zipfile
import pandas as pd
import numpy as np
import yaml
B=Path(__file__).resolve().parent;O=B/'output';T=O/'data'
sen=pd.concat([pd.read_csv(T/f'{g}_sensitivity_k0_to10.csv') for g in ['D','L']])
full=pd.read_csv(T/'full35_group_statistics.csv').set_index('group')
rec=json.loads((O/'processing_record.json').read_text())
com=pd.read_csv(T/'all121_combinations.csv')
candidate=com[(com.D_n_removed==3)&(com.L_n_removed==0)].iloc[0]

report=f'''# ICP 精氨酸峰位置异常候选与嵌套剔除敏感性分析

## 结论与推荐

**主推荐：D 组剔除 0 条，L 组剔除 0 条；每组保留全部 35 条。**

D 组有统计异常候选，但原始数据没有缺失点、边界峰、并列最高峰或不完整半高交点等已检测到的采集问题；这些检查不能排除尚未记录的仪器或样品问题。剔除曲线未出现明确持续稳定平台。因此，目前的证据不足以将候选判为错误数据。保留完整数据作为主要结果，并报告候选剔除的敏感性，是较稳妥且可追溯的选择。

| 组别 | 有效扫描 | 均值 ± 样本 SD (mV) | 中位数 (mV) | MAD (mV) | IQR (mV) | RSD (%) | 最大峰位范围 (mV) | 平均 FWHM (mV) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
'''
for g in ['D','L']:
 r=full.loc[g]
 report+=f'| {g}-Arg | 35 | {r.mean_peak_mV:.6f} ± {r.SD_mV:.6f} | {r.median_peak_mV:.6f} | {r.MAD_mV:.6f} | {r.IQR_mV:.6f} | {r.RSD_percent:.6f} | {r.drift_range_mV:.6f} | {r.mean_FWHM_mV:.6f} |\n'
report+=f'''
完整数据平均峰位差 **ΔV={rec['baseline_delta_V_mV']:.6f} mV**。主推荐不删除数据，因此剔除前后的均值、SD、FWHM、ΔV 均不变。Figure F 的前后两列是同一批观测值的重复展示，并非新的重复测量。

## 原始数据与电压换算

两份真实 Excel 各含 X 和 Y1–Y35，150000 行有效数值，X=0–149999，步长 1。重新读取原始 Excel 的实际 XML 单元格，未依赖文件中不正确的工作表维度元信息。保留原件和 SHA256，不覆盖源文件。文件内除表头外主要是 UI 设置，未找到电压标定关系。

**所有 mV 数值暂按 V_AC=X×0.002 换算，未经仪器电压标定确认。**300 mV 来自用户提供的实验参数；150000 个采样间隔对应 0–300 mV 为本次暂定假设，最后一点对应 299.998 mV。校准关系若有变化，必须重新计算对应电压统计。

每条扫描独立 I/Imax 归一化。直接在原始未对齐信号中取全局最高峰，全部 70 条均为唯一最高峰；不平滑、不拟合、不做峰位对齐、不扣基线、不重构峰形。FWHM 取包围最高峰的最近左右半高交点，仅对交点位置线性插值以测量宽度，不插入实验信号。归一化前后峰位置及 FWHM 已逐条核对不变。与此前代表曲线平移展示任务分开，本任务没有使用其对齐坐标。

## 三种方法的比较

方法 A 使用原始 35 条的中位数作为固定参考，按 |V−Median| 从大到小排序；相同偏差按原扫描编号从小到大打破平局。方法 A 没有异常判定阈值，**只提供候选顺序，不能把前 10 条都称为异常值**。各组完整 35 条固定排序见 Excel，前 10 条为：

- D：Y27、Y17、Y33、Y14、Y6、Y18、Y34、Y20、Y15、Y10。
- L：Y2、Y14、Y30、Y11、Y4、Y31、Y16、Y19、Y6、Y28。

方法 B 为严格超出 Q1−1.5IQR 或 Q3+1.5IQR。分位数采用 NumPy 的 linear 插值定义；全程固定完整数据阈值。

- D：下界 {full.loc['D','IQR_lower_mV']:.6f}，上界 {full.loc['D','IQR_upper_mV']:.6f} mV；候选 **Y17、Y27、Y33**。
- L：下界 {full.loc['L','IQR_lower_mV']:.6f}，上界 {full.loc['L','IQR_upper_mV']:.6f} mV；**无候选**。

方法 C 为 0.6745(V−Median)/MAD，严格 |Z|>3.5；MAD 为未缩放中位数绝对偏差，两组均非零。

- D：候选 **Y17、Y27**；Y33 仅被 IQR 标记。
- L：**无候选**。

因此两种阈值方法在 D 的 Y17/Y27 上一致，在 Y33 上有差异；在 L 没有异常候选这一点一致。这是统计筛查的一致性，不能替代采集记录核查。

## 逐步剔除与平台判断

两组各计算 k=0–10 的 11 档方案，始终从同一固定排序前端依次删除。每档均记录 12 项要求指标及额外 MAD/IQR/FWHM SD、具体保留/删除编号、770 条逐扫描成员状态。k=0 相对上一步的变化量为空，表示不存在上一步；相对完整数据的偏移为 0。

D 前三步 SD 降低约 0.329、0.348、0.258 mV；第 3 步后单步降幅变小，可描述为斜率变化。但 k=3 后 SD 仍继续下降，均值也继续移动，不能将这一点认定为已确认稳定平台。L 各步 SD 缓慢下降，没有明确拐点，而且两种阈值法均未给出异常候选。没有预先验证的仪器容许漂移或稳定性界限可用于确立强制停止阈值。

每组剔除 3 条时保留率为 91.43%，剔除 4 条时降为 88.57%；90% 优先原则用于提醒数据损失，不能凭它认定某个方案正确。对中心数据进行截尾本就容易降低 SD，不能只凭降低 SD 决定剔除，也不能据此宣称仪器实际重复性提高。

## 候选剔除的敏感性对照

**D 删 3 / L 删 0**仅作为有阈值候选支持的敏感性情景，不作为已确认应删除的数据处理方案：

- 删除 D 的 Y27、Y17、Y33；D 保留 32 条（91.43%），L 保留 35 条。
- D 均值由 {full.loc['D','mean_peak_mV']:.6f} 变为 {candidate.D_mean_peak_mV:.6f} mV，偏移 {candidate.D_mean_peak_mV-full.loc['D','mean_peak_mV']:+.6f} mV。
- D SD 由 {full.loc['D','SD_mV']:.6f} 变为 {candidate.D_SD_mV:.6f} mV，下降 {100*(1-candidate.D_SD_mV/full.loc['D','SD_mV']):.2f}%。
- ΔV 由 {rec['baseline_delta_V_mV']:.6f} 变为 {candidate.delta_V_mV:.6f} mV，变化 {candidate.delta_change_from_full_mV:+.6f} mV。
- 上述 ΔV 变化是候选剔除带来的敏感性，不是选择该方案的优化目标。

另附 D 删 2（Y27/Y17）/L 删 0 情景，作为修正 Z 阈值候选的对照。若后续从采集日志、样品记录或预先制定的质量标准确认候选确实无效，可据此更新推荐；原始完整数据对照仍应保留。

## 全部 121 种组合

D、L 各 0–10 条嵌套剔除形成 121 种组合，没有遍历任意子集。ΔV 范围 {com.delta_V_mV.min():.6f}–{com.delta_V_mV.max():.6f} mV；热图逐格保留 3 位小数，Excel/CSV 保留更高精度。未将最大 ΔV 标为最优方案。完整数据与主推荐均位于热图 (0,0)，用两个边框同时标示。

“分布是否重叠”在表中明确操作化为保留观测值的 **[最小值,最大值] 区间是否有交集**。本次 121 种组合的观测范围均不重叠；这不意味着总体分布完全不重叠，也不是显著性检验或置信区间比较。扫描编号是否对应真实时间顺序、扫描独立性和仪器漂移机理尚未确认，因此不推断时间趋势或报告依赖独立性假设的 p 值。

## 六张图与交付格式

- A：完整原始峰位散点；均值、中位数及空心候选标记。
- B：各档均值 ± 样本 SD；误差棒不是 SEM 或均值置信区间。
- C：SD 敏感性；仅将 D k=3 标作候选边界/可能斜率变化。
- D：最大峰位范围敏感性。
- E：11×11 组合 ΔV 热图；逐格真实数值，完整数据与推荐重合。
- F：主推荐前后箱线与全部实测点；因推荐不删数据，前后相同。箱体为 Q1–Q3，中线中位数，须为 1.5 IQR 范围内最远观测点，所有实测点另行绘出。水平微小错开仅用于显示，不改变电压。

六图统一 Arial，D=#2166AC，L=#D73027，白底，线宽 1.5–1.8 pt；TIFF 600 dpi、PNG 预览、嵌入 Arial 的矢量 PDF 及可逐对象编辑 SVG。实际渲染器为 Matplotlib。

**未生成原生 .opju 工程。**本机为 Linux，没有 Origin/COM/Windows 桥；Origin Skill 要求 “External mode must run in Windows Python”。`origin/` 内保存运行时检测和已核对 API 的可选 Windows 数据导入器，该导入器未在 Origin 执行，只创建数据工作表，不重建六张图页；不能当作已交付完整 Origin 图形工程。所有数据可导入 Origin，CSV/Excel/SVG 不能冒充 .opju。

## 可追溯文件

- `01_Original35_PeakParameters.xlsx`：70 条原始峰参数、完整组统计、阈值、固定排序、方法对照与原始 SHA256。
- `02_D_L_Removal_Sensitivity.xlsx`：D/L 各 11 档统计及各档成员状态。
- `03_All121_Removal_Combinations.xlsx`：121 组合统计及热图矩阵。
- `04_Recommendation_vs_Full.xlsx`：主推荐、完整数据、D3/L0 与 D2/L0 敏感性对照。
- `ICP_Sensitivity_All_Results.xlsx`：上述核心结果汇总。
- `data/`：Origin 导入 CSV、完整原始与归一化 NPZ、绘图数据；`figures/`：六图各格式。
- `processing_record.json`、`rendering_record.json`、`validation_results.json`：处理参数、渲染属性及验证；`reproducibility/`：原始 Excel、脚本、日志、独立复核记录与字体来源。
'''
(O/'Analysis_report_ZH.md').write_text(report)
(O/'Figure_captions_ZH.txt').write_text('所有图均基于原始未对齐最高峰；暂定 V_AC=X×0.002 mV，未经仪器标定确认。实际渲染软件 Matplotlib。\n\n'+
 '\n\n'.join(['A：原始35次扫描峰位散点，虚线为均值，点线为中位数；空心点为统计候选，主分析仍保留。',
 'B：固定排序剔除0–10条后的均值±样本SD；不是SEM或置信区间。',
 'C：SD随剔除数量变化。D组k=3为候选边界与可能斜率变化，不是已确认平台。',
 'D：观测峰位范围（最大值减最小值）随剔除数量变化，不推断仪器重复性提高。',
 'E：121种固定嵌套组合的两组均值绝对差，逐格三位小数；完整数据和推荐方案同为(0,0)，两个边框重合显示。',
 'F：主推荐D/L各剔除0条，故前后展示同一批观测值，不是新增测量。每组n=35；箱体Q1–Q3，中线中位数，须为1.5IQR范围内最远观测点；空心点为候选但未剔除，水平错开仅用于展示。']))

readme='''# ICP 峰位异常候选与剔除敏感性分析

主推荐 D0/L0，保留全部70条。D有IQR候选Y17/Y27/Y33，修正Z候选Y17/Y27；L均无候选。D3/L0仅作敏感性对照，不能据此断言采集错误或仪器重复性改善。

请先读 `Analysis_report_ZH.md`，查看 `All_Figures_A_to_F_preview.png` 或六张独立图片；全部统计见 `ICP_Sensitivity_All_Results.xlsx`。各组11档嵌套方案、121组合及全部保留/删除编号均可追溯。

所有电压暂按 X×0.002 mV，未经仪器标定确认。峰参数取自原始未对齐信号，不平滑、不拟合。六图实际由 Matplotlib 渲染，TIFF600dpi、PNG、矢量PDF、可编辑SVG均已生成。

**未生成 .opju**：当前Linux没有Origin或Windows桥。`origin/` 的可选Windows导入器仅创建数据工作表，不重建六图，未在Origin执行。请勿将其他格式当作Origin工程。

完整包中的 `reproducibility/` 保留原始Excel与脚本。复现：先在该目录运行 `read_raw.py`、`analyze_sensitivity.py`，如系统无Arial则运行 `install_arial.py`，随后运行 `render_sensitivity.py` 和 `make_report.py`。`validate_outputs.py`验证科学统计与导出属性；`package_outputs.py`打包。Arial字体文件不随包分发，PDF已嵌入子集，SVG文字编辑需要本地字体。
'''
(O/'README.md').write_text(readme)

layers={
 'A':dict(data='data/Figure_A_points.csv',object='worksheet',plots=['scatter(group,scan_number,peak_voltage_mV)','full35 group mean and median reference lines'],x='Scan Number',y='Peak Voltage (mV)'),
 'B':dict(data=['data/D_sensitivity_k0_to10.csv','data/L_sensitivity_k0_to10.csv'],object='worksheet',plots=['line+symbol(n_removed,mean_peak_mV)','sample SD error bars: SD_mV'],x='Number of Removed Scans',y='Mean Peak Voltage (mV)'),
 'C':dict(data=['data/D_sensitivity_k0_to10.csv','data/L_sensitivity_k0_to10.csv'],object='worksheet',plots=['line+symbol(n_removed,SD_mV)'],annotation='D k=3: candidate boundary/possible slope change, not confirmed plateau',x='Number of Removed Scans',y='Standard Deviation (mV)'),
 'D':dict(data=['data/D_sensitivity_k0_to10.csv','data/L_sensitivity_k0_to10.csv'],object='worksheet',plots=['line+symbol(n_removed,drift_range_mV)'],x='Number of Removed Scans',y='Peak Voltage Drift Range (mV)'),
 'E':dict(data='data/Figure_E_heatmap_matrix.csv',object='matrix',plots=['vector heatmap, columns D k, rows L k, cells delta_V_mV'],annotation='121 labels %.3f; full and recommended both (0,0)',x='Number of Removed D-Arg Scans',y='Number of Removed L-Arg Scans'),
 'F':dict(data='data/Figure_F_points_recommended_k0.csv',object='worksheet',plots=['grouped box and all raw scatter(group,stage,peak_voltage_mV)'],annotation='Both groups k=0; before and after identical; show n, median, IQR',x='Group and filtering stage',y='Peak Voltage (mV)')}
spec=dict(figure={'id':'ICP_sensitivity_A_to_F','purpose':'Nested removal sensitivity; primary retain all'},
 runtime={'requested':'Origin','actual':'Matplotlib','Origin_available':False,'OPJU_generated':False},
 data={'source_files':['raw/D-.86.xlsx','raw/L-.86.xlsx'],'voltage':'X*0.002 mV; unverified','no_alignment':True,'no_smoothing':True},
 pages=[dict(id=k,layout='single',layers=[dict(id='main',**v)]) for k,v in layers.items()],
 style={'font_family':'Arial','background':'white','line_width_pt':[1.5,1.8],
        'colors':{'D':'#2166AC','L':'#D73027'},'candidate_marker':'hollow'},
 export={'TIFF_dpi':600,'PNG_dpi':240,'PDF':'vector','SVG':'editable text and objects','OPJU':'unavailable, not generated'},
 qa={'scans':70,'nested_schemes':22,'combinations':121,'primary_k':{'D':0,'L':0},'no_DeltaV_optimization':True})
(O/'FigureSpec.yaml').write_text(yaml.safe_dump(spec,sort_keys=False,allow_unicode=True))

# Add a compact Chinese field dictionary to every workbook without changing numeric cells.
dictionary=pd.DataFrame([
 ('peak_voltage_mV','原始未对齐最高峰对应电压（暂定换算）'),('scan / scan_number','原始Y列编号'),
 ('mean_peak_mV / median_peak_mV','保留扫描的平均/中位峰顶电压'),('SD_mV','样本标准差，ddof=1'),
 ('MAD_mV','未缩放中位数绝对偏差'),('IQR_mV','Q3−Q1，linear分位数定义'),('RSD_percent','100×SD/|Mean|'),
 ('drift_range_mV','保留实测峰位最大值−最小值'),('FWHM_mV','包围原始最高峰的最近半高交点宽度'),
 ('fixed_removal_rank','按原始35条中位数偏差固定排序，不是每步重新排序'),
 ('IQR_candidate / modified_Z_candidate','统计异常候选，不表示已确认采集错误'),
 ('retained','该档保留True/删除False'),('n_removed / n_retained','删除/保留扫描数量'),
 ('retention_percent','保留数量/35×100%'),('mean_shift_from_full_mV','本档均值−完整数据均值，带符号'),
 ('mean_change_from_previous_mV','本档均值−上档均值，k0为空'),('SD_reduction_from_full_percent','100×(原始SD−本档SD)/原始SD'),
 ('delta_V_mV','两组保留均值之差的绝对值'),('delta_change_from_full_mV','本档DeltaV−完整数据DeltaV'),
 ('observed_ranges_overlap','保留实测最小—最大区间是否有交集；不是总体分布重叠检验'),
 ('recommended','主推荐D0/L0。主分析不实际删除任何扫描')],columns=['field','中文说明'])
for path in O.glob('*.xlsx'):
 with pd.ExcelWriter(path,engine='openpyxl',mode='a',if_sheet_exists='replace') as w:
  dictionary.to_excel(w,sheet_name='字段说明',index=False)
  ws=w.sheets['字段说明'];ws.column_dimensions['A'].width=43;ws.column_dimensions['B'].width=85;ws.freeze_panes='A2'
print('COMPLETE: Chinese analysis report, bilingual captions, FigureSpec, workbook field dictionaries and README.')
