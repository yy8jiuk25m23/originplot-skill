from pathlib import Path
import os, json, math, hashlib, shutil, zipfile, base64
os.environ['MPLCONFIGDIR'] = str(Path(__file__).resolve().parent / 'mplconfig')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt, font_manager
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.ticker import MaxNLocator
import plotly.graph_objects as go
import plotly.io as pio
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

B = Path(__file__).resolve().parent
OUT = B / 'output_v6'
OUT.mkdir(exist_ok=True)
font_path = B / 'iso_chinese_regular.otf'
for font_file in [font_path, B/'iso_chinese_bold.otf']:
    font_manager.fontManager.addfont(str(font_file))
font_family = ['Noto Sans CJK SC', 'DejaVu Sans']
plt.rcParams.update({'font.family': font_family,
                     'axes.unicode_minus': False, 'font.size': 10,
                     'pdf.fonttype': 3, 'mathtext.fontset': 'dejavusans', 'savefig.facecolor': 'white'})
PALETTE = ['#21618C', '#238B7E', '#B74746', '#845D9C', '#C38D28', '#3B8BBB',
           '#C77762', '#648742', '#8D6375', '#4B6B89']
z = np.load(B / 'target_windows.npz')
files = pd.read_csv(B / 'file_metrics.csv')
assert len(files) == 39
assert all(z[Path(f).stem].shape[0] > 550 for f in files['文件']), 'expanded extraction incomplete'

# One common peak anchor for all groups of the same amino acid. Equal file weights
# prevent groups with more repeat columns from dominating the anchor selection.
file_stats, repeat_stats, traces, anchors = [], [], {}, {}
for amino, group in files.groupby('氨基酸', sort=False):
    target = float(group['理论m/z'].iloc[0])
    reference_x = z[Path(group['文件'].iloc[0]).stem][:, 0]
    assert all(np.array_equal(reference_x, z[Path(f).stem][:, 0]) for f in group['文件'])
    pooled = np.mean([z[Path(f).stem][:, 1:].mean(axis=1) for f in group['文件']], axis=0)
    candidate = np.abs(reference_x - target) <= 2.0
    anchor = float(reference_x[np.flatnonzero(candidate)[np.argmax(pooled[candidate])]])
    anchors[amino] = anchor
    core = np.abs(reference_x - anchor) <= 0.45
    display = np.abs(reference_x - anchor) <= 0.65
    assert np.count_nonzero(core) > 70
    for _, original in group.iterrows():
        name = original['文件']
        a = z[Path(name).stem]
        x = a[core, 0]
        v = a[core, 1:]
        assert np.isfinite(v).all() and (v >= 0).all()
        n = v.shape[1]
        heights = v.max(axis=0)
        positions = x[v.argmax(axis=0)]
        areas = np.trapezoid(v, x, axis=0)
        mu = float(heights.mean())
        sd = float(heights.std(ddof=1)) if n > 1 else np.nan
        cv = sd / mu * 100 if n > 1 and mu > 0 else np.nan
        spectrum_mean = a[:, 1:].mean(axis=1)
        peakmean = float(spectrum_mean[core].max())
        peakmean_mz = float(x[np.argmax(spectrum_mean[core])])
        boundary = np.maximum(v[0], v[-1])
        touched = int(np.count_nonzero(boundary > heights * 0.5))
        exact_unique = len({a[:, j].tobytes() for j in range(1, n + 1)})
        peak_at_edge = int(np.count_nonzero((v.argmax(axis=0) == 0) | (v.argmax(axis=0) == len(x)-1)))
        for j in range(n):
            repeat_stats.append({'氨基酸': amino, '文件': name, '重复列': f'y{j+1}',
                '共用实测锚点m/z': anchor, '取峰下界m/z': float(x[0]), '取峰上界m/z': float(x[-1]),
                '原始峰高': float(heights[j]), '实测峰顶m/z': float(positions[j]),
                '窗口原始积分': float(areas[j]), '峰顶触及窗口边界': bool(v[:, j].argmax() in [0, len(x)-1])})
        stat = {'氨基酸': amino, '文件': name, '重复数n': n, '理论[M+H]+m/z': target,
            '共用实测锚点m/z': anchor, '各次峰高的均值': mu, '各次峰高的SD': sd,
            '峰高CV_%': cv, '均值谱峰高': peakmean, '均值谱峰顶m/z': peakmean_mz,
            '峰位SD_Da': float(positions.std(ddof=1)) if n > 1 else np.nan,
            '平均窗口积分': float(areas.mean()),
            '窗口积分CV_%': float(areas.std(ddof=1)/areas.mean()*100) if n > 1 and areas.mean() > 0 else np.nan,
            '检出重复数': int((heights > 0).sum()), '不同数值曲线数': exact_unique,
            '窗口边界大于半峰高的重复数': touched, '峰顶触边重复数': peak_at_edge,
            '源路径': original['源路径']}
        file_stats.append(stat)
        traces[name] = {'x': a[display, 0], 'values': a[display, 1:], 'anchor': anchor,
                        'mean': a[display, 1:].mean(axis=1),
                        'sd': a[display, 1:].std(axis=1, ddof=1) if n > 1 else np.full(display.sum(), np.nan)}

comparison = pd.DataFrame(file_stats)
comparison['选用'] = False
comparison['处理说明'] = ''
for amino, group in comparison.groupby('氨基酸', sort=False):
    eligible = group[(group['重复数n'] >= 2) & group['峰高CV_%'].notna()].copy()
    assert len(eligible), f'No evaluable repeat group: {amino}'
    eligible['检出比例'] = eligible['检出重复数'] / eligible['重复数n']
    eligible = eligible[eligible['检出比例'] == eligible['检出比例'].max()]
    # Lower CV is primary; differences < 1 percentage point favor more repeats.
    best_cv = float(eligible['峰高CV_%'].min())
    near = eligible[eligible['峰高CV_%'] < best_cv + 1.0]
    winner = near.sort_values(['重复数n', '峰高CV_%'], ascending=[False, True]).index[0]
    comparison.loc[winner, '选用'] = True
    for idx, r in group.iterrows():
        if r['重复数n'] < 2:
            text = '仅1次测量，无法估计重复性，不参与优选'
        elif idx == winner:
            text = '选用：优先检出完整；再比较CV（差<1个百分点优先n更多）'
            if r['检出重复数'] < r['重复数n']:
                text += '；两组均有零信号，仅作相对优选，保留零值'
        else:
            text = '保留比较：按同一目标窗口计算，未选入作图'
        comparison.loc[idx, '处理说明'] = text

summary = comparison[comparison['选用']].copy()
summary['强度数量级k'] = np.floor(np.log10(summary['各次峰高的均值'])).astype(int)
summary['分组'] = summary['强度数量级k'].map(lambda k: f'10^{k}')
summary['稳定性提示'] = summary['峰高CV_%'].map(lambda v: 'CV>20%，重复波动较大' if v > 20 else 'CV≤20%（仅描述，不是仪器验收阈值）')
summary = summary.sort_values(['强度数量级k', '各次峰高的均值']).reset_index(drop=True)
assert len(summary) == 18 and summary['氨基酸'].nunique() == 18
comparison['各次峰高的SD'] = comparison['各次峰高的SD'].astype(float)
rep = pd.DataFrame(repeat_stats)
selected_names = set(summary['文件'])
rep['选用组'] = rep['文件'].isin(selected_names)
manifest = []
for _, r in files.iterrows():
    p = Path(r['源路径'])
    manifest.append({'文件': p.name, '氨基酸': r['氨基酸'], '重复数': int(r['重复数']),
                     '是否用于最终作图': p.name in selected_names,
                     'SHA256': hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else r['SHA256']})

# Apply the same measured-tail display rule to all 18 selected ISO spectra.
window_checks=[]
for _,r in summary.iterrows():
    name=r['文件'];a=z[Path(name).stem];x=a[:,0];v=a[:,1:].mean(axis=1);t=traces[name]
    old_x=t['x'].copy();old_mean=t['mean'].copy();lo=int(np.searchsorted(x,old_x[0]));hi=int(np.searchsorted(x,old_x[-1]))
    peak=float(old_mean.max());threshold=peak*.01
    left,right=lo,hi
    left_open=right_open=False
    if v[lo]>threshold:
        found=False
        for j in range(lo-1,1,-1):
            if np.all(v[j-2:j+1]<=threshold):left=j-2;found=True;break
        if not found:left=0;left_open=True
    if v[hi]>threshold:
        found=False
        for j in range(hi+1,len(x)-2):
            if np.all(v[j:j+3]<=threshold):right=j+2;found=True;break
        if not found:right=len(x)-1;right_open=True
    sl=slice(left,right+1)
    traces[name]={'x':x[sl],'values':a[sl,1:],'anchor':t['anchor'],'mean':v[sl],
                  'sd':a[sl,1:].std(axis=1,ddof=1),'left_open':left_open,'right_open':right_open}
    offset=lo-left
    assert np.array_equal(traces[name]['mean'][offset:offset+len(old_mean)],old_mean)
    window_checks.append({'氨基酸':r['氨基酸'],'文件':name,'原左端m/z':old_x[0],'原右端m/z':old_x[-1],
                          '新左端m/z':x[left],'新右端m/z':x[right],
                          '左端相对峰高_%':v[left]/peak*100,'右端相对峰高_%':v[right]/peak*100,
                          '左端仍有背景':left_open,'右端仍有背景':right_open,
                          '新增原始网格点':right-left+1-len(old_x)})
pd.DataFrame(window_checks).to_csv(OUT/'18种氨基酸_绘图窗口核查.csv',index=False,encoding='utf-8-sig')

curve_rows, raw_rows = [], []
for _, r in summary.iterrows():
    t = traces[r['文件']]
    for j, x in enumerate(t['x']):
        curve_rows.append({'分组': r['分组'], '氨基酸': r['氨基酸'], '文件': r['文件'],
            '原始m/z': float(x), '距共用实测锚点_Da': float(x-t['anchor']),
            '平均离子强度': float(t['mean'][j]), '点位SD': float(t['sd'][j]), '重复数n': int(r['重复数n'])})
        row = {'分组': r['分组'], '氨基酸': r['氨基酸'], '文件': r['文件'], '原始m/z': float(x)}
        row.update({f'y{q+1}': float(t['values'][j,q]) for q in range(t['values'].shape[1])})
        raw_rows.append(row)
curves = pd.DataFrame(curve_rows)
raw = pd.DataFrame(raw_rows)

notes = [
 ('读取范围', '只读取39个不含“全”字的文件；全部“全/全1/全2”文件均未读取或参与计算。'),
 ('数据解释', '依用户说明，y1、y2…为重复测量；目标离子为正离子[M+H]+，按用户确认保留实测峰偏移。'),
 ('峰位规则', '同一氨基酸各文件的均值谱等权平均；在理论[M+H]+±2 Da内寻找共同局部主峰锚点。'),
 ('目标窗口', '逐次峰高取共同锚点±0.45 Da内最大原始强度；绘图先取锚点±0.65 Da；边界若仍高于主峰1%，仅补回该ISO文件已提取的局部实测点，至连续3点低于1%。局部数据仍未回落时用空心端点标注，不补零。峰高统计窗口不变；全谱文件不参与。'),
 ('窗口定义的限制', '这是文件标签与局部峰规则确定的候选母离子峰，不以未校准的质量轴单独证明化学归属；邻近峰及取峰边界见逐次测量与质量比较。'),
 ('保留数据', '不平滑、不扣基线、不删离群值，不拼接不同文件的重复列，不对强度做逐物质归一化，不修正质量轴。'),
 ('峰高统计', '分组量为各次局部峰高的算术均值；SD为样本标准差(ddof=1)，CV=SD/均值×100%。不以单次最高值分组。'),
 ('选组规则', '只在n≥2文件中选择。优先正信号重复占比更高者（正值不等于经LOD验证的检出）；再选CV最低者。与最低CV相差<1个百分点时优先n更多，再以低CV破同分。若两组均有零值仍全部保留，不称为稳定组。'),
 ('单次测量', 'n=1的丝氨酸2、甘氨酸2保留在比较表，不以无法计算的CV挑选为最佳组。'),
 ('分组规则', '10^k组满足10^k≤各次峰高均值<10^(k+1)，不同数量级分别作图。没有数据的数量级不创建。'),
 ('3D图的数值', '曲线是所选文件各重复在原始m/z网格的逐点均值。“均值谱峰高”通常小于“各次峰高均值”，因为重复间可能存在峰位偏移。'),
 ('3D图两种横轴', '原始m/z版不移动曲线；局部峰形版仅用Δm/z=原始m/z−该氨基酸共用锚点便于比较峰形，不代表校准或理论对齐。'),
 ('强度轴', '组内共用线性强度轴，轴标题标明10^k倍率，保留原始强度差异。不同页有不同轴范围。'),
 ('细线版样式', '移除峰下填色，拉长质荷比方向的参考基线，压缩纵深；局部峰形版横轴扩展至±1.6 Da。延长的水平线仅为零强度参考线，不代表新增采集点。原有谱线数值与实际峰宽均未改变。'),
 ('单独的强度组', '若某数量级只有一种氨基酸，主图仍绘其均值谱；另附该物质各次重复的3D图。'),
 ('误差与解释', 'CV描述当前文件的重复性。正信号仅指窗口内存在>0原始值；没有空白对照，不等同于LOD/LOQ检出。不同文件n不同，优选仅用于本批数据展示，不作统计显著性或绝对含量结论。谷氨酰胺、苏氨酸所选组仍有零信号，不能称为稳定数据。'),
 ('原始强度单位', '上传表未给出校准单位，统一称“原始离子强度”；不换算浓度。'),
 ('交付文件', 'Excel含按数量级分组的表和作图数据；PDF/PNG为静态图，HTML可离线旋转与缩放。'),
]

xlsx = OUT / '氨基酸_ISO_分组与重复性.xlsx'
public_summary = summary.drop(columns=['源路径', '选用'])
with pd.ExcelWriter(xlsx, engine='openpyxl') as writer:
    pd.DataFrame(notes, columns=['项目', '说明']).to_excel(writer, sheet_name='说明', index=False)
    public_summary.to_excel(writer, sheet_name='选组汇总_18种', index=False)
    comparison.drop(columns=['源路径']).to_excel(writer, sheet_name='全部39组_重复性比较', index=False)
    rep.to_excel(writer, sheet_name='全部222次_峰高记录', index=False)
    for k, g in summary.groupby('强度数量级k', sort=True):
        g.drop(columns=['源路径', '选用']).to_excel(writer, sheet_name=f'10^{k}_分组对比', index=False)
        curves[curves['分组'] == f'10^{k}'].to_excel(writer, sheet_name=f'10^{k}_均值谱作图数据', index=False)
    raw.to_excel(writer, sheet_name='所选组_原始重复曲线', index=False)
    pd.DataFrame(manifest).to_excel(writer, sheet_name='ISO源文件清单', index=False)
    for ws in writer.book.worksheets:
        ws.freeze_panes = 'A2'
        ws.auto_filter.ref = ws.dimensions
        ws.sheet_view.showGridLines = False
        for c in ws[1]:
            c.fill = PatternFill('solid', fgColor='184E69')
            c.font = Font(name='等线', bold=True, color='FFFFFF')
            c.alignment = Alignment(wrap_text=True, vertical='center')
        ws.row_dimensions[1].height = 34
        for col in ws.columns:
            key = col[0].value
            width = 22 if key in ['文件','氨基酸'] else min(29, max(16, len(str(key))*1.5))
            if key == '说明': width = 120
            if key == '处理说明': width = 58
            if key == 'SHA256': width = 70
            ws.column_dimensions[get_column_letter(col[0].column)].width = width
        for row in ws.iter_rows(min_row=2):
            for c in row:
                if isinstance(c.value, float):
                    c.number_format = '0.0000' if 'm/z' in str(ws.cell(1,c.column).value) else '0.00'
                if ws.title == '说明':
                    c.alignment = Alignment(wrap_text=True, vertical='center')
            if ws.title == '说明': ws.row_dimensions[row[0].row].height = 48

public_summary.to_csv(OUT / '选组与强度分组.csv', index=False, encoding='utf-8-sig')
curves.to_csv(OUT / '分组均值谱_原始m_z.csv', index=False, encoding='utf-8-sig')
rep.to_csv(OUT / '全部重复测量_峰高记录.csv', index=False, encoding='utf-8-sig')
(OUT / '方法说明.md').write_text('# 氨基酸 ISO 数据与3D图\n\n' + '\n\n'.join(f'**{k}**：{v}' for k,v in notes), encoding='utf-8')

def display_limits(g, aligned):
    if aligned:
        lo=min(float((traces[f]['x']-traces[f]['anchor']).min()) for f in g['文件'])
        hi=max(float((traces[f]['x']-traces[f]['anchor']).max()) for f in g['文件'])
        return (min(-1.6,lo-.10),max(1.6,hi+.10))
    starts = [traces[f]['x'][0] for f in g['文件']]
    ends = [traces[f]['x'][-1] for f in g['文件']]
    lo,hi = min(starts),max(ends)
    if hi-lo < 3.2:
        center = (lo+hi)/2
        return center-1.6,center+1.6
    padding = max(.4, (hi-lo)*.04)
    return lo-padding,hi+padding

def make_3d(g, aligned=False, ax=None, repeat=False):
    if ax is None:
        fig = plt.figure(figsize=(13.5,8.3))
        ax = fig.add_subplot(111, projection='3d')
        fig.subplots_adjust(left=.02, right=.90, bottom=.08, top=.88)
    else:
        fig = ax.figure
    k = int(g['强度数量级k'].iloc[0]); scale=10**k
    xs=[]; maxz=0
    xlimits = display_limits(g,aligned)
    labels=[]; handles=[]
    entries=[]
    if repeat:
        r=g.iloc[0];t=traces[r['文件']]
        for j in range(t['values'].shape[1]):
            entries.append((r,t['values'][:,j],f'y{j+1}'))
    else:
        for _,r in g.iterrows():entries.append((r,traces[r['文件']]['mean'],r['氨基酸']))
    for i,(r,values,label) in enumerate(entries):
        t=traces[r['文件']]; x=t['x']-t['anchor'] if aligned else t['x']
        zz=values/scale; xs.extend(x.tolist()); maxz=max(maxz,float(zz.max()))
        c=PALETTE[(i+(4 if g.attrs.get('panel')=='B' and not repeat else 0))%len(PALETTE)]
        ax.plot(x,np.full(len(x),i),zz,color=c,lw=1.15)
        if not repeat:
            for edge,is_open in [(0,t.get('left_open',False)),(-1,t.get('right_open',False))]:
                if is_open:ax.scatter([x[edge]],[i],[zz[edge]],s=18,facecolors='white',edgecolors=c,linewidths=.8)
        # This is a geometric zero-intensity reference, not synthesized data.
        ax.plot(xlimits,[i,i],[0,0],color=c,lw=.7,alpha=.7)
        labels.append(label)
        handles.append(plt.Line2D([0],[0],color=c,lw=2,label=label if repeat else f"{i+1:02d}  {label}  n={r['重复数n']}  CV={r['峰高CV_%']:.1f}%"))
    ax.set_xlim(xlimits)
    ax.set_ylim(-.45,max(.55,len(entries)-.5));ax.set_zlim(0,10.0 if k==4 else maxz*1.1)
    ax.set_yticks(range(len(entries)))
    ax.set_yticklabels(labels if repeat else [f'{i+1:02d}' for i in range(len(entries))],fontsize=10)
    ax.set_xlabel('相对共用实测峰位 Δm/z' if aligned else '原始 m/z',labelpad=12)
    ax.set_zlabel('原始离子强度 '+rf'($\times 10^{{{k}}}$)',labelpad=10)
    ax.zaxis.set_major_locator(MaxNLocator(5));ax.xaxis.set_major_locator(MaxNLocator(6))
    if k==4: ax.set_zticks([0,2,4,6,8,10])
    ax.tick_params(axis='y',pad=0); ax.tick_params(axis='z',pad=2)
    ax.view_init(elev=25,azim=-68)
    ax.set_box_aspect((2.6,max(.45,min(1.1,len(entries)*.14)),.85))
    for axis in [ax.xaxis,ax.yaxis,ax.zaxis]:
        axis.pane.fill=False
        axis._axinfo['grid'].update(color=(.7,.75,.78,.23),linewidth=.4)
    if any(traces[f].get('left_open',False) or traces[f].get('right_open',False) for f in g['文件']):
        ax.text2D(.02,.77,'空心端点：局部数据边界仍有背景，未强制归零',transform=ax.transAxes,fontsize=8.5,color='#52636D')
    return fig,ax,handles

# Split only the crowded 10^4 group into two sets of four, by mean peak height.
groups=[]
for k,g0 in summary.groupby('强度数量级k',sort=True):
    if k==4:
        ranked=g0.sort_values('各次峰高的均值')
        for panel,part in [('A',ranked.iloc[:4]),('B',ranked.iloc[4:])]:
            g=part.sort_values('均值谱峰顶m/z').reset_index(drop=True)
            g.attrs['panel']=panel
            groups.append((f'10^{k}{panel}',int(k),g))
    else:
        groups.append((f'10^{k}',int(k),g0.sort_values('均值谱峰顶m/z').reset_index(drop=True)))
assert [len(g) for key,k,g in groups if k==4]==[4,4]
assert sum(len(g) for key,k,g in groups)==18

def group_title(key,k):
    return rf'$10^{{{k}}}$'+(' '+key[-1] if k==4 else '')

pdf_path=OUT/'氨基酸_ISO_分图版_3D图.pdf'
page_paths=[]
with PdfPages(pdf_path) as pdf:
    for key,k,g in groups:
        for aligned in [False,True]:
            fig,ax,handles=make_3d(g,aligned)
            mode='峰形对齐' if aligned else '原始m_z'
            fig.suptitle('ISO 氨基酸局部实测峰｜'+group_title(key,k)+' 强度组',x=.08,ha='left',fontsize=21,fontweight='bold')
            subtitle=('局部峰形，Δm/z仅用于横向排齐' if aligned else '保留原始质量轴')+f' · {len(g)}种氨基酸 · 所选重复组的均值谱'
            if k==4: subtitle+=' · A/B共用强度轴 0–10 × 10⁴'
            fig.text(.08,.905,subtitle,fontsize=11,color='#47606F')
            fig.legend(handles=handles,loc='upper right',bbox_to_anchor=(.995,.82),frameon=False,fontsize=10.5,labelspacing=.8)
            fig.text(.08,.035,'细线版｜水平线为零强度参考线；数据、选组与原始峰宽保持不变；所有谱线统一检查并补回实测尾部。',fontsize=10,color='#52636D')
            p=OUT/f'3D_{key}_{mode}.png';fig.savefig(p,dpi=240);page_paths.append(p)
            pdf.savefig(fig);plt.close(fig)
        if len(g)==1:
            fig,ax,handles=make_3d(g,True,repeat=True);r=g.iloc[0]
            fig.suptitle(r['氨基酸']+'｜'+group_title(key,k)+'组的各次重复测量',x=.08,ha='left',fontsize=20,fontweight='bold')
            fig.text(.08,.90,f"{r['文件']} | n={r['重复数n']} | CV={r['峰高CV_%']:.2f}%",fontsize=12)
            p=OUT/f'3D_{key}_重复测量.png';fig.savefig(p,dpi=240);page_paths.append(p)
            pdf.savefig(fig);plt.close(fig)

fig=plt.figure(figsize=(18,16))
for panel,(key,k,g) in enumerate(groups):
    ax=fig.add_subplot(3,2,panel+1,projection='3d');make_3d(g,True,ax=ax)
    ax.set_title(group_title(key,k)+f' 组｜{len(g)} 种',loc='left',fontsize=17,fontweight='bold',pad=10)
    items=[f'{i+1:02d} {name}' for i,name in enumerate(g['氨基酸'])]
    text='\n'.join('   '.join(items[i:i+4]) for i in range(0,len(items),4))
    ax.text2D(.02,.86,text,transform=ax.transAxes,fontsize=9,linespacing=1.6,color='#304B5B')
fig.suptitle('氨基酸 ISO｜'+r'$10^4$'+'组分为 A、B 两图',fontsize=25,fontweight='bold',x=.04,ha='left',y=.98)
fig.text(.04,.95,'A：较低峰高的4种；B：较高峰高的4种。A/B使用相同强度轴 0–100,000，其余数量级保持原分组。',fontsize=12,color='#47606F')
fig.subplots_adjust(left=.03,right=.96,bottom=.05,top=.90,wspace=.18,hspace=.18)
fig.text(.04,.02,'横轴Δm/z仅用于排齐峰形，数据未归一化；原始m/z版见分组图。',fontsize=11,color='#52636D')
fig.savefig(OUT/'氨基酸_ISO_分图总览.png',dpi=200);plt.close(fig)

# The workbook retains the combined numeric 10^4 table, plus A/B comparison tabs.
from openpyxl import load_workbook
from openpyxl.drawing.image import Image as ExcelImage
wb=load_workbook(xlsx)
ws=wb.create_sheet('3D图总览',0)
ws['A1']='10^4组分为A、B两图，各4种，强度轴相同。'
ws['A2']='按各次峰高均值排序拆分；保留此前选组、强度、CV和原始m/z。'
im=ExcelImage(str(OUT/'氨基酸_ISO_分图总览.png'));im.width,im.height=1080,960;ws.add_image(im,'A4')
panel_records=[]
for key,k,g in groups:
    sheet=key+'_分组对比'
    if sheet in wb.sheetnames:ws=wb[sheet]
    else:
        ws=wb.create_sheet(sheet)
        cols=public_summary.columns.tolist();ws.append(cols)
        for row in g[cols].itertuples(index=False,name=None):ws.append(list(row))
        ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
        for c in ws[1]:c.fill=PatternFill('solid',fgColor='184E69');c.font=Font(name='等线',bold=True,color='FFFFFF')
        for j in range(1,len(cols)+1):ws.column_dimensions[get_column_letter(j)].width=22
    start=len(g)+5;ws.cell(start,1,'局部峰形3D图；A/B共用强度轴0–100,000' if k==4 else '局部峰形3D图')
    im=ExcelImage(str(OUT/f'3D_{key}_峰形对齐.png'));im.width,im.height=972,598;ws.add_image(im,f'A{start+2}')
    ws.sheet_view.showGridLines=False
    for _,r in g.iterrows():panel_records.append({'图面板':key,'氨基酸':r['氨基酸'],'文件':r['文件'],'平均峰高':r['各次峰高的均值'],'CV_%':r['峰高CV_%']})
wb['说明'].append(['10^4拆图规则','按所选组各次峰高均值从低到高排序，前4种为A、后4种为B；两图强度轴都为0–100,000，其余数据不变。'])
ws=wb.create_sheet('18种绘图窗口核查')
ws.append(list(window_checks[0].keys()))
for row in window_checks:ws.append(list(row.values()))
ws.freeze_panes='A2'
wb.save(xlsx)
pd.DataFrame(panel_records).to_csv(OUT/'分图对应表.csv',index=False,encoding='utf-8-sig')

# Font-independent image PDFs: complete set, and the requested pair only.
from PIL import Image as PillowImage
def image_pdf(paths,path):
    pages=[PillowImage.open(p).convert('RGB') for p in paths]
    pages[0].save(path,save_all=True,append_images=pages[1:],resolution=240,quality=95)
    for p in pages:p.close()
image_pdf(page_paths,OUT/'氨基酸_ISO_分图版_字体兼容.pdf')
image_pdf([OUT/'3D_10^4A_原始m_z.png',OUT/'3D_10^4B_原始m_z.png'],OUT/'10^4组_AB两张图.pdf')

# Rebuild the interactive version with one plot open at a time to limit WebGL use.
specs=[];titles=[]
for key,k,g in groups:
    for aligned in [False,True]:
        f=go.Figure();xlimits=display_limits(g,aligned)
        for i,(_,r) in enumerate(g.iterrows()):
            t=traces[r['文件']];xx=t['x']-t['anchor'] if aligned else t['x'];v=t['mean']/(10**k)
            color=PALETTE[(i+(4 if key=='10^4B' else 0))%len(PALETTE)]
            f.add_trace(go.Scatter3d(x=list(xlimits),y=[i,i],z=[0,0],mode='lines',line=dict(color=color,width=2),showlegend=False,legendgroup=r['氨基酸'],hovertemplate='零强度参考线<extra></extra>'))
            f.add_trace(go.Scatter3d(x=xx.tolist(),y=[i]*len(xx),z=v.tolist(),mode='lines',line=dict(color=color,width=3),legendgroup=r['氨基酸'],
                name=f"{i+1:02d} {r['氨基酸']} · n={r['重复数n']} · CV={r['峰高CV_%']:.1f}%",customdata=t['x'].tolist(),hovertemplate=r['氨基酸']+'<br>原始m/z=%{customdata:.5f}<br>强度倍率值=%{z:.4f}<extra></extra>'))
            for edge,flag in [(0,t.get('left_open',False)),(-1,t.get('right_open',False))]:
                if flag:f.add_trace(go.Scatter3d(x=[float(xx[edge])],y=[i],z=[float(v[edge])],mode='markers',marker=dict(symbol='circle-open',size=5,color=color),showlegend=False,hovertemplate='局部数据边界仍有背景，未强制归零<extra></extra>'))
        title=key+('｜局部峰形' if aligned else '｜原始m/z');titles.append(title)
        f.update_layout(title=title,height=650,margin=dict(l=0,r=0,b=0,t=45),font=dict(family='AminoISO',size=14),paper_bgcolor='white',
            scene=dict(xaxis=dict(title='Δm/z' if aligned else '原始m/z',range=list(xlimits)),
                       yaxis=dict(title='序号',tickvals=list(range(len(g))),ticktext=[f'{i+1:02d}' for i in range(len(g))]),
                       zaxis=dict(title=f'原始强度 / {10**k:,}',range=[0,10] if k==4 else None,rangemode='tozero'),
                       aspectmode='manual',aspectratio=dict(x=2.6,y=.85,z=.85),camera=dict(eye=dict(x=1.2,y=-2.1,z=1.0))))
        specs.append(f.to_json())
from plotly.offline import get_plotlyjs
font_data=base64.b64encode(font_path.read_bytes()).decode('ascii')
html='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ISO分图版</title><style>'
html+='@font-face{font-family:AminoISO;src:url(data:font/otf;base64,'+font_data+") format('opentype');}body{font:16px AminoISO,sans-serif;margin:24px;color:#173647}details{border:1px solid #ccd8de;padding:14px;margin:16px 0}summary{cursor:pointer;font-size:20px}</style>"
html+='<h1>氨基酸ISO统一风格版</h1><p>10^4组按峰高拆成A/B，各4种；两图强度轴相同。数据、选组与实测峰宽未改。展开一张图可旋转和缩放。</p>'
html+='<p>全部18种均使用实测局部尾部；空心端点表示局部边界仍有背景信号，没有人为补零。</p>'
html+=''.join(f'<details data-i="{i}"><summary>{title}</summary><div id="plot_{i}"></div></details>' for i,title in enumerate(titles))
html+='<script>'+get_plotlyjs()+'</script><script>const specs=['+','.join(specs)+'];const ready=document.fonts.load("14px AminoISO","氨基酸原始强度序号");'
html+='document.querySelectorAll("details").forEach(d=>d.addEventListener("toggle",async()=>{const i=+d.dataset.i;if(!d.open){if(document.getElementById("plot_"+i).data)Plotly.purge("plot_"+i);return;}document.querySelectorAll("details").forEach(o=>{if(o!==d)o.open=false;});await ready;if(d.open)await Plotly.newPlot("plot_"+i,specs[i].data,specs[i].layout,{responsive:true,displaylogo:false});}));document.querySelector("details").open=true;</script></html>'
(OUT/'氨基酸_ISO_分图版_可旋转.html').write_text(html,encoding='utf-8')

for name in ['选组与强度分组.csv','分组均值谱_原始m_z.csv','全部重复测量_峰高记录.csv']:
    baseline=B/'output_v3'/name
    if name=='选组与强度分组.csv' and baseline.exists():assert baseline.read_bytes()==(OUT/name).read_bytes()
for _,r in summary.iterrows():
    values=rep.loc[rep['文件']==r['文件'],'原始峰高']
    assert np.isclose(values.mean(),r['各次峰高的均值'])
    assert np.isclose(values.std(ddof=1),r['各次峰高的SD'])
assert len({a for key,k,g in groups for a in g['氨基酸']})==18
print(pd.DataFrame(panel_records).to_string(index=False))
print('PASS: 10^4 split into 4+4; both intensity axes 0–100,000; peak statistics unchanged; measured tails checked for all spectra; no missing or duplicate amino acids.')

