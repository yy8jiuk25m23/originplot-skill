from pathlib import Path
import os,json,math,zipfile,hashlib,shutil
os.environ['MPLCONFIGDIR']=str(Path(__file__).resolve().parent/'mplconfig')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
from openpyxl.drawing.image import Image as ExcelImage

B=Path(__file__).resolve().parent;O=B/'output'
summary=pd.read_csv(O/'衍生前后_强度与比值.csv')
files=pd.read_csv(O/'衍生后_全部组比较.csv')
rep=pd.read_csv(O/'衍生后_逐次峰高.csv')
before=pd.read_csv(B/'before_reference.csv')
meta=json.loads((B/'analysis_meta.json').read_text())
z=np.load(B/'derivative_candidate_windows.npz')
for p in [B/'chinese_regular.otf',B/'chinese_bold.otf']:font_manager.fontManager.addfont(str(p))
plt.rcParams.update({'font.family':['Noto Sans CJK SC','DejaVu Sans'],'axes.unicode_minus':False,
                     'mathtext.fontset':'dejavusans','font.size':11,'savefig.facecolor':'white'})
RED='#B74343';BLUE='#24668A';AMBER='#AF7A24';INK='#183D50';GREY='#6C7B85'
valid=summary[summary['可比较']].copy()
valid['需核对']=False
summary['变化说明']='缺衍生后数据'
for idx,r in summary[summary['可比较']].iterrows():
    ratio=r['后_前比值R'];pct=r['变化_%']
    summary.loc[idx,'变化说明']=(f'后为前{ratio:,.3f}倍；增加{pct:,.1f}%' if ratio>1 else f'降为原来的{ratio*100:.2f}%；减少{abs(pct):.1f}%')
summary.to_csv(O/'衍生前后_强度与比值.csv',index=False,encoding='utf-8-sig')

# 1. Fold-change ranking: a neutral line at R=1, direct ratio tick labels.
fig,ax=plt.subplots(figsize=(15,11))
fig.subplots_adjust(left=.18,right=.86,top=.84,bottom=.19)
ys=np.arange(len(valid));xs=valid['log2比值'].to_numpy()
colors=[AMBER if r['需核对'] else (RED if r['后_前比值R']>1 else BLUE) for _,r in valid.iterrows()]
ax.barh(ys,xs,color=colors,height=.60,alpha=.86)
ax.scatter(xs,ys,color=colors,s=24,zorder=4)
ax.axvline(0,color=INK,lw=1.0)
ax.set_yticks(ys);ax.set_yticklabels([r['氨基酸']+('（待核对）' if r['需核对'] else '') for _,r in valid.iterrows()],fontsize=12)
ax.invert_yaxis();ax.set_xlim(-3.8,13.8)
ticks=[-3,-1,0,1,3,5,7,9,11]
ax.set_xticks(ticks);ax.set_xticklabels(['0.125','0.5','1','2','8','32','128','512','2048'])
ax.set_xlabel('衍生后 / 衍生前 信号比值 R（对数间隔；1 为不变）',labelpad=13)
for y,(_,r) in enumerate(valid.iterrows()):
    ratio=r['后_前比值R'];pct=r['变化_%'];label=f'{ratio:,.2f} 倍  ({pct:+,.1f}%)'
    ax.text(xs[y]+.14,y,label,va='center',fontsize=11,color=colors[y],bbox=dict(facecolor='white',edgecolor='none',pad=.8,alpha=.9))
ax.spines[['top','right','left']].set_visible(False);ax.tick_params(axis='y',length=0,pad=8)
ax.grid(axis='x',color='#D8E1E6',lw=.5,alpha=.6);ax.set_axisbelow(True)
fig.suptitle('氨基酸衍生前后｜信号变化一览',x=.055,y=.97,ha='left',fontsize=24,fontweight='bold',color=INK)
fig.text(.055,.905,'按衍生后ISO的实测主峰定位，保留实际质量偏移；红色表示数值增加，蓝色表示减少。',fontsize=12,color=GREY)
fig.text(.055,.075,'R = 衍生后 / 衍生前；R=2表示增强至原来的2倍，即增加100%。未进行逐物质归一化。',fontsize=11,color=GREY)
fig.text(.055,.047,'甘氨酸缺衍生后数据；精氨酸仅数值增加5.9%，方向对选组敏感。此图不表示统计显著性。',fontsize=11,color=GREY)
fig.savefig(O/'01_衍生前后_变化倍数.png',dpi=240);plt.close(fig)

# 2. Absolute intensities: before/after on a common log scale, no normalization.
fig,ax=plt.subplots(figsize=(15,11));fig.subplots_adjust(left=.16,right=.94,top=.84,bottom=.12)
for y,(_,r) in enumerate(valid.iterrows()):
    c=AMBER if r['需核对'] else (RED if r['后_前比值R']>1 else BLUE)
    ax.plot([r['衍生前平均峰高'],r['衍生后平均峰高']],[y,y],color=c,lw=1.8,alpha=.7)
ax.scatter(valid['衍生前平均峰高'],ys,s=50,facecolors='white',edgecolors=GREY,lw=1.5,zorder=4,label='衍生前')
ax.scatter(valid['衍生后平均峰高'],ys,s=48,c=colors,zorder=5,label='衍生后')
ax.set_xscale('log');ax.set_xlim(2e3,6e7);ax.set_yticks(ys);ax.set_yticklabels(valid['氨基酸'],fontsize=13);ax.invert_yaxis()
ax.set_xlabel('原始离子强度（各次目标峰高的平均值；对数坐标）',labelpad=12)
ax.spines[['top','right','left']].set_visible(False);ax.tick_params(axis='y',length=0,pad=8)
ax.grid(axis='x',which='major',color='#D8E1E6',lw=.6);ax.legend(frameon=False,loc='upper left')
fig.suptitle('衍生前后｜原始离子强度对比',x=.055,y=.97,ha='left',fontsize=24,fontweight='bold',color=INK)
fig.text(.055,.905,'空心点为衍生前，实心点为衍生后；向右表示增强，向左表示减弱。',fontsize=12,color=GREY)
fig.text(.055,.055,'按各自实测主峰比较，未将各物质归一化为同一高度；甘氨酸缺衍生后数据。',fontsize=11,color=GREY)
fig.savefig(O/'02_衍生前后_原始强度.png',dpi=240);plt.close(fig)

# 3. A shareable image table gives the exact amounts without reading a workbook.
fig,ax=plt.subplots(figsize=(19,11.5));ax.axis('off');fig.subplots_adjust(left=.025,right=.975,top=.84,bottom=.11)
rows=[];rowcolors=[]
for _,r in summary.iterrows():
    if not r['可比较']:
        rows.append([r['氨基酸'],f"{r['衍生前平均峰高']:,.0f}",'—','—','—','缺数据','不计为下降']);rowcolors.append('#F0F2F3');continue
    ratio=r['后_前比值R'];pct=r['变化_%'];pending=False
    tip=[]
    if pending:tip.append('目标/邻峰待核对')
    if r['组间方向']=='方向对选组敏感':tip.append('组间方向敏感')
    elif max(r['衍生前CV_%'],r['衍生后CV_%'])>30:tip.append('重复波动较大')
    rows.append([r['氨基酸'],f"{r['衍生前平均峰高']:,.0f}",f"{r['衍生后平均峰高']:,.0f}",f'{ratio:,.3f}',f'{pct:+,.1f}%',r['数值方向'],'；'.join(tip) or '描述性比较'])
    rowcolors.append('#FFF3DD' if pending else ('#FAEEEE' if ratio>1 else '#E8F1F7'))
labels=['氨基酸','衍生前平均强度','衍生后平均强度','后/前 比值R','变化百分比','数值方向','结果提示']
table=ax.table(cellText=rows,colLabels=labels,cellLoc='center',colWidths=[.11,.16,.16,.12,.14,.08,.23],bbox=[0,0,1,1])
table.auto_set_font_size(False);table.set_fontsize(12)
for (row,col),cell in table.get_celld().items():
    cell.set_edgecolor('white');cell.set_linewidth(1.2)
    if row==0:cell.set_facecolor(INK);cell.set_text_props(color='white',weight='bold')
    else:
        cell.set_facecolor(rowcolors[row-1])
        if col==6:cell.set_text_props(fontsize=10)
        if col in [0,3,5]:cell.set_text_props(weight='bold')
fig.suptitle('氨基酸衍生前后｜强度与变化表',x=.035,y=.97,ha='left',fontsize=25,fontweight='bold',color=INK)
fig.text(.035,.905,'比值R = 衍生后 / 衍生前；变化百分比 = (R−1) × 100%。例如R=2，表示变为2倍，即增加100%。',fontsize=13,color=GREY)
fig.text(.035,.055,'强度为原始实测主峰峰高均值，按变化倍数排序；精氨酸变化小且对选组敏感。',fontsize=12,color=GREY)
fig.text(.035,.026,'甘氨酸未提供衍生后文件。表中增加/减少是当前文件的数值比较，不代表统计显著性或衍生反应转化率。',fontsize=12,color=GREY)
fig.savefig(O/'03_衍生前后_一眼对比表.png',dpi=220);plt.close(fig)

# 4. Audit the derivative target and its neighboring peak, not the full spectrum.
fig,axes=plt.subplots(6,3,figsize=(17,19));fig.subplots_adjust(left=.06,right=.98,top=.92,bottom=.04,hspace=.70,wspace=.32)
for ax,(_,r) in zip(axes.flat,valid.iterrows()):
    aa=r['氨基酸'];aa_files=files[files['氨基酸']==aa];anchor=float(aa_files['目标实测锚点m/z'].iloc[0])
    for _,ff in aa_files.iterrows():
        a=z[Path(ff['文件']).stem];keep=(a[:,0]>=anchor-1.0)&(a[:,0]<=anchor+1.5)
        c=RED if ff['选用'] else '#AAB6BD'
        ax.plot(a[keep,0],a[keep,1:].mean(axis=1),color=c,lw=1.3 if ff['选用'] else .8,label=Path(ff['文件']).stem)
    ax.axvspan(anchor-.35,anchor+.35,facecolor=AMBER if r['需核对'] else BLUE,alpha=.12)
    ax.axvline(anchor,color=INK,ls=':',lw=.7)
    ax.set_title(aa+f'｜目标约{anchor:.3f}',loc='left',fontsize=12,color=AMBER if r['需核对'] else INK)
    ax.ticklabel_format(axis='y',style='sci',scilimits=(0,0));ax.set_xlabel('原始m/z',fontsize=9);ax.set_ylabel('强度均值',fontsize=9)
    ax.spines[['top','right']].set_visible(False);ax.legend(frameon=False,fontsize=7,loc='upper right')
for ax in axes.flat[len(valid):]:ax.axis('off')
fig.suptitle('衍生后目标峰定位核查｜仅ISO局部数据',fontsize=23,fontweight='bold',x=.04,ha='left')
fig.text(.04,.94,'阴影为实测主峰取峰窗口；红线为优选文件，灰线为其他组。按用户确认接受实测质量偏移。',fontsize=11,color=GREY)
fig.savefig(O/'04_衍生后_目标峰核查.png',dpi=180);plt.close(fig)

notes=[
('数据来源','衍生前沿用已完成的18种ISO优选组；衍生后只使用本轮最后一次上传的33个文件，共17种。没有读取任何全谱文件。'),
('比较条件','用户确认衍生前后氨基酸用量、进样量及采集/缩放条件相同或已校正；y1、y2…沿用重复测量解释。'),
('主要指标','R=衍生后目标峰高均值/衍生前目标峰高均值；百分比=(R−1)×100%。R=2表示变为2倍，即增加100%，不是增加200%。'),
('信号含义','本比较是目标离子信号响应变化，不能单凭强度比推断反应转化率、总氨基酸含量或统计显著性。'),
('质量定位','用户确认衍生后约增加250 Da且接受实际质量偏移。以理论母体[M+H]+加250 Da为线索，在±2 Da局部区域定位该氨基酸ISO的共同实测主峰。'),
('目标峰选择','同种氨基酸各文件的均值谱等权确定共同实测主峰，再用共用锚点±0.35 Da取各次原始峰高。仅定位锚点时对网格作插值；峰高取自各文件原始采样点。'),
('衍生前口径','沿用此前公布的同一原始目标局部峰高（共用实测锚点±0.45 Da内逐次最大值），不重新挑选以放大增强效果。前后均比较峰高而非面积。'),
('本次用户确认','用户要求按实测偏移结果处理并删除星号。因此缬氨酸使用约368.71、谷氨酸使用约398.67、谷氨酰胺使用约397.87的实测主峰；强度、CV和比值均同步重新计算。'),
('组选择','衍生后沿用原先规则：n≥2；先比较正信号重复占比，再优先低CV；CV与最低相差<1个百分点时优先n更多，再按较低CV排序。完全不以信号更高或倍数更大作为优选标准。'),
('统计定义','均值为各次峰高的算术均值；SD为样本标准差(ddof=1)，CV=SD/均值×100%。不删离群值，不平滑、不扣基线、不逐物质归一化；正值不等同经LOD验证的检出。'),
('单次测量','组氨酸2、色氨酸2各仅1次，无法计算CV，保留记录但不选作优选组。'),
('不同n与配对','前后n不同，采用独立组均值之比，不按y列强行一一配对，不计算没有设计依据的配对检验。'),
('组间敏感性','所有n≥2文件组合的最小R=最小衍生后组均值/最大衍生前组均值，最大R反之；这只是选组敏感性范围，不是置信区间。精氨酸范围跨过1倍。'),
('缺失','甘氨酸没有本轮衍生后文件，列为缺数据，不能按0处理或算作下降。'),
('结论边界','增加/减少列表示当前优选组的数值方向。变化小或重复波动较大者应结合重复性解释，不将星号用作显著性标记。'),
('表格可追溯性','衍生后全部组、逐次峰高、衍生前参考值和源文件SHA256均保留；Excel结果公式与CSV可相互核对。'),
]
(O/'方法与注意事项.md').write_text('# 氨基酸衍生前后信号比较\n\n'+'\n\n'.join(f'**{k}**：{v}' for k,v in notes),encoding='utf-8')

front=['氨基酸','数值方向','衍生前平均峰高','衍生后平均峰高','后_前比值R','变化_%','变化说明','结论提示']
ordered=summary[front+[c for c in summary.columns if c not in front]]
xlsx=O/'氨基酸_衍生前后_强度比值.xlsx'
with pd.ExcelWriter(xlsx,engine='openpyxl') as writer:
    ordered.to_excel(writer,sheet_name='一眼对比_按倍数排序',index=False)
    files.to_excel(writer,sheet_name='衍生后33组_筛选依据',index=False)
    rep.to_excel(writer,sheet_name='衍生后全部重复_峰高',index=False)
    before.to_excel(writer,sheet_name='衍生前18种_既定优选组',index=False)
    pd.read_csv(B/'before_all_groups.csv').drop(columns=['源路径'],errors='ignore').to_excel(writer,sheet_name='衍生前全部组_敏感性',index=False)
    pd.DataFrame(notes,columns=['项目','说明']).to_excel(writer,sheet_name='方法与注意事项',index=False)
    pd.read_csv(B/'candidate_files.csv').drop(columns=['源路径']).to_excel(writer,sheet_name='衍生后源文件_SHA256',index=False)
    for ws in writer.book.worksheets:
        ws.freeze_panes='B2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.showGridLines=False
        for c in ws[1]:c.fill=PatternFill('solid',fgColor='183D50');c.font=Font(name='等线',bold=True,color='FFFFFF');c.alignment=Alignment(wrap_text=True,vertical='center')
        ws.row_dimensions[1].height=38
        for j in range(1,ws.max_column+1):
            title=str(ws.cell(1,j).value)
            width=22
            if title in ['结论提示','选组依据','变化说明']:width=65
            if title=='说明':width=125
            if title=='SHA256':width=70
            ws.column_dimensions[get_column_letter(j)].width=width
        for row in ws.iter_rows(min_row=2):
            for c in row:
                if isinstance(c.value,float):c.number_format='0.000' if 'm/z' in str(ws.cell(1,c.column).value) or '比值' in str(ws.cell(1,c.column).value) else '#,##0.00'
        if ws.title=='方法与注意事项':
            for row in ws.iter_rows(min_row=2):
                for c in row:c.alignment=Alignment(wrap_text=True,vertical='center')
                ws.row_dimensions[row[0].row].height=58
    ws=writer.book['一眼对比_按倍数排序']
    for i,(_,r) in enumerate(summary.iterrows(),start=2):
        color='F0F2F3' if not r['可比较'] else ('FAEEEE' if r['后_前比值R']>1 else 'E8F1F7')
        for c in ws[i]:c.fill=PatternFill('solid',fgColor=color)
        if r['可比较']:
            # Excel formulas encode the same ratio/percent definitions as the images.
            ws.cell(i,5,f'=D{i}/C{i}');ws.cell(i,6,f'=(E{i}-1)*100')
    for title,path in [('变化倍数图','01_衍生前后_变化倍数.png'),('原始强度图','02_衍生前后_原始强度.png'),('一眼对比图片','03_衍生前后_一眼对比表.png'),('目标峰核查图','04_衍生后_目标峰核查.png')]:
        ws=writer.book.create_sheet(title);im=ExcelImage(str(O/path));factor=1100/im.width;im.width=1100;im.height=int(im.height*factor);ws.add_image(im,'A1')

# Cache the known, validated formula values for Excel previewers that do not
# recalculate formulas. The editable formulas themselves remain in the workbook.
import xml.etree.ElementTree as ET
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
with zipfile.ZipFile(xlsx) as zin:
    payload={name:zin.read(name) for name in zin.namelist()}
sheet=ET.fromstring(payload['xl/worksheets/sheet1.xml'])
cells={c.attrib['r']:c for c in sheet.iter('{'+NS+'}c')}
for i,(_,r) in enumerate(summary.iterrows(),start=2):
    if not r['可比较']:continue
    for column,value in [('E',r['后_前比值R']),('F',r['变化_%'])]:
        cell=cells[f'{column}{i}'];v=cell.find('{'+NS+'}v')
        if v is None:v=ET.SubElement(cell,'{'+NS+'}v')
        v.text=repr(float(value))
payload['xl/worksheets/sheet1.xml']=ET.tostring(sheet,encoding='utf-8',xml_declaration=True)
with zipfile.ZipFile(xlsx,'w',zipfile.ZIP_DEFLATED) as zout:
    for name,data in payload.items():zout.writestr(name,data)

# Validate values and retain a machine-readable short summary.
for _,r in valid.iterrows():
    assert np.isclose(r['后_前比值R'],r['衍生后平均峰高']/r['衍生前平均峰高'])
    assert np.isclose(r['变化_%'],(r['后_前比值R']-1)*100)
assert summary.loc[summary['氨基酸']=='甘氨酸','后_前比值R'].isna().all()
report={'n_compared':len(valid),'numerical_increases':int((valid['后_前比值R']>1).sum()),
        'numerical_decreases':int((valid['后_前比值R']<1).sum()),'missing':['甘氨酸'],
        'target_review':[],'mass_shift_handling':'按用户确认，采用ISO实测主峰，接受质量偏移',
        'maximum_ratio_amino_acid':valid.iloc[0]['氨基酸']}
(O/'结果摘要.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))
print('PASS: ratios and percentages verified; missing data not zero; Excel formulas and 4 PNG images exported.')
