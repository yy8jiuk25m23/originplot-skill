from pathlib import Path
import json, shutil
import numpy as np
import pandas as pd

B=Path(__file__).resolve().parent
OUT=B/'output';OUT.mkdir(exist_ok=True)
for src,dst in [('/workspace/amino_iso/output_v6/选组与强度分组.csv','before_reference.csv'),
                ('/workspace/amino_iso/common_peak_metrics.csv','before_all_groups.csv'),
                ('/workspace/amino_iso/target_windows.npz','before_target_windows.npz')]:
    if not (B/dst).exists():shutil.copy2(src,B/dst)
before=pd.read_csv(B/'before_reference.csv')
before_all=pd.read_csv(B/'before_all_groups.csv')
sources=pd.read_csv(B/'candidate_files.csv')
windows=np.load(B/'derivative_candidate_windows.npz')
# Keep the common shift as descriptive metadata. User confirmed that measured
# peak shifts are expected: locate the local observed parent-region main peak.
shift=float(np.median(sources['候选区最强m/z']-sources['理论母体m/z']))
assert 248<shift<252
records=[];repeats=[];anchors={}
for aa,group in sources.groupby('氨基酸',sort=False):
    expected=float(group['理论母体m/z'].iloc[0])+250
    grid=windows[Path(group['文件'].iloc[0]).stem][:,0]
    pooled=np.mean([np.interp(grid,windows[Path(s['文件']).stem][:,0],windows[Path(s['文件']).stem][:,1:].mean(axis=1)) for _,s in group.iterrows()],axis=0)
    search=np.abs(grid-expected)<=2.0
    anchor=float(grid[np.flatnonzero(search)[np.argmax(pooled[search])]])
    positions=[]
    for _,src in group.iterrows():
        a=windows[Path(src['文件']).stem];x=a[:,0];mean=a[:,1:].mean(axis=1)
        maxima=np.flatnonzero((mean[1:-1]>mean[:-2])&(mean[1:-1]>=mean[2:]))+1
        candidates=maxima[np.abs(x[maxima]-anchor)<=.35]
        if not len(candidates):
            broad=maxima[np.abs(x[maxima]-expected)<=1.3]
            assert len(broad), f'No derivative candidate for {src["文件"]}'
            candidates=broad[mean[broad]>=mean[broad].max()*.05]
        idx=candidates[np.argmax(mean[candidates])]
        positions.append(float(x[idx]))
    anchor=float(np.median(positions));anchors[aa]=anchor
    for _,src in group.iterrows():
        name=src['文件'];a=windows[Path(name).stem];x=a[:,0];values=a[:,1:]
        core=np.abs(x-anchor)<=.35
        v=values[core];xx=x[core];n=v.shape[1]
        heights=v.max(axis=0);pos=xx[v.argmax(axis=0)]
        mean=float(heights.mean());sd=float(heights.std(ddof=1)) if n>1 else np.nan
        cv=sd/mean*100 if n>1 and mean>0 else np.nan
        avg=values.mean(axis=1);target_peak=float(avg[core].max())
        neighbor=(x-anchor>=.50)&(x-anchor<=1.35)
        neighbor_peak=float(avg[neighbor].max())
        for j in range(n):
            repeats.append({'氨基酸':aa,'文件':name,'重复列':f'y{j+1}',
                '目标实测锚点m/z':anchor,'原始目标峰高':float(heights[j]),'实测峰顶m/z':float(pos[j]),
                '峰顶触边':bool(v[:,j].argmax() in [0,len(xx)-1])})
        records.append({'氨基酸':aa,'文件':name,'重复数n':n,'原始目标峰高均值':mean,'峰高SD':sd,
            '峰高CV_%':cv,'正信号重复数':int((heights>0).sum()),'目标实测锚点m/z':anchor,
            '均值谱峰顶m/z':float(xx[avg[core].argmax()]),'均值谱目标峰高':target_peak,
            '邻近高m_z峰高':neighbor_peak,'邻峰_目标峰比':neighbor_peak/target_peak if target_peak>0 else np.nan,
            '实测相对理论母体增量':anchor-float(src['理论母体m/z']),
            '偏离共同增量_Da':anchor-expected,
            '目标归属需复核':False,
            '峰位SD_Da':float(pos.std(ddof=1)) if n>1 else np.nan,
            '峰顶触边重复数':int(np.count_nonzero((v.argmax(0)==0)|(v.argmax(0)==len(xx)-1))),
            'SHA256':src['SHA256']})
files=pd.DataFrame(records);files['选用']=False;files['选组依据']=''
for aa,g in files.groupby('氨基酸',sort=False):
    eligible=g[(g['重复数n']>=2)&g['峰高CV_%'].notna()].copy()
    assert len(eligible),aa
    frac=eligible['正信号重复数']/eligible['重复数n']
    eligible=eligible[frac==frac.max()]
    low=eligible['峰高CV_%'].min();eligible=eligible[eligible['峰高CV_%']<low+1]
    idx=eligible.sort_values(['重复数n','峰高CV_%'],ascending=[False,True]).index[0]
    files.loc[idx,'选用']=True
    for j,r in g.iterrows():
        files.loc[j,'选组依据']='选用：优先正信号完整，再比较低CV；CV差<1个百分点优先n较多' if j==idx else ('n=1，无法估计重复性，不参与优选' if r['重复数n']==1 else '未选用；保留全部测量')
chosen=files[files['选用']].set_index('氨基酸')
summary=[]
for _,pre in before.iterrows():
    aa=pre['氨基酸']
    r={'氨基酸':aa,'衍生前平均峰高':float(pre['各次峰高的均值']),
       '衍生前SD':float(pre['各次峰高的SD']),'衍生前CV_%':float(pre['峰高CV_%']),
       '衍生前n':int(pre['重复数n']),'衍生前文件':pre['文件'],'衍生前实测m/z':pre['均值谱峰顶m/z']}
    if aa not in chosen.index:
        r.update({'数值方向':'缺衍生后数据','结论提示':'未提供衍生后文件，不算作下降','可比较':False})
    else:
        post=chosen.loc[aa];p=float(post['原始目标峰高均值']);q=r['衍生前平均峰高'];ratio=p/q
        after_group=files[(files['氨基酸']==aa)&(files['重复数n']>=2)]['原始目标峰高均值']
        pre_group=before_all[(before_all['氨基酸']==aa)&(before_all['重复数n']>=2)]['各次峰高的均值']
        minratio=float(after_group.min()/pre_group.max());maxratio=float(after_group.max()/pre_group.min())
        tips=[]
        if minratio<1<maxratio:tips.append('不同组组合可跨越1倍，变化方向对选组敏感')
        if max(pre['峰高CV_%'],post['峰高CV_%'])>30:tips.append('重复波动较大')
        if .9<=ratio<=1.1:tips.append('幅度小，不能据此认定显著变化')
        r.update({'衍生后平均峰高':p,'衍生后SD':post['峰高SD'],'衍生后CV_%':post['峰高CV_%'],
            '衍生后n':int(post['重复数n']),'衍生后文件':post['文件'],'衍生后实测m/z':post['均值谱峰顶m/z'],
            '后_前比值R':ratio,'变化_%':(ratio-1)*100,'绝对强度差':p-q,'log2比值':float(np.log2(ratio)) if ratio>0 else np.nan,
            '数值方向':'增加' if ratio>1 else ('减少' if ratio<1 else '不变'),
            '所有组组合_最小R':minratio,'所有组组合_最大R':maxratio,
            '组间方向':'方向一致' if minratio>1 or maxratio<1 else '方向对选组敏感',
            '目标质量增量':post['实测相对理论母体增量'],'邻峰_目标峰比':post['邻峰_目标峰比'],
            '目标归属需复核':post['目标归属需复核'],
            '结论提示':'；'.join(tips) or '按当前文件的描述性比较','可比较':True})
    summary.append(r)
summary=pd.DataFrame(summary).sort_values('后_前比值R',ascending=False,na_position='last').reset_index(drop=True)
repeat=pd.DataFrame(repeats);repeat['选用组']=repeat['文件'].isin(files.loc[files['选用'],'文件'])
summary.to_csv(OUT/'衍生前后_强度与比值.csv',index=False,encoding='utf-8-sig')
files.to_csv(OUT/'衍生后_全部组比较.csv',index=False,encoding='utf-8-sig')
repeat.to_csv(OUT/'衍生后_逐次峰高.csv',index=False,encoding='utf-8-sig')
(B/'analysis_meta.json').write_text(json.dumps({'observed_common_shift':shift,'after_target_half_width':.35,
    'after_anchors':anchors,'derivative_files':len(files),'after_repeats':len(repeat),
    'matched_amino_acids':int(summary['可比较'].sum()),'missing':summary.loc[~summary['可比较'],'氨基酸'].tolist()},ensure_ascii=False,indent=2))
assert len(summary)==18 and summary['可比较'].sum()==17 and len(files)==33
assert np.allclose(summary.loc[summary['可比较'],'后_前比值R'],summary.loc[summary['可比较'],'衍生后平均峰高']/summary.loc[summary['可比较'],'衍生前平均峰高'])
print('Coherent measured mass increment:',shift)
print(summary[['氨基酸','衍生前平均峰高','衍生后平均峰高','后_前比值R','变化_%','衍生后CV_%','数值方向','结论提示']].to_string(index=False))
print('AFTER FILES\n',files[['氨基酸','文件','重复数n','原始目标峰高均值','峰高CV_%','邻峰_目标峰比','峰顶触边重复数','选用']].to_string(index=False))
