from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd

B=Path(__file__).resolve().parent;O=B/'output';O.mkdir(exist_ok=True)
SCALE=.002

def peak_metrics(x,y):
    finite=np.isfinite(x)&np.isfinite(y)
    complete=bool(finite.all())
    if not finite.any():return {'valid':False,'reason':'no numeric observations'}
    maximum=float(np.max(y[finite]))
    if maximum<=0:return {'valid':False,'reason':'nonpositive maximum; max normalization undefined'}
    available=np.flatnonzero(finite)
    p=int(available[np.argmax(y[finite])])
    max_indices=np.flatnonzero(finite&(y==maximum))
    # All supplied scans have one unique maximum. This deterministic policy is
    # logged so future tied maxima cannot be silently cherry-picked.
    half=maximum/2;left=p;right=p
    while left>0 and finite[left-1] and y[left-1]>=half:left-=1
    while right<len(y)-1 and finite[right+1] and y[right+1]>=half:right+=1
    left_cross=right_cross=np.nan
    if left>0 and finite[left-1] and y[left-1]<half:
        left_cross=float(x[left-1]+(half-y[left-1])*(x[left]-x[left-1])/(y[left]-y[left-1]))
    if right<len(y)-1 and finite[right+1] and y[right+1]<half:
        right_cross=float(x[right]+(half-y[right])*(x[right+1]-x[right])/(y[right+1]-y[right]))
    width=right_cross-left_cross if np.isfinite(left_cross+right_cross) else np.nan
    above=finite&(y>=half)
    components=int(np.count_nonzero(above&~np.r_[False,above[:-1]]))
    flags=[]
    if not complete:flags.append('missing_numeric_points')
    if not np.isfinite(width):flags.append('no_complete_half_height_crossings')
    if p in [0,len(y)-1]:flags.append('peak_at_acquisition_boundary')
    if len(max_indices)>1:flags.append('tied_maximum')
    return {'valid':True,'reason':'','n_numeric':int(finite.sum()),'n_missing':int((~finite).sum()),
            'I_max':maximum,'peak_index_0based':p,'peak_X':float(x[p]),'peak_mV_assumed':float(x[p]*SCALE),
            'maximum_tie_count':len(max_indices),'maximum_tie_X_min':float(x[max_indices[0]]),
            'maximum_tie_X_max':float(x[max_indices[-1]]),'left_half_X':left_cross,'right_half_X':right_cross,
            'FWHM_X':width,'left_half_mV_assumed':left_cross*SCALE,'right_half_mV_assumed':right_cross*SCALE,
            'FWHM_mV_assumed':width*SCALE,'half_height_component_count':components,
            'shape_complete':bool(np.isfinite(width)),'acquisition_flag_count':len(flags),'flags':';'.join(flags)}

metadata=json.loads((B/'raw_metadata.json').read_text())
rows=[];summaries=[];representatives={};group_arrays={}
for group in ['D','L']:
    cache=np.load(B/f'{group}_raw_arrays.npz');data=cache['data'];headers=cache['headers'].tolist()
    x=data[:,0];values=data[:,1:]
    assert np.all(np.diff(x)>0)
    norm=np.full_like(values,np.nan)
    group_rows=[]
    for j,name in enumerate(headers[1:]):
        metrics=peak_metrics(x,values[:,j]);record={'sample':group,'sample_name':group+'-Arginine',
            'scan':name,'scan_number':j+1,'source_file':next(m['file'] for m in metadata if m['sample']==group),**metrics}
        if metrics['valid']:
            norm[:,j]=values[:,j]/metrics['I_max']
            assert np.nanmax(norm[:,j])==1.0
            # Multiplicative normalization leaves both measured coordinates and FWHM unchanged.
            check=peak_metrics(x,norm[:,j])
            assert np.isclose(check['FWHM_X'],metrics['FWHM_X'],rtol=1e-10,equal_nan=True)
        group_rows.append(record)
    frame=pd.DataFrame(group_rows);valid=frame[frame['valid']]
    p=valid['peak_X'].to_numpy();w=valid['FWHM_mV_assumed'].to_numpy()
    median=float(np.median(p));mean=float(np.mean(p));sd=float(np.std(p,ddof=1)) if len(p)>1 else np.nan
    distances=np.abs(valid['peak_X']-median)
    tied=valid[np.isclose(distances,distances.min(),atol=1e-12,rtol=0)].copy()
    tied=tied.sort_values(['shape_complete','acquisition_flag_count','scan_number'],ascending=[False,True,True])
    chosen=tied.iloc[0];j=int(chosen['scan_number'])-1
    shift=(mean-float(chosen['peak_X']))*SCALE
    v=x*SCALE;aligned=v+shift
    group_arrays[group]={'x':x,'raw':values,'normalized':norm}
    rep={'sample':group,'scan':chosen['scan'],'scan_number':int(chosen['scan_number']),
         'original_peak_X':float(chosen['peak_X']),'original_peak_mV_assumed':float(chosen['peak_mV_assumed']),
         'mean_peak_X':mean,'mean_peak_mV_assumed':mean*SCALE,'translation_mV':shift,
         'I_max':float(chosen['I_max']),'FWHM_X':float(chosen['FWHM_X']),
         'FWHM_mV_assumed':float(chosen['FWHM_mV_assumed']),
         'median_distance_X':float(abs(chosen['peak_X']-median)),
         'tied_candidate_count':len(tied),'tied_candidate_scans':tied['scan'].tolist()}
    representatives[group]=rep
    assert np.allclose(aligned-v,shift,atol=1e-12,rtol=0)
    assert np.isclose(aligned[int(chosen['peak_index_0based'])],mean*SCALE,atol=1e-10)
    shifted_check=peak_metrics(aligned,norm[:,j])
    assert np.isclose(shifted_check['FWHM_X'],chosen['FWHM_mV_assumed'],rtol=1e-10)
    np.savez_compressed(O/f'{group}_all_scans_normalized.npz',X=x,V_mV_assumed=v,
                       scan_names=np.array(headers[1:]),I_raw=values,I_normalized=norm)
    full=pd.DataFrame({'X_original':x,'V_original_mV_assumed':v,'V_aligned_mV_assumed':aligned,
                       'sample_depth':0.0 if group=='D' else 1.8,'I_raw':values[:,j],
                       'I_normalized':norm[:,j]})
    full.to_csv(O/f'{group}_representative_full.csv.gz',index=False,float_format='%.15g',compression='gzip')
    # Use the requested visible range if it contains the complete dominant peak.
    # Verify the representative's local 0.1%-height neighborhood, without smoothing.
    peak_idx=int(chosen['peak_index_0based']);lo=peak_idx;hi=peak_idx
    while lo>0 and norm[lo-1,j]>.001:lo-=1
    while hi<len(x)-1 and norm[hi+1,j]>.001:hi+=1
    rep['main_peak_0p1percent_left_aligned_mV']=float(aligned[lo])
    rep['main_peak_0p1percent_right_aligned_mV']=float(aligned[hi])
    summaries.append({'sample':group,'sample_name':group+'-Arginine','n_scans_total':len(frame),'n_valid':len(valid),
        'n_invalid':int((~frame['valid']).sum()),'n_FWHM_complete':int(valid['FWHM_mV_assumed'].notna().sum()),
        'peak_X_mean':mean,'peak_X_median':median,'peak_X_SD_sample':sd,
        'peak_mV_mean_assumed':mean*SCALE,'peak_mV_median_assumed':median*SCALE,'peak_mV_SD_sample_assumed':sd*SCALE,
        'peak_mV_min_assumed':float(p.min()*SCALE),'peak_mV_max_assumed':float(p.max()*SCALE),
        'FWHM_mV_mean_assumed':float(np.nanmean(w)),'FWHM_mV_median_assumed':float(np.nanmedian(w)),
        'FWHM_mV_SD_sample_assumed':float(np.nanstd(w,ddof=1)),'FWHM_mV_min_assumed':float(np.nanmin(w)),
        'FWHM_mV_max_assumed':float(np.nanmax(w)),'representative_scan':chosen['scan'],
        'representative_original_peak_mV_assumed':chosen['peak_mV_assumed'],
        'representative_FWHM_mV_assumed':chosen['FWHM_mV_assumed'],'translation_mV':shift,
        'representative_FWHM_after_translation_mV':shifted_check['FWHM_X']})
    frame['distance_to_group_median_X']=np.abs(frame['peak_X']-median)
    frame['representative']=frame['scan']==chosen['scan']
    q1,q3=np.quantile(p,[.25,.75]);iqr=q3-q1
    frame['peak_position_Tukey_outlier_flag']=(frame['peak_X']<q1-1.5*iqr)|(frame['peak_X']>q3+1.5*iqr)
    frame['included_in_group_statistics']=frame['valid']
    frame['group_peak_mean_mV_assumed']=mean*SCALE
    frame['group_peak_SD_mV_assumed']=sd*SCALE
    rows.extend(frame.to_dict('records'))

scan_table=pd.DataFrame(rows);summary=pd.DataFrame(summaries)
delta=abs(summary.loc[summary['sample']=='L','peak_mV_mean_assumed'].iloc[0]-summary.loc[summary['sample']=='D','peak_mV_mean_assumed'].iloc[0])
summary['delta_V_mV_assumed']=delta
scan_table['delta_V_mV_assumed']=delta
xmin=120.0;xmax=160.0
left=min(r['main_peak_0p1percent_left_aligned_mV'] for r in representatives.values())
right=max(r['main_peak_0p1percent_right_aligned_mV'] for r in representatives.values())
if left<xmin or right>xmax:
    xmin=min(xmin,float(np.floor((left-2)/5)*5));xmax=max(xmax,float(np.ceil((right+2)/5)*5))
plots=[]
for group in ['D','L']:
    rep=representatives[group];a=group_arrays[group];j=rep['scan_number']-1
    v=a['x']*SCALE;aligned=v+rep['translation_mV'];keep=(aligned>=xmin)&(aligned<=xmax)
    table=pd.DataFrame({'sample':group+'-Arginine','sample_depth':0.0 if group=='D' else 1.8,
        'representative_scan':rep['scan'],'X_original':a['x'][keep],
        'V_original_mV_assumed':v[keep],'V_aligned_mV_assumed':aligned[keep],
        'I_raw':a['raw'][keep,j],'I_normalized':a['normalized'][keep,j]})
    table.to_csv(O/f'{group}_Origin_XYZ_plot.csv',index=False,float_format='%.15g')
    plots.append(table)
pd.concat(plots,ignore_index=True).to_csv(O/'combined_aligned_plot_data.csv',index=False,float_format='%.15g')
scan_table.to_csv(O/'all_70_scan_peak_statistics.csv',index=False,float_format='%.15g')
summary.to_csv(O/'group_summary_statistics.csv',index=False,float_format='%.15g')
result={'normalization':'I / per-scan maximum; no smoothing, no fitting, no reconstructed peak',
        'voltage_mapping':{'slope_mV_per_X':SCALE,'offset_mV':0,'verified_calibration':False,
           'basis':'User-specified provisional assumption: 150000 sample intervals correspond to 0–300 mV; V=X*300/150000. No calibration metadata found.'},
        'experiment':{'technique':'Ion Cloud Profiling (ICP)','analytes':['D-Arginine','L-Arginine'],
           'additive':'Verapamil Hydrochloride','same_frequency':True,'frequency_Hz':None,
           'voltage_parameter_mV_user_provided':300},
        'representatives':representatives,'delta_V_mV_assumed':float(delta),'plot_x_limits_mV':[xmin,xmax],
        'all_valid_scans_retained':True,'all_data_raw_checksums_preserved':True,
        'FWHM_method':'Nearest left/right Imax/2 crossings enclosing the global maximum; linear interpolation of each crossing only for width measurement. No signal points interpolated for plotting.',
        'peak_tie_policy':'First original X at maximum; all 70 current scans have a unique maximum.',
        'representative_policy':'Minimum absolute distance to group median peak X; only exact-distance ties favor complete half-height shape, fewer acquisition flags, then lower original scan number.',
        'renderer':'Matplotlib mplot3d; Origin unavailable in this Linux instance; fallback accepted by user',
        'font':'Arial'}
(O/'processing_record.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
assert len(scan_table)==70 and scan_table['valid'].all() and scan_table['included_in_group_statistics'].all()
assert int(scan_table['representative'].sum())==2
assert all(np.isclose(row['representative_FWHM_mV_assumed'],row['representative_FWHM_after_translation_mV']) for row in summaries)
print(summary.to_string(index=False))
print('Delta V (provisional mV):',repr(delta))
print('Outlier flags retained:',scan_table.loc[scan_table['peak_position_Tukey_outlier_flag'],['sample','scan','peak_mV_assumed']].to_dict('records'))
print('VALIDATED: 70 scans; per-scan maxima 1; no dropped valid scans; normalization and translation preserve FWHM; source file hashes unchanged.')
