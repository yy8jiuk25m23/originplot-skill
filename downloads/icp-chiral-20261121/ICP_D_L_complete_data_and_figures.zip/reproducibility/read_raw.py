from pathlib import Path
import json,zipfile,xml.etree.ElementTree as ET,re,hashlib,shutil
import numpy as np

B=Path(__file__).resolve().parent
N='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
inputs=json.loads((B/'input_manifest.json').read_text());metadata=[]
for source in inputs:
    p=Path(source['path']);target=B/'raw'/source['file']
    if not p.exists():p=target
    if not target.exists():shutil.copy2(p,target)
    assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(target.read_bytes()).digest()
    with zipfile.ZipFile(target) as z:
        shared=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml'))] if 'xl/sharedStrings.xml' in z.namelist() else []
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        sheet_names=[e.attrib['name'] for e in wb.find(N+'sheets')]
        text_cells=[];other_cells=[];header=None;rowcount=0;skipped=[];nonfinite=0
        capacity=160000;data=None
        # This instrument exported a single sheet with an incorrect A1 dimension;
        # stream its actual XML rows instead of trusting the dimension metadata.
        assert len(sheet_names)==1
        with z.open('xl/worksheets/sheet1.xml') as stream:
            iterator=ET.iterparse(stream,events=('start','end'));_,root=next(iterator)
            for event,row in iterator:
                if event!='end' or row.tag!=N+'row':continue
                entries={}
                for cell in row.findall(N+'c'):
                    ref=cell.attrib['r'];letters=re.match('[A-Z]+',ref)[0];idx=0
                    for ch in letters:idx=idx*26+ord(ch)-64
                    raw=cell.findtext(N+'v');kind=cell.attrib.get('t','')
                    if kind=='s':value=shared[int(raw)] if raw is not None else ''
                    elif kind=='inlineStr':value=''.join(cell.find(N+'is').itertext())
                    elif raw is None:value=None
                    else:
                        try:value=float(raw)
                        except ValueError:value=raw
                    entries[idx-1]=value
                    if isinstance(value,str):text_cells.append({'cell':ref,'text':value})
                    if header is not None and idx-1>=len(header):other_cells.append({'cell':ref,'value':value})
                if header is None:
                    candidate=[entries.get(i) for i in range(max(entries)+1)] if entries else []
                    if candidate and str(candidate[0]).lower()=='x':
                        header=[candidate[0]]+[v for v in candidate[1:] if isinstance(v,str) and re.fullmatch(r'y\d+',v,re.I)]
                        assert len(header)>1
                        data=np.full((capacity,len(header)),np.nan,dtype=np.float64)
                    else:skipped.append(row.attrib.get('r'))
                else:
                    x=entries.get(0)
                    if isinstance(x,(float,int)) and np.isfinite(x):
                        if rowcount>=capacity:
                            capacity*=2;data=np.vstack([data,np.full((len(data),len(header)),np.nan)])
                        values=[entries.get(i,np.nan) for i in range(len(header))]
                        for i,v in enumerate(values):
                            data[rowcount,i]=v if isinstance(v,(float,int)) else np.nan
                        rowcount+=1
                    elif any(i<len(header) and v is not None for i,v in entries.items()):skipped.append(row.attrib.get('r'))
                row.clear();root.clear()
        data=data[:rowcount].copy();assert rowcount>0
        np.savez_compressed(B/f'{source["sample"]}_raw_arrays.npz',data=data,headers=np.array(header))
        meta={**source,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
              'sheet_names':sheet_names,'headers':header,'numeric_rows':rowcount,
              'x_min':float(np.nanmin(data[:,0])),'x_max':float(np.nanmax(data[:,0])),
              'x_strictly_increasing':bool(np.all(np.diff(data[:,0])>0)),
              'x_step_min':float(np.min(np.diff(data[:,0]))),'x_step_max':float(np.max(np.diff(data[:,0]))),
              'nonfinite_counts':np.count_nonzero(~np.isfinite(data),axis=0).tolist(),
              'negative_counts':np.count_nonzero(data<0,axis=0).tolist(),
              'shared_strings':shared,'text_cells':text_cells,'nondata_cells':other_cells,'skipped_rows':skipped,
              'calibration_metadata_found':False,
              'calibration_note':'Text cells, workbook metadata, side settings, and package members inspected. No voltage calibration, range, or X-to-voltage coefficient provided.'}
        metadata.append(meta)
        print(source['sample'],'shape',data.shape,'x range',meta['x_min'],meta['x_max'],'x steps',meta['x_step_min'],meta['x_step_max'],
              'missing',sum(meta['nonfinite_counts']),'negative',sum(meta['negative_counts']),flush=True)
        print('non-data cells',other_cells,flush=True)
(B/'raw_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
print('COMPLETE: original checksums preserved, numeric data cached without interpolation or filling.')
