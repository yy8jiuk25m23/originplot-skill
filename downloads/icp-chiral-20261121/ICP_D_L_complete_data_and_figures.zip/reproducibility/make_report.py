from pathlib import Path
import json,hashlib,shutil
import pandas as pd
import numpy as np
import yaml
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter

B=Path(__file__).resolve().parent;O=B/'output'
record=json.loads((O/'processing_record.json').read_text())
scans=pd.read_csv(O/'all_70_scan_peak_statistics.csv')
groups=pd.read_csv(O/'group_summary_statistics.csv')
plot=pd.read_csv(O/'combined_aligned_plot_data.csv')
metadata=json.loads((B/'raw_metadata.json').read_text())
delta=record['delta_V_mV_assumed']
notes=[
('实验','Ion Cloud Profiling (ICP)；D-Arginine、L-Arginine；添加Verapamil Hydrochloride；两组频率相同。300 mV实验参数来自用户，文件没有提供频率数值。'),
('原始读取','每组150000个有效X采样点，X=0…149999、步长1；每组y1…y35共35条曲线。原始文件各有一个工作表，其A1维度元信息不正确，因此流式读取实际XML单元格。'),
('非数值信息','表头和AM/AN列UI设置被单独记录。D的Relative=True、L的Relative=False，二者强度尺度不同，因此不直接比较原始峰高。未发现扫描电压范围、单位换算或电压标定参数。'),
('电压换算—重要','暂定V_AC(mV)=X×300/150000=X×0.002。此关系是用户指定的线性扫描范围假设，不是已验证的仪器电压标定。所有mV峰位、SD、FWHM和ΔV均随标定斜率变化。末点为299.998 mV，而非将149999强制映射为300 mV。'),
('归一化','每条曲线分别除以其原始最大值，使最大值为1；不扣基线、不平滑、不拟合、不进行峰形重构。所有原始数值与归一化数组均保存。'),
('有效扫描','70条扫描均有完整数值、非负信号和正最大值，均有效并全部纳入总体统计；未删去任何异常值。'),
('峰位','每条曲线在全部150000个点中找全局最高峰，当前70条均有唯一最高值。后续若最大值重复则采用原始X最小者并记录重复计数，不静默筛选较有利峰位。'),
('FWHM','不扣基线的Imax/2半高阈值，寻找包围全局最高峰的最近左右交点，仅用相邻实测点线性插值确定半高交点位置。该插值仅用于宽度测量，不插入绘图信号点。'),
('总体统计','峰位均值、中位数、样本SD(ddof=1)由所有35条有效扫描计算；FWHM同时提供每扫描值、组均值、中位数、样本SD及代表曲线值。'),
('代表曲线筛选','首先最小化峰位与该组中位数的绝对距离；只有距离完全相同时，优先左右半高交点完整、采集标记更少，再按原始扫描编号。D=y16、L=y20，均唯一命中中位数，未为增大差异而择优。'),
('整体平移','V_aligned=V_original−V_peak+V_mean。D平移+0.754285714286 mV；L平移+0.319771428571 mV。仅坐标整体加常数，不改变任意强度值或采样间距。已逐项核对平移前后FWHM相同。'),
('离群标记','D组y17、y27、y33仅被Tukey 1.5×IQR规则标记以便追溯，仍全部参加均值、SD和中位数统计；不把这些标记作为删除理由。'),
('主图含义','主图是两组真实代表扫描归一化后、平移至各组平均峰位置的3D线瀑布图，既不是35条曲线的平均峰形，也不是未经处理的原始同时实测双峰谱图。'),
('视窗','主图X显示120–160 mV，采用相同电压尺度；已核对该范围包含两条代表扫描的完整主峰和局部尾部。完整0–149999采样坐标的代表曲线另存CSV.GZ，完整35条原始/归一化矩阵存NPZ。'),
('三维属性','使用真正3D折线：X=平移后电压、Y=分类样品深度(D=0、L=1.8)、Z=归一化强度。无散点、柱体、曲面或曲线下填充；D位于前方，X从左向右递增。'),
('字体及导出','Arial Regular；轴标题13 pt，刻度11 pt，峰位标注11.5 pt，曲线1.9 pt。600 dpi TIFF/PNG为7680×4320，16:9；PDF保留矢量曲线和内嵌Arial字体。'),
('渲染软件','已读取并采用Origin Skill数据与图形控制规范；当前Linux无本地Origin/OriginPro，用户要求直接解决，因此实际图形由Matplotlib mplot3d完成。附Origin可导入XYZ数据和FigureSpec；未生成或冒称Origin OPJU项目。'),
('禁止的处理','没有合成实验数据，没有补点或补零，没有高斯拟合，没有平滑，没有伸缩峰形，没有为了得到更大手性区分而挑选曲线。'),
]

cols={'sample_name':'样品','n_valid':'有效扫描数','peak_mV_mean_assumed':'平均峰位_mV_暂定',
      'peak_mV_median_assumed':'中位峰位_mV_暂定','peak_mV_SD_sample_assumed':'峰位样本SD_mV_暂定',
      'representative_scan':'代表曲线','representative_original_peak_mV_assumed':'代表曲线原峰位_mV_暂定',
      'translation_mV':'整体平移_mV','representative_FWHM_mV_assumed':'代表曲线FWHM_mV_暂定',
      'FWHM_mV_mean_assumed':'全部扫描FWHM均值_mV_暂定','FWHM_mV_SD_sample_assumed':'FWHM样本SD_mV_暂定',
      'delta_V_mV_assumed':'两组均值差ΔV_mV_暂定'}
brief=groups[list(cols)].rename(columns=cols)
calibration=pd.DataFrame([{'parameter':'V_AC = X × 0.002','verified_instrument_calibration':False,
    'basis':'provisional user-specified linear range assumption','sampling_points':150000,
    'X_start':0,'X_end':149999,'original_voltage_end_mV':299.998,'delta_V_mV':delta}])
source_rows=[{'sample':m['sample'],'file':m['file'],'sheet':m['sheet_names'][0],
             'numeric_rows':m['numeric_rows'],'scan_count':len(m['headers'])-1,'SHA256':m['sha256']} for m in metadata]
book=O/'ICP_peak_statistics_and_processing.xlsx'
with pd.ExcelWriter(book,engine='openpyxl') as w:
    brief.to_excel(w,sheet_name='汇总_电压为暂定换算',index=False)
    groups.to_excel(w,sheet_name='Group_summary_full_precision',index=False)
    scans.to_excel(w,sheet_name='全部70条扫描_不删异常',index=False)
    scans.loc[scans['representative']].to_excel(w,sheet_name='代表扫描筛选记录',index=False)
    pd.DataFrame(notes,columns=['项目','处理说明']).to_excel(w,sheet_name='方法与图注要求',index=False)
    calibration.to_excel(w,sheet_name='暂定电压换算_非标定',index=False)
    pd.DataFrame(source_rows).to_excel(w,sheet_name='原始文件校验',index=False)
    pd.DataFrame([{'sample':m['sample'],**cell} for m in metadata for cell in m['nondata_cells']]).to_excel(w,sheet_name='原文件非数据设置',index=False)
    plot.to_excel(w,sheet_name='主图实测点_Origin可导入',index=False)
    for ws in w.book.worksheets:
        ws.freeze_panes='B2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.showGridLines=False
        for c in ws[1]:
            c.fill=PatternFill('solid',fgColor='24445C');c.font=Font(name='Arial',bold=True,color='FFFFFF')
            c.alignment=Alignment(wrap_text=True,vertical='center')
        ws.row_dimensions[1].height=42
        for j in range(1,ws.max_column+1):
            label=str(ws.cell(1,j).value);width=23
            if label=='处理说明':width=135
            if label=='SHA256':width=70
            ws.column_dimensions[get_column_letter(j)].width=width
        for row in ws.iter_rows(min_row=2):
            for c in row:
                if isinstance(c.value,float):c.number_format='0.000000'
                if ws.title=='方法与图注要求':c.alignment=Alignment(wrap_text=True,vertical='center')
            if ws.title=='方法与图注要求':ws.row_dimensions[row[0].row].height=57
    ws=w.book.create_sheet('3D图预览')
    im=ExcelImage(str(O/'ICP_D_L_waterfall_preview.png'));im.width=1152;im.height=648;ws.add_image(im,'A1')

caption_en=f'''Three-dimensional line-waterfall visualization of ion cloud profiling scans of D-arginine and L-arginine acquired separately in the presence of verapamil hydrochloride at the same experimental frequency (user-specified voltage parameter: 300 mV). Each of the 35 scans per group was normalized independently to its own maximum. The measured scan whose peak position was nearest the group median was selected (D: Y16; L: Y20), and its voltage coordinates were translated rigidly so that its maximum coincided with the mean peak position calculated from all 35 valid scans. The aligned means are 132.712 mV (D) and 144.896 mV (L); ΔV={delta:.6f} mV was computed from the unrounded means. No smoothing, Gaussian fitting, peak reconstruction, horizontal scaling, or averaging of peak shapes was applied. Representative FWHM values are 0.399992 mV (D) and 0.397719 mV (L), unchanged by alignment. Voltage coordinates and all voltage-derived statistics use the provisional relation V_AC (mV)=X×300/150000=X×0.002 because no calibration parameters were present in the files; this is an assumed linear scan range, not a verified instrument calibration. The figure shows aligned measured representative profiles and the overall group peak-position difference, not an unprocessed simultaneous two-peak spectrum. Actual rendering: Matplotlib mplot3d; Origin-importable data are supplied.'''
caption_zh=f'''盐酸维拉帕米存在条件下分别测得的D-Arginine与L-Arginine离子云扫描(ICP)三维线瀑布图。两组频率相同，用户给定实验电压参数为300 mV。每组35条扫描分别按各自最大值归一化。选择峰位最接近组中位数的真实扫描(D：Y16；L：Y20)，仅整体平移电压坐标，使峰顶对齐至该组全部35条有效扫描的平均峰位。对齐后的平均峰位为D：132.712 mV、L：144.896 mV；由未舍入均值计算ΔV={delta:.6f} mV。未平滑、未高斯拟合、未峰形重构、未横向缩放、未对35条峰形直接平均。代表曲线FWHM分别为0.399992 mV和0.397719 mV，平移后不变。文件未提供电压标定，电压与所有电压派生统计均采用暂定线性关系V_AC(mV)=X×0.002，不能视为已验证的仪器标定。该图展示真实代表曲线对齐后的峰形和总体峰位置差异，不是未经处理的原始同时实测双峰谱图。实际渲染工具为Matplotlib mplot3d，另附Origin可导入数据。'''
(O/'Figure_caption_EN.txt').write_text(caption_en+'\n')
(O/'Figure_caption_ZH.txt').write_text(caption_zh+'\n',encoding='utf-8')
(O/'Methods_and_processing_record.md').write_text('# ICP D/L-Arginine processing record\n\n'+'\n\n'.join(f'**{k}**：{v}' for k,v in notes),encoding='utf-8')
spec={
 'figure':{'id':'ICP_D_L_Arginine_waterfall','title':None,'graph_kind':'true_3d_line_waterfall','not_a_surface':True},
 'runtime':{'preferred_backend':'Origin on Windows','actual_backend':'Matplotlib mplot3d',
            'native_origin_available':False,'save_project':False,'native_opju_generated':False},
 'data':[{'id':g,'source':f'{g}_Origin_XYZ_plot.csv','format':'csv','object':'worksheet_XYZ',
          'roles':{'x':'V_aligned_mV_assumed','y':'sample_depth','z':'I_normalized'},
          'source_scan':record['representatives'][g]['scan'],'no_smoothing':True} for g in ['D','L']],
 'page':{'id':'main','size_mm':[325.12,182.88],'aspect_ratio':'16:9','background':'white'},
 'layers':[{'id':'waterfall','page':'main','dimension':'3D',
            'x':{'title':'V_AC (mV)','subscript':'AC','limits':[120,160],'major_step':5,'calibration':'provisional X*0.002'},
            'y':{'title':'Sample','categories':{'D-Arginine':0.0,'L-Arginine':1.8},'front':'D-Arginine'},
            'z':{'title':'Normalized intensity','limits':[0,1.2],'major_step':.2}}],
 'plots':[{'id':g+'_line','layer':'waterfall','data_ref':g,'type':'line3d','color':c,
           'line_width_pt':1.9,'line_style':'solid','markers':False,'fill':False}
          for g,c in [('D','#2166AC'),('L','#D73027')]],
 'annotations':[{'type':'text3d','sample':g,'x':record['representatives'][g]['mean_peak_mV_assumed'],
                 'y':0 if g=='D' else 1.8,'z':1.055,
                 'text':f"{record['representatives'][g]['mean_peak_mV_assumed']:.3f} mV",
                 'font_size_pt':11.5,'color':c} for g,c in [('D','#2166AC'),('L','#D73027')]],
 'style':{'font_family':'Arial','axis_title_pt':13,'tick_label_pt':11,'grid':'light gray','camera':{'elevation':23,'azimuth':-60,'focal_length':1.35}},
 'export':{'png':{'dpi':600},'tiff':{'dpi':600,'compression':'LZW'},'pdf':{'vector':True},'save_clean_data':True},
 'provenance':{'normalization':'per scan I/Imax','selection':'nearest group median peak position',
               'alignment':'V_original - V_peak + V_mean','calibration_verified':False,'delta_V_mV_assumed':delta}}
(O/'FigureSpec.yaml').write_text(yaml.safe_dump(spec,allow_unicode=True,sort_keys=False),encoding='utf-8')
shutil.copy2(B/'raw_metadata.json',O/'raw_file_metadata.json')
for source in metadata:
    assert hashlib.sha256((B/'raw'/source['file']).read_bytes()).hexdigest()==source['sha256']
print('Workbook, bilingual figure captions, source metadata, methods and FigureSpec saved.')
print(brief.to_string(index=False))
