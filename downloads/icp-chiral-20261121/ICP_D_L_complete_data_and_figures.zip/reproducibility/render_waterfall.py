from pathlib import Path
import os,json
os.environ['MPLCONFIGDIR']=str(Path(__file__).resolve().parent/'mplconfig')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
from matplotlib.ticker import MultipleLocator,FormatStrFormatter
from PIL import Image

B=Path(__file__).resolve().parent;O=B/'output'
record=json.loads((O/'processing_record.json').read_text())
font_path=B/'font_setup'/'Arial.ttf'
font_manager.fontManager.addfont(str(font_path))
assert font_manager.FontProperties(fname=font_path).get_name()=='Arial'
plt.rcParams.update({'font.family':'Arial','font.size':11,'axes.unicode_minus':False,
    'mathtext.fontset':'custom','mathtext.rm':'Arial','mathtext.it':'Arial','mathtext.bf':'Arial',
    'mathtext.cal':'Arial','mathtext.sf':'Arial','mathtext.tt':'Arial',
    'pdf.fonttype':42,'ps.fonttype':42,'path.simplify':False,'savefig.facecolor':'white'})

fig=plt.figure(figsize=(12.8,7.2),facecolor='white')
ax=fig.add_subplot(111,projection='3d')
fig.subplots_adjust(left=.02,right=.88,bottom=.10,top=.97)
colors={'D':'#2166AC','L':'#D73027'}
depth={'D':0.0,'L':1.8}
artists=[]
for group in ['D','L']:
    table=pd.read_csv(O/f'{group}_Origin_XYZ_plot.csv')
    x=table['V_aligned_mV_assumed'].to_numpy();z=table['I_normalized'].to_numpy()
    y=table['sample_depth'].to_numpy()
    assert np.all(np.diff(x)>0) and np.isclose(z.max(),1) and np.all(y==depth[group])
    line,=ax.plot(x,y,z,color=colors[group],lw=1.9,ls='-',marker=None,zorder=4 if group=='D' else 3)
    artists.append(line)
    mean=record['representatives'][group]['mean_peak_mV_assumed']
    ax.text(mean,depth[group],1.055,f'{mean:.3f} mV',ha='center',va='bottom',
            color=colors[group],fontsize=11.5,fontfamily='Arial',zorder=10)

ax.set_xlim(*record['plot_x_limits_mV']);ax.set_ylim(-.28,2.15);ax.set_zlim(0,1.2)
ax.xaxis.set_major_locator(MultipleLocator(5))
ax.zaxis.set_major_locator(MultipleLocator(.2));ax.zaxis.set_major_formatter(FormatStrFormatter('%.1f'))
ax.set_yticks([depth['D'],depth['L']]);ax.set_yticklabels(['D-Arginine','L-Arginine'],ha='left')
ax.set_xlabel(r'$V_{\mathrm{AC}}$ (mV)',fontsize=13,labelpad=13)
ax.set_ylabel('Sample',fontsize=13,labelpad=37)
ax.set_zlabel('Normalized intensity',fontsize=13,labelpad=13)
ax.tick_params(axis='x',labelsize=11,pad=3)
ax.tick_params(axis='y',labelsize=11,pad=10)
ax.tick_params(axis='z',labelsize=11,pad=3)
for axis in [ax.xaxis,ax.yaxis,ax.zaxis]:
    axis.pane.set_facecolor((1,1,1,1));axis.pane.set_edgecolor((.90,.90,.90,1))
    axis.line.set_color('#333333');axis.line.set_linewidth(.7)
    axis._axinfo['grid'].update(color=(.82,.82,.82,.65),linewidth=.45,linestyle='-')
ax.set_proj_type('persp',focal_length=1.35)
ax.view_init(elev=23,azim=-60)
ax.set_box_aspect((2.85,1.25,1.55))
# mplot3d projection check: D must be closer to the camera than L, and X must
# increase from left to right in the visible image.
from mpl_toolkits.mplot3d import proj3d
matrix=ax.get_proj();mid=float(np.mean(record['plot_x_limits_mV']))
front=proj3d.proj_transform(mid,depth['D'],.5,matrix)
back=proj3d.proj_transform(mid,depth['L'],.5,matrix)
left=proj3d.proj_transform(record['plot_x_limits_mV'][0],0,0,matrix)
right=proj3d.proj_transform(record['plot_x_limits_mV'][1],0,0,matrix)
assert left[0]<right[0]
assert front[2]<back[2],(front,back)
assert len(ax.lines)==2 and len(ax.collections)==0 and len(ax.texts)==2
assert len(fig.texts)==0 and not ax.get_title()
for line in artists:
    assert line.get_marker() in [None,'None','']
fig.savefig(O/'ICP_D_L_waterfall_600dpi.png',dpi=600)
fig.savefig(O/'ICP_D_L_waterfall_600dpi.tiff',dpi=600,
            pil_kwargs={'compression':'tiff_lzw'})
fig.savefig(O/'ICP_D_L_waterfall_preview.png',dpi=180)
fig.savefig(O/'ICP_D_L_waterfall_vector.pdf',metadata={
    'Title':'ICP D- and L-Arginine normalized representative 3D waterfall',
    'Subject':'Measured representative scans translated to group mean peak positions; provisional voltage conversion',
    'Creator':'Matplotlib; Origin Skill data workflow; native Origin unavailable'})
fig.savefig(O/'ICP_D_L_waterfall_vector.svg')
plt.close(fig)
with Image.open(O/'ICP_D_L_waterfall_600dpi.tiff') as im:
    assert im.size==(7680,4320) and abs(im.info['dpi'][0]-600)<1
with Image.open(O/'ICP_D_L_waterfall_600dpi.png') as im:
    assert im.size==(7680,4320) and abs(im.info['dpi'][0]-600)<1
visual={'renderer':'Matplotlib mplot3d','native_origin_rendered':False,
        'font_family':'Arial','font_file_sha256':__import__('hashlib').sha256(font_path.read_bytes()).hexdigest(),
        'figure_inches':[12.8,7.2],'raster_pixels':[7680,4320],'raster_dpi':600,
        'line_width_pt':1.9,'depth_categories':depth,'colors':colors,
        'elevation_deg':23,'azimuth_deg':-60,'perspective_focal_length':1.35,
        'line_count':2,'fill_or_surface_collections':0,'markers':False,
        'D_in_front_verified':True,'X_increases_left_to_right_verified':True,
        'coordinates_are_actual_aligned_samples':True,'no_path_simplification':True}
(O/'rendering_record.json').write_text(json.dumps(visual,indent=2))
print('VALIDATED: true 3D line waterfall, D in front, X increasing left-to-right; exact raw profiles, normalization and translation only; 600 dpi PNG/TIFF and vector PDF exported.')
