"""Restore the exact Arial package used for rendering, without running package JS."""
from pathlib import Path
import urllib.request,hashlib,base64,tarfile,io,json
from fontTools.ttLib import TTFont

B=Path(__file__).resolve().parent
URL='https://registry.npmjs.org/@canvas-fonts/arial/-/arial-1.0.4.tgz'
INTEGRITY='sha512-3kutrSYYWiICFjMNQWqlhu1JJmi1tlqz+CaVgkpq24B4oREIg8IYDvqJK4DiewC0qvcWvqVS/8GPNv5QXm7KeA=='
with urllib.request.urlopen(URL,timeout=60) as response:archive=response.read()
algorithm,expected=INTEGRITY.split('-',1)
assert base64.b64encode(hashlib.new(algorithm,archive).digest()).decode()==expected
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as package:
    font=package.extractfile('package/Arial.ttf').read()
dest=B/'font_setup';dest.mkdir(exist_ok=True)
path=dest/'Arial.ttf';path.write_bytes(font)
with TTFont(path) as face:
    assert face['name'].getDebugName(1)=='Arial'
    assert not face['OS/2'].fsType&2,'Restricted font embedding'
(dest/'arial-package-provenance.json').write_text(json.dumps({'name':'@canvas-fonts/arial',
    'version':'1.0.4','tarball':URL,'integrity':INTEGRITY,'sha256':hashlib.sha256(archive).hexdigest()},indent=2))
print('Verified Arial 1.0.4 package integrity; exact font restored for local rendering.')
